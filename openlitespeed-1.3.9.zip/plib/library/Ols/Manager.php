<?php

require_once pm_Context::getPlibDir() . 'library/Ols/L10n.php';

class Ols_Manager
{
    const VERSION = '1.3.9';
    const CONTROL_ACTIONS = array('start', 'stop', 'restart', 'graceful');
    const LOG_TYPES = array('error', 'access', 'admin-error', 'admin-access', 'vhost-access', 'vhost-error');
    const ENGINE_MODES = array('ols', 'nginx');
    const PHP_MODES = array('direct', 'backend');

    public static function call($action, array $extra = array())
    {
        $args = array_merge(array('--action=' . $action), $extra);
        $env = array(
            'PATH' => '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
        );
        $root = (string) pm_Settings::get('ols_root', '');
        if ($root !== '') {
            $env['OLS_ROOT'] = $root;
        }

        $result = pm_ApiCli::callSbin('openlitespeed', $args, pm_ApiCli::RESULT_FULL, $env);

        return self::decode($result);
    }

    public static function info()
    {
        return self::call('info');
    }

    public static function control($action)
    {
        if (!in_array($action, self::CONTROL_ACTIONS, true)) {
            throw new pm_Exception(Ols_L10n::t('Unsupported control action.'));
        }

        return self::call($action);
    }

    public static function test()
    {
        return self::call('test');
    }

    public static function vhosts()
    {
        $data = self::call('vhosts');

        return isset($data['vhosts']) ? $data['vhosts'] : array();
    }

    public static function logs($type, $vhost, $lines)
    {
        if (!in_array($type, self::LOG_TYPES, true)) {
            throw new pm_Exception(Ols_L10n::t('Unknown log type.'));
        }
        $lines = max(1, min(2000, (int) $lines));
        $args = array('--type=' . $type, '--lines=' . $lines);
        if ($vhost !== '') {
            if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9._-]*$/', $vhost)) {
                throw new pm_Exception(Ols_L10n::t('Invalid virtual host name.'));
            }
            $args[] = '--vhost=' . $vhost;
        }

        return self::call('logs', $args);
    }

    public static function engineStatus()
    {
        return self::call('engine-status');
    }

    public static function engineSwitch($mode, $phpMode = 'backend')
    {
        if (!in_array($mode, self::ENGINE_MODES, true)) {
            throw new pm_Exception(Ols_L10n::t('Unsupported web engine mode.'));
        }
        if (!in_array($phpMode, self::PHP_MODES, true)) {
            $phpMode = 'backend';
        }
        $extra = $mode === 'ols' ? array('--php-mode=' . $phpMode) : array();

        return self::call('engine-switch-' . $mode, $extra);
    }

    public static function adminConsole()
    {
        return self::call('admin-console');
    }

    public static function consoleUser($user, $password)
    {
        if (strlen($password) < 6) {
            throw new pm_Exception(Ols_L10n::t('The console password must be at least 6 characters long.'));
        }

        return self::call('admin-console-user', array(
            '--user=' . $user,
            '--payload=' . base64_encode($password),
        ));
    }

    public static function engineSync()
    {
        return self::call('engine-sync');
    }

    public static function setupStatus($lite = false)
    {
        return self::call('setup-status', $lite ? array('--lite=1') : array());
    }

    public static function setupRun($phpMode = 'direct')
    {
        if (!in_array($phpMode, self::PHP_MODES, true)) {
            $phpMode = 'direct';
        }

        return self::call('setup-run', array('--php-mode=' . $phpMode));
    }

    public static function setupDone()
    {
        return self::call('setup-done');
    }

    public static function setupSkip()
    {
        $data = self::call('setup-skip');
        if (!empty($data['ok'])) {
            return $data;
        }

        throw new pm_Exception(Ols_L10n::t('The OpenLiteSpeed helper reported a failure.'));
    }

    public static function setupReset()
    {
        return self::call('setup-reset');
    }

    public static function updateCheck($force = false)
    {
        return self::call('update-check', $force ? array('--force=1') : array());
    }

    public static function updateApply()
    {
        return self::call('update-apply');
    }

    public static function configList()
    {
        $data = self::call('config-list');

        return isset($data['files']) ? $data['files'] : array();
    }

    public static function configGet($key)
    {
        return self::call('config-get', array('--key=' . self::safeConfigKey($key)));
    }

    public static function configSave($key, $content)
    {
        $args = array(
            '--key=' . self::safeConfigKey($key),
            '--payload=' . base64_encode($content),
        );

        return self::call('config-save', $args);
    }

    public static function safeConfigKey($key)
    {
        if (!preg_match('/^(main|admin-context|vhost-[A-Za-z0-9][A-Za-z0-9._-]*)$/', (string) $key)) {
            throw new pm_Exception(Ols_L10n::t('Invalid configuration file key.'));
        }

        return (string) $key;
    }

    private static function decode($result)
    {
        $stdout = '';
        $stderr = '';
        $code = 0;

        if (is_array($result)) {
            $stdout = isset($result['stdout']) ? $result['stdout'] : (isset($result[1]) ? $result[1] : '');
            $stderr = isset($result['stderr']) ? $result['stderr'] : (isset($result[2]) ? $result[2] : '');
            $code = isset($result['code']) ? (int) $result['code'] : (isset($result[0]) ? (int) $result[0] : 0);
        } elseif (is_string($result)) {
            $stdout = $result;
        }

        $data = json_decode($stdout, true);

        if (is_array($data) && isset($data['ok'])) {
            if (!$data['ok']) {
                $reason = isset($data['error']) ? (string) $data['error'] : '';
                if ($reason === '' && isset($data['output'])) {
                    $reason = (string) $data['output'];
                }
                if ($reason === '') {
                    $reason = Ols_L10n::t('The OpenLiteSpeed helper reported a failure.');
                }
                throw new pm_Exception(Ols_L10n::t(self::shorten($reason)));
            }

            return $data;
        }

        if ($code !== 0) {
            $detail = $stderr !== '' ? $stderr : $stdout;
            throw new pm_Exception(Ols_L10n::t('OpenLiteSpeed helper failed (exit code {0}):', array((string) $code))
                . ' ' . self::shorten($detail));
        }

        throw new pm_Exception(Ols_L10n::t('Unexpected response from the OpenLiteSpeed helper:')
            . ' ' . self::shorten($stdout));
    }

    private static function shorten($text)
    {
        $text = trim((string) $text);
        if (strlen($text) > 2000) {
            return substr($text, 0, 2000) . '...';
        }

        return $text;
    }
}

(function () {
    'use strict';

    document.addEventListener('submit', function (event) {
        var form = event.target.closest('form[data-confirm]');
        if (!form || event.defaultPrevented) {
            return;
        }
        if (!window.confirm(form.getAttribute('data-confirm'))) {
            event.preventDefault();
            event.stopPropagation();
        }
    }, true);

    document.addEventListener('change', function (event) {
        var control = event.target;
        if (control.tagName === 'SELECT' && control.hasAttribute('data-auto-submit')) {
            if (control.form) {
                control.form.submit();
            }
        }
    });

    document.addEventListener('click', function (event) {
        var button = event.target.closest('[data-toggle-readonly]');
        if (!button) {
            return;
        }
        var field = document.getElementById(button.getAttribute('data-toggle-readonly'));
        if (!field) {
            return;
        }
        field.readOnly = !field.readOnly;
        if (!field.readOnly) {
            field.focus();
        }
        button.textContent = field.readOnly
            ? button.getAttribute('data-label-locked')
            : button.getAttribute('data-label-unlocked');
        var save = button.form ? button.form.querySelector('[data-save-button]') : null;
        if (save) {
            save.disabled = field.readOnly;
        }
    });

    function dismissToast(toast) {
        if (!toast || toast.classList.contains('is-hidden')) {
            return;
        }
        toast.classList.add('is-hidden');
        window.setTimeout(function () {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 300);
    }

    function scheduleToasts() {
        var toasts = document.querySelectorAll('.ols-toast');
        for (var i = 0; i < toasts.length; i++) {
            (function (toast) {
                var delay = toast.classList.contains('ols-toast--error') ? 14000 : 7000;
                toast.setAttribute('data-hide', window.setTimeout(function () {
                    dismissToast(toast);
                }, delay));
            })(toasts[i]);
        }
    }

    document.addEventListener('click', function (event) {
        var close = event.target.closest('[data-ols-toast-close]');
        if (close) {
            var toast = close.closest('.ols-toast');
            if (toast && toast.getAttribute('data-hide')) {
                window.clearTimeout(Number(toast.getAttribute('data-hide')));
            }
            dismissToast(toast);

            return;
        }

        // The panel keeps no back control for module pages, so the button walks the
        // browser history when there is one and otherwise lands on the panel home.
        var back = event.target.closest('[data-ols-back]');
        if (back && window.history.length > 1) {
            event.preventDefault();
            window.history.back();
        }
    });

    // The detached setup worker keeps running while the panel is closed, so the
    // wizard page reloads itself until the worker has recorded a final stage.
    function setupAutoRefresh() {
        var marker = document.querySelector('[data-ols-auto-refresh]');
        if (!marker) {
            return;
        }
        var seconds = parseInt(marker.getAttribute('data-ols-auto-refresh'), 10);
        if (!(seconds > 1)) {
            seconds = 4;
        }
        var url = marker.getAttribute('data-ols-refresh-url');
        window.setTimeout(function () {
            if (document.hidden) {
                setupAutoRefresh();

                return;
            }
            if (url) {
                window.location.assign(url);
            } else {
                window.location.reload();
            }
        }, seconds * 1000);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            scheduleToasts();
            setupAutoRefresh();
        });
    } else {
        scheduleToasts();
        setupAutoRefresh();
    }
}());

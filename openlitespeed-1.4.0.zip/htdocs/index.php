<?php
pm_Context::init('openlitespeed');
$application = new pm_Application();
$application->run();

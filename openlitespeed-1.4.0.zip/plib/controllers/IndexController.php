<?php

require_once pm_Context::getPlibDir() . 'library/Ols/Manager.php';
require_once pm_Context::getPlibDir() . 'library/Ols/L10n.php';

class IndexController extends pm_Controller_Action
{
    protected $_accessLevel = array('admin');

    private $_info = null;
    private $_infoError = null;
    private $_setup = null;

    public function init()
    {
        parent::init();

        $this->handleLanguageSwitch();

        $this->view->pageTitle = 'OpenLiteSpeed';
        $this->view->currentAction = $this->_request->getActionName();
        $this->view->headLink()->appendStylesheet(pm_Context::getBaseUrl() . 'assets/ols.css');
        $this->view->headScript()->appendFile(pm_Context::getBaseUrl() . 'assets/ols.js');
        $this->view->tabs = array(
            array('title' => Ols_L10n::t('Dashboard'), 'action' => 'index'),
            array('title' => Ols_L10n::t('Web Engine'), 'action' => 'webengine'),
            array('title' => Ols_L10n::t('Virtual Hosts'), 'action' => 'vhosts'),
            array('title' => Ols_L10n::t('Logs'), 'action' => 'logs'),
            array('title' => Ols_L10n::t('Configuration'), 'action' => 'config'),
            array('title' => Ols_L10n::t('Settings'), 'action' => 'settings'),
        );

        $this->view->ui = $this->uiData();

        // A freshly installed extension shows the one-click setup page first; it
        // disappears as soon as the administrator has been through it.
        if ($this->wizardNeeded()) {
            $this->doRedirect(pm_Context::getActionUrl('index', 'wizard'));
        }
    }

    public function wizardAction()
    {
        $this->view->tabs = array();
        try {
            $setup = Ols_Manager::setupStatus();
        } catch (Exception $e) {
            $setup = array_merge($this->setupGate(), array('domains' => 0, 'php_direct_domains' => 0,
                'steps' => array(), 'log' => null));
            $setup['error'] = $e->getMessage();
        }
        $this->view->setup = $this->acknowledgeSetup($setup);
        $flash = $this->pullFlash();
        $this->view->notice = isset($flash['notice']) ? $flash['notice'] : null;
        $this->view->error = isset($flash['error']) ? $flash['error'] : null;
    }

    /**
     * Reinstalling the extension makes the welcome page ask once more. Where
     * OpenLiteSpeed is already the web front that visit is only an
     * acknowledgement: the page shows the finished state and closes its own gate,
     * so the next click lands on the panel instead of looping back here.
     */
    private function acknowledgeSetup(array $setup)
    {
        $finished = empty($setup['running'])
            && (!empty($setup['front_installed'])
                || (isset($setup['stage']) && $setup['stage'] === 'ready'));
        if (!$finished || !empty($setup['onboarded'])) {
            return $setup;
        }

        try {
            Ols_Manager::setupDone();
            $setup['onboarded'] = true;
        } catch (Exception $e) {
            // Asking again on the next visit beats failing the welcome page.
        }

        return $setup;
    }

    public function setuprunAction()
    {
        $this->requirePost();
        $wizardUrl = pm_Context::getActionUrl('index', 'wizard');
        $phpMode = (string) $this->_request->getPost('ols_php_mode');
        if (!in_array($phpMode, Ols_Manager::PHP_MODES, true)) {
            $phpMode = 'direct';
        }

        try {
            $result = Ols_Manager::setupRun($phpMode);
            if (empty($result['ok'])) {
                throw new pm_Exception(Ols_L10n::t('The OpenLiteSpeed helper reported a failure.'));
            }
            $this->redirectWithNotice(Ols_L10n::t('The setup is running. This page updates on its own.'), $wizardUrl);
        } catch (Exception $e) {
            $this->redirectWithError($e->getMessage(), $wizardUrl);
        }
    }

    public function setupskipAction()
    {
        $this->requirePost();
        $indexUrl = pm_Context::getActionUrl('index', 'index');

        try {
            Ols_Manager::setupSkip();
            $this->redirectWithNotice(Ols_L10n::t('The setup wizard is hidden now; you can switch the web front at any time on the Web Engine page.'), $indexUrl);
        } catch (Exception $e) {
            $this->redirectWithError($e->getMessage(), pm_Context::getActionUrl('index', 'wizard'));
        }
    }

    public function indexAction()
    {
        $info = $this->info();
        if ($this->_infoError !== null) {
            $info['error'] = $this->_infoError;
        }

        $this->view->info = $info;
        $this->view->update = $this->updateStatus(false);
        $flash = $this->pullFlash();
        $this->view->notice = isset($flash['notice']) ? $flash['notice'] : null;
        $this->view->error = isset($flash['error']) ? $flash['error'] : null;
    }

    public function updatecheckAction()
    {
        $this->requirePost();
        $indexUrl = pm_Context::getActionUrl('index', 'index');
        $check = $this->updateStatus(true);
        if (!empty($check['error'])) {
            $this->redirectWithError(Ols_L10n::t('The update check failed:') . ' ' . $check['error'], $indexUrl);
        }
        if (!empty($check['available'])) {
            $this->redirectWithNotice(Ols_L10n::t('A newer version is available: {0} (this server runs {1}).',
                array($check['latest'], $check['current'])), $indexUrl);
        }

        $this->redirectWithNotice(Ols_L10n::t('This is the newest version: {0}.', array($check['current'])), $indexUrl);
    }

    public function updateapplyAction()
    {
        $this->requirePost();
        $indexUrl = pm_Context::getActionUrl('index', 'index');

        try {
            $result = Ols_Manager::updateApply();
        } catch (Exception $e) {
            $this->redirectWithError($e->getMessage(), $indexUrl);

            return;
        }

        if (!empty($result['updated'])) {
            $this->redirectWithNotice(Ols_L10n::t('OpenLiteSpeed was updated to version {0}; the web front configuration was left untouched.',
                array($result['current'])), $indexUrl);

            return;
        }

        if (!empty($result['ok'])) {
            $this->redirectWithNotice(Ols_L10n::t('This is already the newest version: {0}.', array($result['current'])), $indexUrl);

            return;
        }

        $this->redirectWithError(Ols_L10n::t('The update could not be installed:') . ' '
            . (isset($result['error']) ? $result['error'] : Ols_L10n::t('The OpenLiteSpeed helper reported a failure.')), $indexUrl);
    }

    /**
     * Landing on the OpenLiteSpeed page asks the release feed for a newer
     * version, but the answer is cached for hours and a failed check is silent:
     * the dashboard must never wait on, or break because of, github.com.
     */
    private function updateStatus($force)
    {
        try {
            $check = Ols_Manager::updateCheck($force);
        } catch (Exception $e) {
            return array('ok' => false, 'available' => false, 'error' => $e->getMessage());
        }

        return is_array($check) ? $check : array('ok' => false, 'available' => false);
    }

    public function webengineAction()
    {
        $status = array('ok' => false, 'mode' => null, 'domains' => array(), 'error' => null);
        try {
            $status = Ols_Manager::engineStatus();
        } catch (Exception $e) {
            $status['error'] = $e->getMessage();
        }

        $this->view->engine = $status;
        $flash = $this->pullFlash();
        $this->view->notice = isset($flash['notice']) ? $flash['notice'] : null;
        $this->view->error = isset($flash['error']) ? $flash['error'] : null;
    }

    public function engineswitchAction()
    {
        $this->requirePost();
        $mode = (string) $this->_request->getPost('ols_engine_mode');
        $phpMode = (string) $this->_request->getPost('ols_php_mode');
        if (!in_array($phpMode, Ols_Manager::PHP_MODES, true)) {
            $phpMode = 'backend';
        }
        $engineUrl = pm_Context::getActionUrl('index', 'webengine');

        try {
            $result = Ols_Manager::engineSwitch($mode, $phpMode);
            if ($mode === 'nginx') {
                $message = Ols_L10n::t('nginx is back in front of Apache and OpenLiteSpeed has been released from ports 80/443.');
            } elseif (!empty($result['apache_disabled'])) {
                $message = Ols_L10n::t('OpenLiteSpeed is now the whole web front: it serves the files, runs PHP itself and Apache is stopped. nginx stays stopped and disabled.');
            } else {
                $message = Ols_L10n::t('OpenLiteSpeed is now the web front for every Plesk domain. nginx is stopped and disabled; Apache keeps serving the few domains that still need it.');
            }

            $checked = isset($result['domains']) ? count($result['domains']) : 0;
            $broken = isset($result['already_broken']) ? count($result['already_broken']) : 0;
            $message .= ' ' . Ols_L10n::t('Health check: {0} domain(s) verified over HTTP.', array($checked));
            if ($broken > 0) {
                $message .= ' ' . Ols_L10n::t('({0} were already unreachable before the switch.)', array($broken));
            }
            if (!empty($result['https_failed'])) {
                $message .= ' ' . Ols_L10n::t('HTTPS warnings:') . ' ' . implode(', ', $result['https_failed']) . '.';
            }
            if (!empty($result['backups'])) {
                $message .= ' ' . Ols_L10n::t('Backups: {0}', array($result['backups']));
            }
            $this->redirectWithNotice($message, $engineUrl);
        } catch (Exception $e) {
            $this->redirectWithError($e->getMessage(), $engineUrl);
        }
    }

    public function enginesyncAction()
    {
        $this->requirePost();
        $engineUrl = pm_Context::getActionUrl('index', 'webengine');

        try {
            $result = Ols_Manager::engineSync();
            $count = isset($result['domains']) ? count($result['domains']) : 0;
            $this->redirectWithNotice(
                Ols_L10n::t('Front-end configuration rebuilt from Plesk: {0} domain(s) mapped, all reachable over HTTP.', array($count)),
                $engineUrl
            );
        } catch (Exception $e) {
            $this->redirectWithError($e->getMessage(), $engineUrl);
        }
    }

    public function controlAction()
    {
        $this->requirePost();
        $action = (string) $this->_request->getPost('ols_action');

        try {
            $result = Ols_Manager::control($action);
            $labels = array(
                'start' => Ols_L10n::t('OpenLiteSpeed has been started.'),
                'stop' => Ols_L10n::t('OpenLiteSpeed has been stopped.'),
                'restart' => Ols_L10n::t('OpenLiteSpeed has been restarted.'),
                'graceful' => Ols_L10n::t('Graceful reload requested for OpenLiteSpeed.'),
            );
            $message = isset($labels[$action]) ? $labels[$action] : Ols_L10n::t('Action completed.');
            if (isset($result['state']['running'])) {
                $message .= $result['state']['running']
                    ? ' ' . Ols_L10n::t('Current state: running.')
                    : ' ' . Ols_L10n::t('Current state: stopped.');
            }
            $this->redirectWithNotice($message);
        } catch (Exception $e) {
            $this->redirectWithError($e->getMessage());
        }
    }

    public function testAction()
    {
        $this->requirePost();

        try {
            $result = Ols_Manager::test();
            if (empty($result['supported'])) {
                $this->redirectWithError(
                    Ols_L10n::t('Configuration test is not supported by this OpenLiteSpeed build.')
                    . ' ' . (isset($result['output']) ? $result['output'] : '')
                );
            } elseif (!empty($result['ok'])) {
                $this->redirectWithNotice(
                    Ols_L10n::t('Configuration test passed.')
                    . (isset($result['output']) ? "\n" . $result['output'] : '')
                );
            } else {
                $this->redirectWithError(
                    Ols_L10n::t('Configuration test FAILED.')
                    . (isset($result['output']) ? "\n" . $result['output'] : '')
                );
            }
        } catch (Exception $e) {
            $this->redirectWithError($e->getMessage());
        }
    }

    public function vhostsAction()
    {
        $vhosts = array();
        $error = null;
        try {
            $vhosts = Ols_Manager::vhosts();
        } catch (Exception $e) {
            $error = $e->getMessage();
        }

        $this->view->vhosts = $vhosts;
        $this->view->loadError = $error;
    }

    public function logsAction()
    {
        $type = (string) $this->_request->getParam('type', 'error');
        if (!in_array($type, Ols_Manager::LOG_TYPES, true)) {
            $type = 'error';
        }
        $vhost = trim((string) $this->_request->getParam('vhost', ''));
        $lines = (int) $this->_request->getParam('lines', 100);

        $vhostNames = array();
        try {
            foreach (Ols_Manager::vhosts() as $vhostInfo) {
                $vhostNames[] = $vhostInfo['name'];
            }
        } catch (Exception $e) {
            $vhostNames = array();
        }

        if ($vhost !== '' && !in_array($vhost, $vhostNames, true)) {
            $vhost = '';
        }
        if ($vhost === '' && count($vhostNames) > 0) {
            $vhost = $vhostNames[0];
        }

        $content = '';
        $path = '';
        $error = null;
        $needsVhost = strpos($type, 'vhost-') === 0;

        if ($needsVhost && count($vhostNames) === 0) {
            $error = Ols_L10n::t('This OpenLiteSpeed installation has no virtual host, so there is nothing to show.');
        } else {
            try {
                $data = Ols_Manager::logs($type, $needsVhost ? $vhost : '', $lines);
                $content = $data['content'];
                $path = $data['path'];
                if (empty($data['exists'])) {
                    $error = Ols_L10n::t('The log file does not exist yet:') . ' ' . $path;
                }
            } catch (Exception $e) {
                $error = $e->getMessage();
            }
        }

        $this->view->logType = $type;
        $this->view->logVhost = $vhost;
        $this->view->logNeedsVhost = $needsVhost;
        $this->view->logLines = max(1, min(2000, $lines));
        $this->view->logContent = $content;
        $this->view->logPath = $path;
        $this->view->logError = $error;
        $this->view->vhostNames = $vhostNames;
    }

    public function configAction()
    {
        $key = (string) $this->_request->getParam('key', 'main');
        try {
            $key = Ols_Manager::safeConfigKey($key);
        } catch (Exception $e) {
            $key = 'main';
        }

        $files = array();
        $file = null;
        $error = null;
        try {
            $files = Ols_Manager::configList();
            $file = Ols_Manager::configGet($key);
        } catch (Exception $e) {
            $error = $e->getMessage();
        }

        $flash = $this->pullFlash();
        $this->view->configKey = $key;
        $this->view->configFiles = $files;
        $this->view->configFile = $file;
        $this->view->configError = $error;
        $this->view->notice = isset($flash['notice']) ? $flash['notice'] : null;
        $this->view->error = isset($flash['error']) ? $flash['error'] : null;
    }

    public function configsaveAction()
    {
        $this->requirePost();

        $key = (string) $this->_request->getPost('key');
        $content = (string) $this->_request->getPost('content');
        $configUrl = pm_Context::getActionUrl('index', 'config') . '?key=' . urlencode($key);

        try {
            $result = Ols_Manager::configSave($key, $content);
            $message = Ols_L10n::t('Configuration saved and validated.');
            if (!empty($result['backup'])) {
                $message .= ' ' . Ols_L10n::t('Previous version backed up to {0}', array($result['backup']));
            }
            if (!empty($result['test_skipped'])) {
                $message .= ' ' . Ols_L10n::t('Note: this OpenLiteSpeed build does not support config testing, the change was applied without validation.');
            }
            $message .= ' ' . Ols_L10n::t('Restart OpenLiteSpeed to apply the new configuration.');
            $this->redirectWithNotice($message, $configUrl);
        } catch (Exception $e) {
            $this->redirectWithError($e->getMessage(), $configUrl);
        }
    }

    public function consoleuserAction()
    {
        $this->requirePost();
        $settingsUrl = pm_Context::getActionUrl('index', 'settings');

        $user = trim((string) $this->_request->getPost('ols_console_user'));
        $password = (string) $this->_request->getPost('ols_console_password');

        try {
            $result = Ols_Manager::consoleUser($user, $password);
            $this->redirectWithNotice(
                Ols_L10n::t('Web admin console user {0} saved. Use this password to log in to the console.', array($result['user'])),
                $settingsUrl
            );
        } catch (Exception $e) {
            $this->redirectWithError($e->getMessage(), $settingsUrl);
        }
    }

    public function setupresetAction()
    {
        $this->requirePost();
        $settingsUrl = pm_Context::getActionUrl('index', 'settings');

        try {
            Ols_Manager::setupReset();
            $this->redirectWithNotice(
                Ols_L10n::t('The setup page will be shown again on the next visit.'),
                pm_Context::getActionUrl('index', 'wizard')
            );
        } catch (Exception $e) {
            $this->redirectWithError($e->getMessage(), $settingsUrl);
        }
    }

    public function settingsAction()
    {
        $info = $this->info();
        $console = isset($info['admin_console']) && is_array($info['admin_console']) ? $info['admin_console'] : array();

        $flash = $this->pullFlash();
        $this->view->notice = isset($flash['notice']) ? $flash['notice'] : null;
        $this->view->error = isset($flash['error']) ? $flash['error'] : null;
        $this->view->consoleUrl = $this->consoleUrl($console);
        $this->view->console = $console;
        $this->view->languages = Ols_L10n::available();
        $this->view->currentLanguage = Ols_L10n::locale();

        $form = new pm_Form_Simple();
        $form->addElement('text', 'ols_root', array(
            'label' => Ols_L10n::t('OpenLiteSpeed installation directory'),
            'value' => (string) pm_Settings::get('ols_root', ''),
            'required' => false,
            'description' => Ols_L10n::t('Leave empty for automatic detection (default: /usr/local/lsws). Set it only if OpenLiteSpeed is installed in a non-standard prefix.'),
        ));
        $form->addElement('text', 'ols_console_url', array(
            'label' => Ols_L10n::t('Web admin console address override'),
            'value' => (string) pm_Settings::get('ols_console_url', ''),
            'required' => false,
            'description' => Ols_L10n::t('Optional full URL, for example https://ols.example.com:7089/. Leave empty to build it from the detected console listener.'),
        ));
        $form->addElement('select', 'ols_language', array(
            'label' => Ols_L10n::t('Interface language'),
            'multiOptions' => Ols_L10n::available(),
            'value' => Ols_L10n::locale(),
            'description' => Ols_L10n::t('Follows the panel language by default. Picking a language here stores it for this module only.'),
        ));
        $form->addControlButtons(array(
            'cancelHidden' => true,
            'sendForm' => Ols_L10n::t('Save settings'),
        ));

        if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost())) {
            pm_Settings::set('ols_root', trim((string) $form->getValue('ols_root')));
            pm_Settings::set('ols_console_url', trim((string) $form->getValue('ols_console_url')));
            Ols_L10n::setLocale((string) $this->_request->getPost('ols_language'));
            $this->pushFlash('notice', Ols_L10n::t('Settings saved.'));
            $this->_helper->json(array('redirect' => pm_Context::getActionUrl('index', 'settings')));

            return;
        }

        $this->view->form = $form;
    }

    /**
     * The helper answers with one small JSON document for the gate, so ordinary
     * pages do not pay for a full domain scan.
     */
    private function setupGate()
    {
        if ($this->_setup !== null) {
            return $this->_setup;
        }

        try {
            $this->_setup = Ols_Manager::setupStatus(true);
        } catch (Exception $e) {
            $this->_setup = array('ok' => false, 'onboarded' => true, 'stage' => 'welcome',
                'running' => false, 'error' => $e->getMessage());
        }

        return $this->_setup;
    }

    private function wizardNeeded()
    {
        $action = (string) $this->_request->getActionName();
        if (in_array($action, array('wizard', 'setuprun', 'setupskip', 'setupreset'), true)) {
            return false;
        }
        // The wizard keeps its own address while it refreshes, even once the
        // setup has been recorded as finished.
        if ($this->_request->getParam('ols_wizard_state') !== null) {
            return false;
        }
        $gate = $this->setupGate();

        return empty($gate['onboarded']);
    }

    /**
     * Detection data shared by every page header.
     */
    private function uiData()
    {
        $info = $this->info();
        $console = isset($info['admin_console']) && is_array($info['admin_console']) ? $info['admin_console'] : array();
        $os = isset($info['os']) && is_array($info['os']) ? $info['os'] : array();

        return array(
            'installed' => !empty($info['installed']),
            'running' => !empty($info['state']['running']),
            'version' => isset($info['version']) ? $info['version'] : null,
            'root' => isset($info['root']) ? $info['root'] : null,
            'mode' => isset($info['engine_mode']) ? $info['engine_mode'] : 'unknown',
            'console' => $console,
            'console_url' => $this->consoleUrl($console),
            'os' => $os,
            'language' => Ols_L10n::locale(),
            'languages' => Ols_L10n::available(),
            'error' => $this->_infoError,
        );
    }

    private function info()
    {
        if ($this->_info !== null) {
            return $this->_info;
        }

        try {
            $this->_info = Ols_Manager::info();
        } catch (Exception $e) {
            $this->_infoError = $e->getMessage();
            $this->_info = array('installed' => false, 'state' => array('running' => false),
                'admin_console' => array(), 'os' => array(), 'engine_mode' => 'unknown');
        }

        return $this->_info;
    }

    /**
     * The console listens on its own port; the link is built from the address the
     * administrator is already using, so it works for both host names and IPs.
     */
    private function consoleUrl(array $console)
    {
        $override = trim((string) pm_Settings::get('ols_console_url', ''));
        if ($override !== '') {
            return $override;
        }
        if (empty($console['port'])) {
            return null;
        }

        $scheme = !empty($console['ssl']) ? 'https' : 'http';
        $host = '';
        if (!empty($_SERVER['HTTP_HOST'])) {
            $host = (string) parse_url('http://' . $_SERVER['HTTP_HOST'], PHP_URL_HOST);
        }
        if ($host === '' || $host === 'localhost') {
            $host = !empty($console['bind']) && strpos($console['bind'], ':') !== false
                && strpos($console['bind'], '*') !== 0
                ? explode(':', $console['bind'])[0]
                : '127.0.0.1';
        }

        return $scheme . '://' . $host . ':' . (int) $console['port'] . '/';
    }

    private function handleLanguageSwitch()
    {
        $requested = (string) $this->_request->getParam('ols_lang', '');
        if ($requested === '' || !Ols_L10n::setLocale($requested)) {
            return;
        }

        $target = (string) $this->_request->getParam('target', 'index');
        $allowed = array('index', 'wizard', 'webengine', 'vhosts', 'logs', 'config', 'settings');
        if (!in_array($target, $allowed, true)) {
            $target = 'index';
        }

        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();
        $this->getResponse()->setRedirect(pm_Context::getActionUrl('index', $target));
    }

    private function requirePost()
    {
        if (!$this->_request->isPost()) {
            throw new pm_Exception(Ols_L10n::t('Invalid request method.'));
        }

        if (!$this->isSameOrigin()) {
            throw new pm_Exception(Ols_L10n::t('Invalid request origin.'));
        }
    }

    /**
     * Every control in this module is a same-origin form, so a POST that arrived
     * from another site is a cross-site request and must never reach the root
     * helper. A request that carries no Origin and no Referer at all is accepted:
     * browsers send one on every form POST, and blocking it would only lock the
     * administrator out of the panel.
     */
    private function isSameOrigin()
    {
        $own = $this->hostWithoutPort(isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '');
        if ($own === null) {
            return true;
        }

        foreach (array('HTTP_ORIGIN', 'HTTP_REFERER') as $key) {
            if (empty($_SERVER[$key])) {
                continue;
            }
            $host = $this->hostWithoutPort(parse_url((string) $_SERVER[$key], PHP_URL_HOST));

            return $host === null || $host === $own;
        }

        return true;
    }

    private function hostWithoutPort($value)
    {
        $host = strtolower(trim((string) $value));
        if ($host === '') {
            return null;
        }
        if (strpos($host, '[') === 0) {
            $end = strrpos($host, ']');

            return $end === false ? $host : substr($host, 0, $end + 1);
        }
        $pos = strrpos($host, ':');

        return $pos === false ? $host : substr($host, 0, $pos);
    }

    private function redirectWithNotice($message, $url = null)
    {
        $this->pushFlash('notice', $message);
        $this->doRedirect($url === null ? pm_Context::getActionUrl('index', 'index') : $url);
    }

    private function redirectWithError($message, $url = null)
    {
        $this->pushFlash('error', $message);
        $this->doRedirect($url === null ? pm_Context::getActionUrl('index', 'index') : $url);
    }

    private function doRedirect($url)
    {
        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();
        $this->getResponse()->setRedirect($url);
    }

    private function pushFlash($type, $message)
    {
        $dir = $this->flashDir();
        file_put_contents($dir . '/flash.json', json_encode(array(
            $type => $this->shortenMessage($message),
        )), LOCK_EX);
    }

    private function pullFlash()
    {
        $file = $this->flashDir() . '/flash.json';
        if (!is_file($file)) {
            return array();
        }
        $data = json_decode((string) file_get_contents($file), true);
        @unlink($file);

        return is_array($data) ? $data : array();
    }

    private function flashDir()
    {
        $dir = pm_Context::getVarDir();
        if (!is_dir($dir)) {
            mkdir($dir, 0750, true);
        }

        return $dir;
    }

    private function shortenMessage($message)
    {
        $message = trim((string) $message);
        if (strlen($message) > 2000) {
            return substr($message, 0, 2000) . '...';
        }

        return $message;
    }
}

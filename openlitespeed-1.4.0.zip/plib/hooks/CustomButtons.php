<?php

class Modules_Openlitespeed_CustomButtons extends pm_Hook_CustomButtons
{
    public function getButtons()
    {
        return array(
            array(
                'place' => self::PLACE_ADMIN_NAVIGATION,
                'section' => self::SECTION_NAV_SERVER_MANAGEMENT,
                'title' => 'OpenLiteSpeed',
                'description' => 'Manage the OpenLiteSpeed web server and the Plesk web front',
                'icon' => pm_Context::getBaseUrl() . 'images/icon.svg',
                'link' => pm_Context::getBaseUrl() . 'index.php/index/index',
                'newWindow' => false,
                'order' => 15,
            ),
            array(
                'place' => self::PLACE_ADMIN_TOOLS_AND_SETTINGS,
                'section' => self::SECTION_ADMIN_TOOLS_SERVER_MANAGEMENT,
                'title' => 'OpenLiteSpeed',
                'description' => 'Manage the OpenLiteSpeed web server and the Plesk web front',
                'icon' => pm_Context::getBaseUrl() . 'images/icon.svg',
                'link' => pm_Context::getBaseUrl() . 'index.php/index/index',
                'newWindow' => false,
            ),
        );
    }
}

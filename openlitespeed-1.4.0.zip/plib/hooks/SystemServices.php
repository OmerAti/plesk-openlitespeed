<?php

require_once pm_Context::getPlibDir() . '/library/Ols/Service.php';

class Modules_Openlitespeed_SystemServices extends pm_Hook_SystemServices
{
    public function getServices()
    {
        return array(new Ols_Service());
    }
}

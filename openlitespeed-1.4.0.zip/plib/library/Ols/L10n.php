<?php

/**
 * Module translations. English is the source language and also the key, so a
 * missing phrase degrades to English instead of showing a raw key.
 *
 * The language follows the panel locale (pm_Locale::getCode()) unless the
 * administrator picks one explicitly on the Settings page.
 */
class Ols_L10n
{
    const SETTING = 'ols_language';

    private static $_locale = null;
    private static $_messages = null;

    public static function available()
    {
        return array(
            'en' => 'English',
            'tr' => 'Türkçe',
        );
    }

    public static function locale()
    {
        if (self::$_locale !== null) {
            return self::$_locale;
        }

        $saved = strtolower(trim((string) pm_Settings::get(self::SETTING, '')));
        $available = self::available();
        if (isset($available[$saved])) {
            return self::$_locale = $saved;
        }

        return self::$_locale = self::panelLocale();
    }

    public static function setLocale($code)
    {
        $code = strtolower(trim((string) $code));
        $available = self::available();
        if (!isset($available[$code])) {
            return false;
        }
        pm_Settings::set(self::SETTING, $code);
        self::$_locale = $code;
        self::$_messages = null;

        return true;
    }

    public static function t($text, array $params = array())
    {
        return self::translate($text, $params);
    }

    public static function translate($text, array $params = array())
    {
        $text = (string) $text;
        $locale = self::locale();
        if ($locale !== 'en') {
            self::load($locale);
            if (self::$_messages !== null) {
                if (isset(self::$_messages[$text])) {
                    $text = self::$_messages[$text];
                } else {
                    $text = self::translatePrefix($text);
                }
            }
        }

        if (count($params) > 0) {
            $search = array();
            $replace = array();
            foreach ($params as $key => $value) {
                $search[] = '{' . $key . '}';
                $replace[] = (string) $value;
            }
            $text = str_replace($search, $replace, $text);
        }

        return $text;
    }

    /**
     * Helper errors carry a dynamic tail (a path, a pid, test output), so only
     * the English prefix is swapped and the tail is left as the helper wrote it.
     */
    private static function translatePrefix($text)
    {
        $matched = '';
        $replacement = '';
        foreach (self::$_messages as $prefix => $value) {
            $last = substr($prefix, -1);
            if ($last !== ' ' && $last !== '(' && $last !== "\n") {
                continue;
            }
            $length = strlen($prefix);
            if ($length > strlen($matched) && strncmp($text, $prefix, $length) === 0) {
                $matched = $prefix;
                $replacement = $value;
            }
        }

        return $matched === '' ? $text : $replacement . substr($text, strlen($matched));
    }

    private static function panelLocale()
    {
        $code = '';
        if (class_exists('pm_Locale') && method_exists('pm_Locale', 'getCode')) {
            try {
                $code = strtolower((string) pm_Locale::getCode());
            } catch (Exception $e) {
                $code = '';
            }
        }
        if ($code === '') {
            foreach (array('HTTP_ACCEPT_LANGUAGE') as $header) {
                if (!empty($_SERVER[$header])) {
                    $code = strtolower(trim(explode(',', (string) $_SERVER[$header])[0]));
                    break;
                }
            }
        }

        return strpos($code, 'tr') === 0 ? 'tr' : 'en';
    }

    private static function load($locale)
    {
        if (self::$_messages !== null) {
            return;
        }

        $file = pm_Context::getPlibDir() . 'locales/' . $locale . '.php';
        if (!is_file($file)) {
            self::$_messages = array();

            return;
        }
        $messages = include $file;
        self::$_messages = is_array($messages) ? $messages : array();
    }
}

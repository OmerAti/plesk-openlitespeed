<?php

require_once pm_Context::getPlibDir() . '/library/Ols/Manager.php';

class Ols_Service extends pm_SystemService_Service
{
    public function getId()
    {
        return 'openlitespeed';
    }

    public function getName()
    {
        return 'OpenLiteSpeed';
    }

    public function onStart()
    {
        Ols_Manager::control('start');
    }

    public function onStop()
    {
        Ols_Manager::control('stop');
    }

    public function onRestart()
    {
        Ols_Manager::control('restart');
    }

    public function isRunning()
    {
        try {
            $info = Ols_Manager::info();

            return !empty($info['state']['running']);
        } catch (Exception $e) {
            return false;
        }
    }
}

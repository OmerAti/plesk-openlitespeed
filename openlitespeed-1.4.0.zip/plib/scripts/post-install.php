<?php
pm_Context::init('openlitespeed');

$varDir = pm_Context::getVarDir();
if (!is_dir($varDir)) {
    mkdir($varDir, 0750, true);
}

$moduleId = pm_Context::getModuleId();
$helpers = array(
    '/usr/local/psa/admin/bin/modules/' . $moduleId . '/openlitespeed',
    '/usr/local/psa/admin/sbin/modules/' . $moduleId . '/openlitespeed',
    '/usr/local/psa/admin/bin/modules/' . $moduleId . '/openlitespeed.php',
    '/usr/local/psa/admin/sbin/modules/' . $moduleId . '/openlitespeed.php',
);

foreach ($helpers as $helper) {
    if (file_exists($helper)) {
        chmod($helper, 0755);
    }
}

/*
 * The PHP pool for Plesk's own service hostnames moved out of the engine state
 * directory, because the OpenLiteSpeed worker has to reach its socket. Whatever
 * an older version left there belongs to nothing any more.
 */
foreach ((array) glob($varDir . '/engine/svc-fpm-*') as $stale) {
    if (is_file($stale)) {
        @unlink($stale);
    }
}

/*
 * Installing the extension is a fresh start for the welcome page: the record that
 * the administrator has been through it lives in this var directory, which
 * survives an upgrade in place. Without this the panel would go straight to the
 * dashboard after an install and never offer the one-click setup. An upgrade from
 * inside the OpenLiteSpeed page is marked by the helper and keeps that record, so
 * updating never throws the welcome page at somebody who already set the server up.
 */
$upgrading = false;
foreach (array(
    '/usr/local/psa/var/modules/openlitespeed/engine/upgrading.json',
    '/opt/psa/var/modules/openlitespeed/engine/upgrading.json',
) as $marker) {
    if (!is_file($marker)) {
        continue;
    }
    $data = json_decode((string) @file_get_contents($marker), true);
    @unlink($marker);
    $age = is_array($data) && isset($data['started']) ? time() - (int) strtotime((string) $data['started']) : null;
    $upgrading = $age !== null && $age >= 0 && $age <= 1800;
    break;
}

if (!$upgrading) {
    foreach (array('/engine/setup.json', '/engine/setup.log', '/engine/setup.pid', '/flash.json') as $relative) {
        if (is_file($varDir . $relative)) {
            @unlink($varDir . $relative);
        }
    }
}

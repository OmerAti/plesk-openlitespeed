<?php
/**
 * OpenLiteSpeed root helper for the Plesk "openlitespeed" extension.
 *
 * Executed by pm_ApiCli::callSbin() as root. Handles OpenLiteSpeed 1.8+
 * plain-text configuration (httpd_config.conf) as well as legacy XML files,
 * and implements the nginx <-> OpenLiteSpeed web front switch.
 * All results are printed as a single JSON document on stdout.
 *
 * Author: OmerAti - Omer ATABER
 */

error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);
set_time_limit(600);

const VALID_ACTIONS = array(
    'info', 'status', 'start', 'stop', 'restart', 'graceful', 'test',
    'vhosts', 'logs', 'config-list', 'config-get', 'config-save',
    'engine-status', 'engine-switch-ols', 'engine-switch-nginx', 'engine-sync',
    'engine-sync-check', 'engine-cron-install', 'engine-cron-remove', 'engine-revert',
    'front-active',
    'update-check', 'update-apply',
    'admin-console', 'admin-console-user',
    'setup-status', 'setup-run', 'setup-worker', 'setup-skip', 'setup-done', 'setup-reset',
);
const SETUP_ACTIONS = array('setup-status', 'setup-run', 'setup-worker', 'setup-skip', 'setup-done', 'setup-reset');
// Actions that answer correctly even when OpenLiteSpeed itself is gone.
const ROOT_FREE_ACTIONS = array('info', 'engine-revert', 'front-active', 'update-check', 'update-apply');
const SETUP_RUNNING_STAGES = array('installing', 'configuring', 'switching');
const SETUP_DONE_STAGES = array('ready', 'failed', 'skipped');
const SETUP_WORKER_TIMEOUT = 2400;
// The worker records its own process id within a second of starting; a running
// stage without any known worker for this long never started, so the wizard page
// must stop saying "setup is running" and show what the log holds instead.
const SETUP_WORKER_START_GRACE = 30;
const LOG_TYPES = array(
    'error', 'access', 'admin-error', 'admin-access', 'vhost-access', 'vhost-error',
);
const MAX_LOG_LINES = 2000;
const MAX_CONFIG_BYTES = 2097152;
const MAX_HEALTH_DOMAINS = 40;

const ADMIN_CONFIG_FILE = '/admin/conf/admin_config.conf';
const ADMIN_HTPASSWD_FILE = '/admin/conf/htpasswd';

const FRONT_MARKER_BEGIN = '# BEGIN PLESK OLS EXTENSION WEB FRONT';
const FRONT_MARKER_END = '# END PLESK OLS EXTENSION WEB FRONT';
const VHOST_PREFIX = 'pl-';
const EXTENGINE_DIR = '/usr/local/psa/var/modules/openlitespeed/engine';
const PLESK_NGINX_DIR = '/etc/nginx/plesk.conf.d';
const PLESK_SYSTEM_DIR = '/var/www/vhosts/system';
const PLESK_DEFAULT_DOCROOT = '/var/www/vhosts/default/htdocs';
const PLESK_WEB_GROUP = 'psaserv';
const FRONT_CRON_FILE = '/etc/cron.d/plesk-openlitespeed-front';
const FRONT_CRON_INTERVAL = '*/2 * * * *';

// Plesk wires webmail (and every product it installs the same way) onto its own
// hostnames outside the subscription vhosts, with its own certificate and its
// own PHP runtime user.
const PLESK_SERVICE_NGINX_DIR = '/etc/nginx/plesk.conf.d/webmails';
const PLESK_SERVICE_APACHE_DIRS = array(
    '/etc/httpd/conf/plesk.conf.d/webmails',
    '/etc/apache2/conf/plesk.conf.d/webmails',
);
const SERVICE_POOL_SLUG = 'svc-fpm';
// Sockets this extension starts live where the web group can reach them.
const SERVICE_POOL_DIR = '/usr/local/psa/var/run/openlitespeed';

// How a domain served by the OpenLiteSpeed front runs PHP.
const PHP_DIRECT = 'direct';
const PHP_BACKEND = 'backend';
const PHP_MODES = array(PHP_DIRECT, PHP_BACKEND);

// Proxy handler for the server hostname / Plesk panel vhost.
const PANEL_HANDLER = 'PleskPanelBackend';

// The author's own release file: { "version": "1.3.9", "url": "…zip", "notes": "…" }.
// Checking is an anonymous HTTPS GET; applying is Plesk's own upgrade command with
// a package that was verified to be this extension before it is installed.
const EXTENSION_ID = 'openlitespeed';
const UPDATE_FEED_URL = 'https://raw.githubusercontent.com/OmerAti/plesk-openlitespeed/refs/heads/main/update.json';
const UPDATE_CACHE_TTL = 21600;
const UPDATE_FAIL_TTL = 600;
const UPDATE_JSON_BYTES = 262144;
const UPDATE_ZIP_BYTES = 52428800;
const UPDATE_FETCH_TIMEOUT = 25;

// Official LiteSpeed package repositories, copied from the repository bootstrap
// at http://repo.litespeed.sh so the package manager is pointed at exactly the
// sets LiteSpeed itself publishes. A family that is not described here is
// reported as unsupported instead of guessing, so a live server's package
// manager configuration can never be filled with a made-up URL.
const OPENLITESPEED_PACKAGE = 'openlitespeed';
const OPENLITESPEED_RHEL_BASE = 'http://rpms.litespeedtech.com/centos/';
const OPENLITESPEED_RHEL_KEY_URL = 'http://rpms.litespeedtech.com/centos/RPM-GPG-KEY-litespeed';
// The 2025 key signs the newer builds; the bootstrap still installs it under the
// old file name, and so do we, because the repository file references one path.
const OPENLITESPEED_RHEL_KEY_URL_2025 = 'http://rpms.litespeedtech.com/centos/RPM-GPG-KEY-litespeed2025';
const OPENLITESPEED_RHEL_KEY_2025_FROM = 10;
const OPENLITESPEED_RHEL_KEY_FILE = '/etc/pki/rpm-gpg/RPM-GPG-KEY-litespeed';
const OPENLITESPEED_RHEL_IDS = array('rhel', 'redhat', 'centos', 'centosstream', 'almalinux',
    'rocky', 'cloudlinux', 'virtuozzo', 'scientific', 'oracledistribution', 'oel', 'ol');
// Major releases whose repository really carries a plain-text (1.8+) build.
const OPENLITESPEED_RHEL_MAJORS = array('8' => '8', '9' => '9', '10' => '10');
const OPENLITESPEED_RHEL_ARCHES = array('x86_64' => 'x86_64', 'aarch64' => 'aarch64');
// Distro channel the LiteSpeed PHP dependency packages need on RHEL family.
const OPENLITESPEED_RHEL_OPTIONAL_REPO = array('8' => 'powertools', '9' => 'crb', '10' => 'crb');
const OPENLITESPEED_DEBIAN_BASE = 'http://rpms.litespeedtech.com/debian/';
const OPENLITESPEED_DEBIAN_KEYS = array('lst_debian_repo.gpg', 'lst_repo.gpg');
const OPENLITESPEED_DEBIAN_TRUST_DIR = '/etc/apt/trusted.gpg.d';
const OPENLITESPEED_DEBIAN_CODENAMES = array('bionic', 'focal', 'jammy', 'noble',
    'bullseye', 'bookworm', 'trixie');
const OPENLITESPEED_DEBIAN_ARCHES = array('x86_64' => 'amd64', 'amd64' => 'amd64',
    'aarch64' => 'arm64', 'arm64' => 'arm64');
// The package pulls LiteSpeed's own PHP build as a dependency; the extension
// never uses it, PHP keeps running through the Plesk php-fpm pools.
const OPENLITESPEED_DEB_OPTIONS = array(
    '-o', 'Dpkg::Options::=--force-confdef',
    '-o', 'Dpkg::Options::=--force-confold',
);

function get_arg($argv, $name, $default = null)
{
    $prefix = '--' . $name . '=';
    foreach ($argv as $token) {
        if (strpos($token, $prefix) === 0) {
            return substr($token, strlen($prefix));
        }
    }

    return $default;
}

function emit($data, $code = 0)
{
    echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit($code);
}

function fail($message)
{
    emit(array('ok' => false, 'error' => $message), 1);
}

function run(array $cmd)
{
    $line = implode(' ', array_map('escapeshellarg', $cmd)) . ' 2>&1';
    $output = array();
    $code = 0;
    exec($line, $output, $code);

    return array($code, trim(implode("\n", $output)));
}

function detect_root()
{
    $candidates = array();
    $override = getenv('OLS_ROOT');
    if ($override !== false && $override !== '') {
        $candidates[] = rtrim($override, '/');
    }
    $candidates = array_merge($candidates, array(
        '/usr/local/lsws',
        '/usr/local/openlitespeed',
        '/opt/lsws',
    ));

    foreach ($candidates as $root) {
        if (!is_dir($root) || !is_dir($root . '/bin')) {
            continue;
        }
        if (file_exists($root . '/bin/lshttpd') || file_exists($root . '/bin/openlitespeed')) {
            return $root;
        }
    }

    return null;
}

function main_bin($root)
{
    if (file_exists($root . '/bin/lshttpd')) {
        return $root . '/bin/lshttpd';
    }
    if (file_exists($root . '/bin/openlitespeed')) {
        return $root . '/bin/openlitespeed';
    }

    return null;
}

function detect_version($root)
{
    $bin = main_bin($root);
    if ($bin === null) {
        return null;
    }
    foreach (array('-v', '-V') as $flag) {
        list($code, $out) = run(array($bin, $flag));
        if ($code === 0 && $out !== '' && stripos($out, 'usage') !== 0) {
            // The build stamp some releases append is noise in a status badge.
            $line = trim(preg_replace('/\((?:BUILD|built)[^)]*\)/i', '', explode("\n", $out)[0]), " \t.:,-");
            if ($line === '') {
                continue;
            }
            if (preg_match('#((?:Open)?LiteSpeed[ /]?[0-9][0-9a-zA-Z._-]*)#i', $line, $m)) {
                return trim($m[1], " \t.:,-");
            }

            return $line;
        }
    }

    return null;
}

function find_systemctl()
{
    foreach (array('/usr/bin/systemctl', '/bin/systemctl') as $candidate) {
        if (is_executable($candidate)) {
            return $candidate;
        }
    }

    return null;
}

function systemd_unit($root)
{
    $systemctl = find_systemctl();
    if ($systemctl === null) {
        return null;
    }
    foreach (array('litespeed', 'lsws', 'openlitespeed', 'lshttpd') as $unit) {
        list($code) = run(array($systemctl, 'cat', $unit . '.service'));
        if ($code === 0) {
            return $unit;
        }
    }

    return null;
}

function pid_file_candidates($root)
{
    return array(
        $root . '/logs/logs/httpd.pid',
        $root . '/logs/httpd.pid',
        '/run/litespeed.pid',
        '/var/run/litespeed.pid',
    );
}

function current_pid($root)
{
    foreach (pid_file_candidates($root) as $file) {
        if (!is_file($file)) {
            continue;
        }
        $pid = (int) trim((string) @file_get_contents($file));
        if ($pid > 0 && is_process_alive($pid, $root)) {
            return $pid;
        }
    }

    $bin = main_bin($root);
    // LiteSpeed rewrites its process titles ("openlitespeed (lshttpd - main)"),
    // so argv[0] no longer holds the binary path and a pgrep for it finds
    // nothing. The master title is the only handle that survives.
    foreach (array('lshttpd - main', $bin) as $pattern) {
        if ($pattern === null) {
            continue;
        }
        list($code, $out) = run(array('pgrep', '-f', $pattern));
        if ($code === 0 && $out !== '') {
            $lines = explode("\n", $out);
            $pid = (int) trim($lines[0]);
            if ($pid > 0 && is_process_alive($pid, $root)) {
                return $pid;
            }
        }
    }

    return null;
}

function send_signal($pid, $sig)
{
    if (function_exists('posix_kill')) {
        return @posix_kill($pid, $sig);
    }
    list($code) = run(array('kill', '-' . $sig, (string) $pid));

    return $code === 0;
}

function is_process_alive($pid, $root)
{
    $cmdline = @file_get_contents('/proc/' . $pid . '/cmdline');
    if ($cmdline === false) {
        return false;
    }
    $cmdline = str_replace("\0", ' ', $cmdline);

    return strpos($cmdline, 'lshttpd') !== false || strpos($cmdline, 'openlitespeed') !== false
        || ($root !== null && strpos($cmdline, $root) !== false);
}

function process_uptime($pid)
{
    $stat = @file_get_contents('/proc/' . $pid . '/stat');
    if ($stat === false) {
        return null;
    }
    $afterComm = substr($stat, strrpos($stat, ')') + 1);
    $fields = preg_split('/\s+/', trim($afterComm));
    if (!isset($fields[19])) {
        return null;
    }
    $starttime = (int) $fields[19];
    $btime = null;
    foreach (explode("\n", (string) @file_get_contents('/proc/stat')) as $line) {
        if (strpos($line, 'btime ') === 0) {
            $btime = (int) substr($line, 6);
            break;
        }
    }
    if ($btime === null) {
        return null;
    }
    $started = $btime + (int) ($starttime / 100);

    return max(0, time() - $started);
}

function format_duration($seconds)
{
    if ($seconds === null) {
        return null;
    }
    $days = (int) ($seconds / 86400);
    $seconds %= 86400;
    $parts = array();
    if ($days > 0) {
        $parts[] = $days . 'd';
    }
    $parts[] = gmdate('H:i:s', $seconds);

    return implode(' ', $parts);
}

/*
 * ---------------------------------------------------------------------------
 * Configuration parsing: OpenLiteSpeed 1.8+ plain text, with XML fallback.
 * ---------------------------------------------------------------------------
 */

function main_config_file($root)
{
    if (is_file($root . '/conf/httpd_config.conf')) {
        return $root . '/conf/httpd_config.conf';
    }
    if (is_file($root . '/conf/httpd_config.xml')) {
        return $root . '/conf/httpd_config.xml';
    }

    return $root . '/conf/httpd_config.conf';
}

function is_plain_config($root)
{
    return is_file($root . '/conf/httpd_config.conf');
}

function extract_top_blocks($text, $keyword)
{
    $blocks = array();
    $lines = explode("\n", $text);
    $count = count($lines);
    $i = 0;
    $pattern = '/^' . preg_quote($keyword, '/') . '[ \t]+([^{\n]+?)[ \t]*\{/i';
    while ($i < $count) {
        if (preg_match($pattern, $lines[$i], $m)) {
            $name = trim($m[1]);
            $body = array();
            $depth = 1;
            $i++;
            while ($i < $count && $depth > 0) {
                $line = $lines[$i];
                $opens = substr_count($line, '{');
                $closes = substr_count($line, '}');
                $depth += $opens - $closes;
                if ($depth < 0) {
                    $depth = 0;
                }
                if ($depth > 0) {
                    $body[] = $line;
                }
                $i++;
            }
            $blocks[] = array('name' => $name, 'body' => implode("\n", $body));
            continue;
        }
        $i++;
    }

    return $blocks;
}

function block_field($body, $field)
{
    if (preg_match('/^[ \t]*' . preg_quote($field, '/') . '[ \t]+([^\n]*)$/m', $body, $m)) {
        return trim($m[1]);
    }

    return null;
}

function block_all($body, $field)
{
    $values = array();
    if (preg_match_all('/^[ \t]*' . preg_quote($field, '/') . '[ \t]+([^\n]*)$/m', $body, $m)) {
        foreach ($m[1] as $value) {
            $values[] = trim($value);
        }
    }

    return $values;
}

function parse_listeners_plain($root)
{
    $text = (string) @file_get_contents(main_config_file($root));
    $listeners = array();
    foreach (extract_top_blocks($text, 'listener') as $block) {
        $maps = array();
        foreach (block_all($block['body'], 'map') as $map) {
            $parts = preg_split('/\s+/', $map);
            if (isset($parts[0])) {
                $maps[] = array('vhost' => $parts[0], 'domains' => isset($parts[1]) ? $parts[1] : '*');
            }
        }
        $listeners[] = array(
            'name' => $block['name'],
            'address' => block_field($block['body'], 'address'),
            'ssl' => block_field($block['body'], 'secure') === '1',
            'maps' => $maps,
        );
    }

    return $listeners;
}

function parse_listeners($root)
{
    if (is_plain_config($root)) {
        return parse_listeners_plain($root);
    }
    $file = $root . '/conf/httpd_config.xml';
    if (!is_file($file)) {
        return array();
    }
    $xml = @simplexml_load_file($file);
    if ($xml === false) {
        return array();
    }
    $listeners = array();
    foreach ($xml->children() as $name => $node) {
        if ($name !== 'listener') {
            continue;
        }
        $listeners[] = array(
            'name' => isset($node->name) ? (string) $node->name : '',
            'address' => isset($node->address) ? (string) $node->address : '',
            'ssl' => isset($node->ssl->enable) && (string) $node->ssl->enable === '1',
            'maps' => array(),
        );
    }

    return $listeners;
}

function list_vhosts_plain($root)
{
    $text = (string) @file_get_contents(main_config_file($root));
    $vhosts = array();
    foreach (extract_top_blocks($text, 'virtualHost') as $block) {
        $name = $block['name'];
        if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9._-]*$/', $name)) {
            continue;
        }
        $configRel = block_field($block['body'], 'configFile');
        $config = $configRel !== null
            ? (strpos($configRel, '/') === 0 ? $configRel : $root . '/' . ltrim($configRel, '/'))
            : $root . '/conf/vhosts/' . $name . '/vhconf.conf';
        $vhRootRel = block_field($block['body'], 'vhRoot');
        $vhRoot = $vhRootRel !== null
            ? (strpos($vhRootRel, '/') === 0 ? rtrim($vhRootRel, '/') : rtrim($root . '/' . ltrim($vhRootRel, '/'), '/'))
            : $root . '/' . $name;
        $entry = array(
            'name' => $name,
            'config' => $config,
            'docRoot' => null,
            'vhRoot' => $vhRoot,
            'errorLog' => $vhRoot . '/logs/error.log',
            'accessLog' => $vhRoot . '/logs/access.log',
            'ssl' => false,
        );
        if (is_file($config)) {
            $vhText = (string) @file_get_contents($config);
            $docRoot = block_field($vhText, 'docRoot');
            if ($docRoot !== null) {
                $entry['docRoot'] = expand_vh_vars($root, $vhRoot, $docRoot);
            }
            if (preg_match('/^[ \t]*vhssl[ \t]*\{/m', $vhText)) {
                $entry['ssl'] = true;
            }
        }
        $vhosts[] = $entry;
    }
    usort($vhosts, 'ols_sort_by_name');

    return $vhosts;
}

function ols_sort_by_name($a, $b)
{
    return strcmp($a['name'], $b['name']);
}

function expand_vh_vars($root, $vhRoot, $value)
{
    return str_replace(
        array('$VH_ROOT', '$SERVER_ROOT', '$DOC_ROOT'),
        array($vhRoot, $root, $vhRoot . '/html'),
        (string) $value
    );
}

function list_vhosts($root)
{
    if (is_plain_config($root)) {
        return list_vhosts_plain($root);
    }
    $dir = $root . '/conf/vhosts';
    if (!is_dir($dir)) {
        return array();
    }
    $vhosts = array();
    foreach ((array) glob($dir . '/*', GLOB_ONLYDIR) as $path) {
        $name = basename($path);
        if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9._-]*$/', $name)) {
            continue;
        }
        $confFile = $path . '/vhost.conf';
        if (!is_file($confFile)) {
            $confFile = $path . '/vhconf.conf';
        }
        $entry = array(
            'name' => $name,
            'config' => $confFile,
            'docRoot' => null,
            'vhRoot' => $root . '/vhosts/' . $name,
            'errorLog' => $root . '/logs/vhosts/' . $name . '/error_log',
            'accessLog' => $root . '/logs/vhosts/' . $name . '/access_log',
            'ssl' => false,
        );
        if (is_file($confFile)) {
            $xml = @simplexml_load_file($confFile);
            if ($xml !== false && isset($xml->vhRoot)) {
                $entry['vhRoot'] = expand_vh_vars($root, $root . '/vhosts/' . $name, $xml->vhRoot);
            }
            if ($xml !== false && isset($xml->docRoot)) {
                $entry['docRoot'] = expand_vh_vars($root, $entry['vhRoot'], $xml->docRoot);
            }
            if ($xml !== false && isset($xml->ssl)) {
                $entry['ssl'] = isset($xml->ssl->enable) && (string) $xml->ssl->enable === '1';
            }
        }
        $vhosts[] = $entry;
    }
    usort($vhosts, 'ols_sort_by_name');

    return $vhosts;
}

function vhost_root_of($root, $vhostName)
{
    foreach (list_vhosts($root) as $entry) {
        if ($entry['name'] === $vhostName && !empty($entry['vhRoot'])) {
            return rtrim($entry['vhRoot'], '/');
        }
    }

    return $root . '/vhosts/' . $vhostName;
}

/**
 * OpenLiteSpeed writes its logs under several possible layouts depending on the
 * distribution, the version and on what each vhost configures, so every known
 * spelling is tried and the first existing file wins.
 */
function log_candidates($root, $type, $vhost)
{
    $names = function ($base) {
        return array($base . '.log', $base . '_log');
    };

    switch ($type) {
        case 'error':
            return array_merge($names($root . '/logs/error'), $names($root . '/logs/logs/error'));
        case 'access':
            return array_merge($names($root . '/logs/access'), $names($root . '/logs/logs/access'));
        case 'admin-error':
            return $names($root . '/admin/logs/error');
        case 'admin-access':
            return $names($root . '/admin/logs/access');
        case 'vhost-access':
        case 'vhost-error':
            $which = $type === 'vhost-access' ? 'access' : 'error';
            $vhRoot = vhost_root_of($root, $vhost);

            return array_merge(
                $names($vhRoot . '/logs/' . $which),
                $names($root . '/vhosts/' . $vhost . '/logs/' . $which),
                $names($root . '/logs/vhosts/' . $vhost . '/' . $which)
            );
    }

    return array();
}

function log_path($root, $type, $vhost)
{
    $candidates = log_candidates($root, $type, $vhost);
    if (count($candidates) === 0) {
        fail('Unknown log type.');
    }
    foreach ($candidates as $candidate) {
        if (is_file($candidate)) {
            return $candidate;
        }
    }

    return $candidates[0];
}

function tail_file($path, $lines)
{
    if (!is_file($path)) {
        return null;
    }
    $handle = @fopen($path, 'rb');
    if ($handle === false) {
        fail('Unable to read log file: ' . $path);
    }
    $chunk = 8192;
    $position = filesize($path);
    $data = '';
    $found = 0;
    while ($position > 0 && $found <= $lines) {
        $read = min($chunk, $position);
        $position -= $read;
        fseek($handle, $position);
        $block = fread($handle, $read);
        $data = $block . $data;
        $found = substr_count($data, "\n");
    }
    fclose($handle);
    $all = explode("\n", rtrim($data, "\n"));
    if (count($all) > $lines) {
        $all = array_slice($all, -$lines);
    }

    return implode("\n", $all);
}

/** Keep a package manager transcript short enough to live in one log line. */
function tail_text($text, $limit = 300)
{
    $text = trim(preg_replace('/\s+/', ' ', (string) $text));

    return strlen($text) > $limit ? '...' . substr($text, -$limit) : $text;
}

function config_file_for_key($root, $key)
{
    if ($key === 'main') {
        return main_config_file($root);
    }
    if (strpos($key, 'vhost-') === 0) {
        $name = substr($key, 6);
        if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9._-]*$/', $name)) {
            fail('Invalid vhost configuration key.');
        }
        foreach (array('vhconf.conf', 'vhost.conf') as $candidateName) {
            $candidate = $root . '/conf/vhosts/' . $name . '/' . $candidateName;
            if (is_file($candidate)) {
                return $candidate;
            }
        }

        return $root . '/conf/vhosts/' . $name . '/vhconf.conf';
    }
    if ($key === 'admin-context') {
        foreach (array('admin_config.conf', 'admin_config.xml') as $candidateName) {
            $candidate = $root . '/admin/conf/' . $candidateName;
            if (is_file($candidate)) {
                return $candidate;
            }
        }

        return $root . '/admin/conf/admin_config.conf';
    }

    fail('Unknown configuration key.');
}

function jail_path($root, $path)
{
    $confDir = realpath($root . '/conf');
    $real = realpath($path);
    if ($confDir === false || $real === false) {
        fail('Configuration file not found.');
    }
    $confDir = str_replace('\\', '/', $confDir);
    $real = str_replace('\\', '/', $real);
    if ($real !== $confDir && strpos($real, $confDir . '/') !== 0) {
        fail('Refusing to touch a path outside the OpenLiteSpeed configuration directory.');
    }

    return $real;
}

function config_error_lines($out)
{
    $errors = array();
    foreach (explode("\n", $out) as $line) {
        if (strpos($line, '[ERROR]') !== false) {
            $errors[] = trim($line);
        }
    }

    return $errors;
}

function test_config($root)
{
    $bin = main_bin($root);
    if ($bin === null) {
        return array(null, 'No lshttpd binary found; configuration test skipped.');
    }
    list($code, $out) = run(array($bin, '-t'));
    if ($out === '') {
        return array(null, 'This OpenLiteSpeed build does not support "-t"; configuration test skipped.');
    }

    return array($code, $out);
}

function do_control($root, $action)
{
    $lswsctrl = $root . '/bin/lswsctrl';
    if ($action === 'graceful') {
        $pid = current_pid($root);
        if ($pid !== null && send_signal($pid, 10)) {
            sleep(2);
            if (is_process_alive($pid, $root)) {
                return array('method' => 'sigusr1', 'pid' => $pid);
            }

            return do_control($root, 'restart');
        }
    }

    if (file_exists($lswsctrl)) {
        // lswsctrl has no "graceful" verb; "reload" is its graceful restart.
        $verb = $action === 'graceful' ? 'reload' : $action;
        list($code, $out) = run(array($lswsctrl, $verb));
        if ($code !== 0 && !($action === 'stop' && current_pid($root) === null)) {
            fail(ucfirst($action) . ' failed: ' . ($out !== '' ? $out : 'exit code ' . $code));
        }

        return array('method' => 'lswsctrl');
    }

    $unit = systemd_unit($root);
    $systemctl = find_systemctl();
    if ($unit !== null && $systemctl !== null) {
        $verb = $action === 'graceful' ? 'reload' : $action;
        list($code, $out) = run(array($systemctl, $verb, $unit));
        if ($code !== 0) {
            fail(ucfirst($action) . ' failed: ' . ($out !== '' ? $out : 'exit code ' . $code));
        }

        return array('method' => 'systemctl', 'unit' => $unit);
    }

    if ($action === 'stop') {
        $pid = current_pid($root);
        if ($pid === null) {
            return array('method' => 'none', 'note' => 'Already stopped.');
        }
        if (!send_signal($pid, 15)) {
            fail('Failed to send SIGTERM to OpenLiteSpeed (pid ' . $pid . ').');
        }
        for ($i = 0; $i < 15; $i++) {
            if (!is_process_alive($pid, $root)) {
                return array('method' => 'sigterm');
            }
            sleep(1);
        }
        fail('OpenLiteSpeed did not stop within 15 seconds.');
    }

    fail('No supported way to control OpenLiteSpeed was found (neither lswsctrl nor a systemd unit exists).');
}

function try_control($root, $action)
{
    $lswsctrl = $root . '/bin/lswsctrl';
    if (file_exists($lswsctrl)) {
        list($code, $out) = run(array($lswsctrl, $action));

        return array($code === 0, $out);
    }
    $unit = systemd_unit($root);
    $systemctl = find_systemctl();
    if ($unit !== null && $systemctl !== null) {
        list($code, $out) = run(array($systemctl, $action, $unit));

        return array($code === 0, $out);
    }

    return array(false, 'No supported control method for OpenLiteSpeed.');
}

function service_state($root)
{
    $pid = $root !== null ? current_pid($root) : null;
    $uptime = null;
    $workers = null;
    if ($pid !== null) {
        $uptime = process_uptime($pid);
        $children = 0;
        foreach ((array) glob('/proc/[0-9]*/stat') as $statFile) {
            $stat = @file_get_contents($statFile);
            if ($stat === false) {
                continue;
            }
            $afterComm = substr($stat, strrpos($stat, ')') + 1);
            $fields = preg_split('/\s+/', trim($afterComm));
            if (isset($fields[1]) && (int) $fields[1] === $pid) {
                $children++;
            }
        }
        $workers = $children;
    }

    return array(
        'running' => $pid !== null,
        'pid' => $pid,
        'uptime_seconds' => $uptime,
        'uptime' => format_duration($uptime),
        'worker_processes' => $workers,
    );
}

function action_info($root)
{
    $lswsctrl = $root !== null && file_exists($root . '/bin/lswsctrl');
    $unit = $root !== null ? systemd_unit($root) : null;
    $engine = engine_read_state();

    return array(
        'ok' => true,
        'installed' => $root !== null,
        'root' => $root,
        'config_format' => $root !== null ? (is_plain_config($root) ? 'plain' : 'xml') : null,
        'version' => $root !== null ? detect_version($root) : null,
        'state' => $root !== null ? service_state($root) : array('running' => false, 'pid' => null, 'uptime' => null, 'uptime_seconds' => null, 'worker_processes' => null),
        'control' => array(
            'lswsctrl' => $lswsctrl,
            'systemd_unit' => $unit,
        ),
        'listeners' => $root !== null ? parse_listeners($root) : array(),
        'vhost_count' => $root !== null ? count(list_vhosts($root)) : 0,
        'engine_mode' => isset($engine['mode']) ? $engine['mode'] : 'unknown',
        'logs' => $root !== null ? array(
            'error' => log_path($root, 'error', null),
            'access' => log_path($root, 'access', null),
            'admin_error' => log_path($root, 'admin-error', null),
        ) : array(),
        'php_fpm_pools' => plesk_php_fpm_pool_count(),
        'os' => os_info(),
        'apache_service' => apache_service_name(),
        'nginx_service' => nginx_service_name(),
        'admin_console' => $root !== null ? admin_console_info($root)
            : array('configured' => false, 'users' => array(), 'has_user' => false, 'reachable' => false),
    );
}

function action_config_list($root)
{
    $files = array();
    $main = main_config_file($root);
    if (is_file($main)) {
        $stat = stat($main);
        $files[] = array('key' => 'main', 'label' => 'Main server (' . basename($main) . ')', 'path' => $main, 'size' => $stat['size'], 'mtime' => date('Y-m-d H:i:s', $stat['mtime']));
    }
    foreach (list_vhosts($root) as $vhost) {
        if (is_file($vhost['config'])) {
            $stat = stat($vhost['config']);
            $files[] = array(
                'key' => 'vhost-' . $vhost['name'],
                'label' => 'VHost: ' . $vhost['name'],
                'path' => $vhost['config'],
                'size' => $stat['size'],
                'mtime' => date('Y-m-d H:i:s', $stat['mtime']),
            );
        }
    }

    return array('ok' => true, 'files' => $files);
}

function action_config_get($root, $key)
{
    $path = config_file_for_key($root, $key);
    if (strpos($path, $root . '/admin/') === 0) {
        if (!is_file($path)) {
            fail('Configuration file not found: ' . $path);
        }
    } else {
        $path = jail_path($root, $path);
    }
    if (!is_file($path)) {
        fail('Configuration file not found: ' . $path);
    }
    $content = file_get_contents($path);
    $stat = stat($path);

    return array(
        'ok' => true,
        'key' => $key,
        'path' => $path,
        'content' => $content,
        'size' => $stat['size'],
        'mtime' => date('Y-m-d H:i:s', $stat['mtime']),
    );
}

function action_config_save($root, $key, $payloadB64)
{
    if ($payloadB64 === null) {
        fail('Missing --payload for config-save.');
    }
    $content = base64_decode($payloadB64, true);
    if ($content === false) {
        fail('Payload is not valid base64.');
    }
    if (strlen($content) > MAX_CONFIG_BYTES) {
        fail('Configuration file is too large (limit: 2 MB).');
    }
    if (trim($content) === '') {
        fail('The configuration file is empty.');
    }
    if (strpos($content, "\0") !== false) {
        fail('The configuration contains binary data.');
    }
    if (strpos(ltrim($content), '<') === 0 && substr($key, 0, 5) !== 'vhost') {
        $previous = libxml_use_internal_errors(true);
        if (@simplexml_load_string($content) === false) {
            $errors = libxml_get_errors();
            libxml_clear_errors();
            libxml_use_internal_errors($previous);
            $detail = isset($errors[0]) ? trim($errors[0]->message) : 'unknown XML error';
            fail('XML syntax error: ' . $detail);
        }
        libxml_use_internal_errors($previous);
    }

    $path = config_file_for_key($root, $key);
    if (strpos($path, $root . '/admin/') === 0) {
        if (!is_file($path)) {
            fail('Target configuration file disappeared: ' . $path);
        }
    } else {
        $path = jail_path($root, $path);
    }
    if (!is_file($path)) {
        fail('Target configuration file disappeared: ' . $path);
    }

    $backup = $path . '.ols-bak-' . date('YmdHis');
    if (!copy($path, $backup)) {
        fail('Failed to create a backup at ' . $backup);
    }
    @chmod($backup, 0600);

    $tmp = dirname($path) . '/.ols-tmp-' . substr(md5(uniqid('', true)), 0, 10);
    if (file_put_contents($tmp, $content) === false) {
        @unlink($backup);
        fail('Failed to stage the new configuration.');
    }
    $oldStat = stat($path);
    @chmod($tmp, $oldStat['mode'] & 07777);

    if (!rename($tmp, $path)) {
        @unlink($tmp);
        @unlink($backup);
        fail('Failed to install the new configuration.');
    }

    if ($key !== 'admin-context') {
        list($testCode, $testOut) = test_config($root);
        $testErrors = $testCode === null ? array() : config_error_lines($testOut);
        if (count($testErrors) > 0) {
            if (!copy($backup, $path)) {
                fail('Configuration test failed AND rollback failed! Restore manually from ' . $backup);
            }
            @unlink($backup);
            fail("The new configuration failed the 'lshttpd -t' check and was rolled back.\n\nTest errors:\n" . implode("\n", $testErrors));
        }
    } else {
        $testOut = 'Admin configuration is applied when the admin service restarts.';
    }

    return array(
        'ok' => true,
        'path' => $path,
        'backup' => $backup,
        'test_output' => $testOut,
        'needs_restart' => true,
    );
}

/*
 * ---------------------------------------------------------------------------
 * Web engine switch: OpenLiteSpeed front <-> nginx front (Apache backend)
 * ---------------------------------------------------------------------------
 */

function engine_state_file()
{
    return EXTENGINE_DIR . '/state.json';
}

function try_full_restart($root)
{
    $out = '';
    if (service_state($root)['running']) {
        list(, $out) = try_control($root, 'stop');
        for ($i = 0; $i < 10; $i++) {
            if (!service_state($root)['running']) {
                break;
            }
            sleep(1);
        }
    }
    list(, $startOut) = try_control($root, 'start');
    sleep(1);

    return array(service_state($root)['running'], trim($out . ' ' . $startOut));
}

function engine_read_state()
{
    $file = engine_state_file();
    if (!is_file($file)) {
        return array('mode' => 'unknown');
    }
    $data = json_decode((string) @file_get_contents($file), true);

    return is_array($data) ? $data : array('mode' => 'unknown');
}

function engine_write_state(array $state)
{
    if (!is_dir(EXTENGINE_DIR)) {
        @mkdir(EXTENGINE_DIR, 0750, true);
    }
    $state['updated'] = date('c');
    @file_put_contents(
        engine_state_file(),
        json_encode($state, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES),
        LOCK_EX
    );
    @chmod(engine_state_file(), 0640);

    return $state;
}

function nginx_service_name()
{
    $systemctl = find_systemctl();
    if ($systemctl !== null) {
        list($code) = run(array($systemctl, 'cat', 'nginx.service'));
        if ($code === 0) {
            return 'nginx';
        }
    }
    foreach (array('/etc/init.d/nginx', '/usr/sbin/nginx', '/sbin/nginx') as $path) {
        if (file_exists($path)) {
            return 'nginx';
        }
    }

    return null;
}

/**
 * Apache is "httpd" on the RPM family (AlmaLinux/RHEL/CentOS/CloudLinux/Rocky/
 * Oracle/Fedora/Amazon) and "apache2" on the Debian family (Debian/Ubuntu).
 * Plesk supports both, so the unit name is always probed, never assumed.
 */
function apache_service_name()
{
    static $resolved = false;
    static $name = null;
    if ($resolved) {
        return $name;
    }
    $resolved = true;

    $systemctl = find_systemctl();
    if ($systemctl !== null) {
        foreach (array('httpd', 'apache2') as $unit) {
            list($code) = run(array($systemctl, 'cat', $unit . '.service'));
            if ($code === 0) {
                return $name = $unit;
            }
        }
    }
    foreach (array('httpd' => '/etc/httpd', 'apache2' => '/etc/apache2') as $unit => $dir) {
        if (is_dir($dir) || is_file('/etc/init.d/' . $unit)) {
            return $name = $unit;
        }
    }

    return $name = null;
}

function os_info()
{
    static $info = null;
    if ($info !== null) {
        return $info;
    }

    $info = array('id' => null, 'name' => null, 'version' => null, 'family' => null, 'codename' => null);
    $families = array(
        'rhel' => array('rhel', 'centos', 'almalinux', 'rocky', 'cloudlinux', 'virtuozzo',
            'oracledistribution', 'oracle', 'scientific', 'fedora', 'amzn', 'oel'),
        'debian' => array('debian', 'ubuntu', 'linuxmint', 'kasos'),
        'suse' => array('sles', 'opensuse-leap', 'opensuse', 'sled'),
    );

    foreach (array('/etc/os-release', '/usr/lib/os-release') as $file) {
        if (!is_file($file)) {
            continue;
        }
        $text = (string) @file_get_contents($file);
        $fields = array();
        foreach (array('ID', 'ID_LIKE', 'NAME', 'VERSION_ID', 'VERSION_CODENAME') as $key) {
            if (preg_match('/^' . $key . '="?([^"\n]+)"?/m', $text, $m)) {
                // NAME is shown to the administrator, so it keeps the release's own
                // casing; everything else has to match repository metadata.
                $fields[$key] = $key === 'NAME' ? trim($m[1]) : strtolower(trim($m[1]));
            }
        }
        $info['id'] = isset($fields['ID']) ? $fields['ID'] : null;
        $info['name'] = isset($fields['NAME']) ? trim($fields['NAME']) : null;
        $info['version'] = isset($fields['VERSION_ID']) ? $fields['VERSION_ID'] : null;
        $info['codename'] = isset($fields['VERSION_CODENAME']) ? $fields['VERSION_CODENAME'] : null;

        $candidates = array();
        if (isset($fields['ID'])) {
            $candidates[] = $fields['ID'];
        }
        if (isset($fields['ID_LIKE'])) {
            $candidates = array_merge($candidates, preg_split('/\s+/', $fields['ID_LIKE']));
        }
        foreach ($families as $family => $members) {
            foreach ($candidates as $candidate) {
                if (in_array($candidate, $members, true)) {
                    $info['family'] = $family;
                    break 2;
                }
            }
        }
        if ($info['family'] !== null) {
            break;
        }
        if ($info['id'] !== null) {
            break;
        }
    }

    return $info;
}

function service_active($name)
{
    $systemctl = find_systemctl();
    if ($systemctl === null || $name === null) {
        return null;
    }
    list(, $out) = run(array($systemctl, 'is-active', $name));

    return trim($out) === 'active';
}

/**
 * The Apache/nginx drop-in Plesk maintains for one subscription or domain alias,
 * in the order they are most reliably present on the supported distributions.
 */
function plesk_conf_candidates($pleskKey)
{
    if (!preg_match('/^[a-zA-Z0-9][a-zA-Z0-9._-]*$/', (string) $pleskKey)) {
        return array();
    }

    return array(
        PLESK_SYSTEM_DIR . '/' . $pleskKey . '/conf/httpd.conf',
        '/etc/httpd/conf/plesk.conf.d/vhosts/' . $pleskKey . '.conf',
        '/etc/apache2/conf/plesk.conf.d/vhosts/' . $pleskKey . '.conf',
        '/etc/apache2/sites-enabled/' . $pleskKey . '.conf',
    );
}

/**
 * The real document root Plesk generated for one subscription or domain alias.
 * Plesk's own per-domain file is authoritative and always present, the Apache
 * drop-in is only used when that file was rotated away.
 */
function plesk_docroot($pleskKey)
{
    foreach (plesk_conf_candidates($pleskKey) as $file) {
        if (!is_file($file)) {
            continue;
        }
        $text = (string) @file_get_contents($file);
        if (preg_match('/DocumentRoot\s+"?([^\s"]+)"?/i', $text, $m)) {
            $path = rtrim($m[1], '/');
            if ($path !== '' && strpos($path, '/') === 0 && is_dir($path)) {
                return $path;
            }
        }
    }

    return null;
}

/**
 * The php-fpm pool that serves PHP for this domain today. Plesk keeps the socket
 * under the subscription directory, and a domain alias reaches the same pool
 * through the path its own nginx and Apache blocks already reference, so those
 * are the fallbacks instead of assuming a layout.
 */
function plesk_php_socket($pleskKey, $nginxText = '')
{
    $direct = PLESK_SYSTEM_DIR . '/' . $pleskKey . '/php-fpm.sock';
    if (file_exists($direct)) {
        return $direct;
    }

    $candidates = array();
    if (preg_match('#fastcgi_pass\s+unix:(/[^\s;"\']+)#i', $nginxText, $m)) {
        $candidates[] = $m[1];
    }
    foreach (plesk_conf_candidates($pleskKey) as $file) {
        if (!is_file($file)) {
            continue;
        }
        if (preg_match('#proxy:unix:([^\|\s"]+)#i', (string) @file_get_contents($file), $m)) {
            $candidates[] = $m[1];
        }
    }

    foreach ($candidates as $path) {
        $path = rtrim($path, '/');
        // A unix socket is not a regular file, so is_file() rejects every pool.
        if ($path !== '' && substr($path, -5) === '.sock' && file_exists($path)) {
            return $path;
        }
    }

    return null;
}

/**
 * Plesk starts one php-fpm pool per domain that uses php-fpm; the dashboard
 * reports those pools instead of an lsphp/lsapi package check.
 */
function plesk_php_fpm_pool_count()
{
    $found = @glob(PLESK_SYSTEM_DIR . '/*/php-fpm.sock');

    return $found === false ? 0 : count($found);
}

/**
 * Files of the php-fpm pool this extension runs for a Plesk service hostname.
 * One pool per (user, group, PHP binary, php.ini) combination, so every webmail
 * hostname on the server shares a single pool.
 *
 * They live in their own directory, not in the engine state directory: the
 * OpenLiteSpeed worker that connects to the socket runs as nobody:psaserv and has
 * to be able to reach it. Root owns the directory and the web group gets search
 * permission only, exactly like Plesk's own /var/www/vhosts/system/<domain>, so
 * nothing inside is listable by anybody but root.
 */
function service_pool_prefix($key)
{
    $dir = SERVICE_POOL_DIR;
    if (!is_dir($dir)) {
        @mkdir($dir, 0710, true);
        @chgrp($dir, PLESK_WEB_GROUP);
        @chmod($dir, 0710);
    }

    return $dir . '/' . SERVICE_POOL_SLUG . '-' . $key;
}

/**
 * The php-fpm binary behind Plesk's own "plesk-php<major><minor>-fastcgi"
 * handler id, with the plain OS package as fallback.
 */
function service_php_binary($handlerIndex)
{
    $candidates = array();
    if (preg_match('/^plesk-php(\d+)-/', (string) $handlerIndex, $m)) {
        $digits = $m[1];
        if (strlen($digits) >= 2) {
            $version = substr($digits, 0, strlen($digits) - 1) . '.' . substr($digits, -1);
            $candidates[] = '/opt/plesk/php/' . $version . '/sbin/php-fpm';
            $candidates[] = '/opt/alt/php' . $digits . '/usr/sbin/php-fpm';
        }
    }
    $candidates[] = '/usr/sbin/php-fpm';

    foreach ($candidates as $path) {
        if (is_file($path) && is_executable($path)) {
            return $path;
        }
    }

    return null;
}

function service_apache_dropin($base)
{
    if (!preg_match('/^[a-zA-Z0-9][a-zA-Z0-9._-]*$/', (string) $base)) {
        return null;
    }
    foreach (PLESK_SERVICE_APACHE_DIRS as $dir) {
        $file = $dir . '/' . $base . '.conf';
        if (is_file($file)) {
            return (string) @file_get_contents($file);
        }
    }

    return null;
}

/**
 * Plesk's service hostnames (webmail.<domain> today) as domain-shaped entries,
 * so the front maps them exactly like a subscription: own names, own
 * certificate, own document root, and PHP through the pool started below.
 *
 * A hostname only counts as direct once that pool is actually listening; until
 * then it keeps the Apache backend, which is why a failing pool can never leave
 * webmail unreachable.
 */
function plesk_service_apps()
{
    $apps = array();
    foreach ((array) glob(PLESK_SERVICE_NGINX_DIR . '/*.conf') as $file) {
        $base = basename($file, '.conf');
        $text = (string) @file_get_contents($file);

        $names = array();
        if (preg_match_all('/server_name\s+["\']([^"\';\r\n]+)["\']/i', $text, $m)) {
            foreach ($m[1] as $raw) {
                foreach (preg_split('/\s+/', trim($raw)) as $name) {
                    $name = trim($name, ';');
                    if ($name !== '' && $name !== '_' && $name[0] !== '*'
                        && preg_match('/^[a-zA-Z0-9][a-zA-Z0-9._-]*$/', $name)) {
                        $names[strtolower($name)] = true;
                    }
                }
            }
        }
        if (count($names) === 0) {
            continue;
        }

        $cert = null;
        $key = null;
        if (preg_match('/ssl_certificate\s+["\']?([^\s"\';]+)["\']?/i', $text, $m)) {
            $cert = $m[1];
        }
        if (preg_match('/ssl_certificate_key\s+["\']?([^\s"\';]+)["\']?/i', $text, $m)) {
            $key = $m[1];
        }

        $docroot = null;
        $user = null;
        $group = null;
        $ini = null;
        $alias = null;
        $handlerIndex = null;
        $apache = service_apache_dropin($base);
        if ($apache !== null) {
            if (preg_match('/DocumentRoot\s+"?([^\s"]+)"?/i', $apache, $m)) {
                $docroot = rtrim($m[1], '/');
            }
            if (preg_match('/SuexecUserGroup\s+"([^"\s]+)"\s+"([^"\s]+)"/i', $apache, $m)) {
                $user = $m[1];
                $group = $m[2];
            }
            if (preg_match('/PP_CUSTOM_PHP_INI\s+"([^"\s]+)"/i', $apache, $m)) {
                $ini = $m[1];
            }
            if (preg_match('/PP_CUSTOM_PHP_CGI_INDEX\s+"([^"\s]+)"/i', $apache, $m)) {
                $handlerIndex = $m[1];
            }
            if (preg_match('#Alias\s+"(/[^"\s]+)"\s+"(/[^"\s]+)"#i', $apache, $m)) {
                $alias = array('uri' => rtrim($m[1], '/') . '/', 'path' => rtrim($m[2], '/') . '/');
            }
        }
        $binary = service_php_binary($handlerIndex);

        $poolKey = substr(md5(implode('|', array($user, $group, $binary, $ini))), 0, 10);
        $socket = service_pool_prefix($poolKey) . '.sock';
        $ready = $docroot !== null && is_dir($docroot)
            && $user !== null && preg_match('/^[a-zA-Z0-9._-]{1,32}$/', $user) === 1
            && $group !== null && preg_match('/^[a-zA-Z0-9._-]{1,32}$/', $group) === 1
            && $binary !== null && $ini !== null && is_file($ini);

        $apps[] = array(
            'names' => array_keys($names),
            'cert' => $cert,
            'key' => $key === null ? $cert : $key,
            'ssl' => $cert !== null && is_file($cert),
            'http301' => (bool) preg_match('/return\s+30[12]\s+https:/i', $text),
            'plesk_key' => 'svc-' . $poolKey,
            'docroot' => $docroot,
            'php_socket' => $ready && file_exists($socket) ? $socket : null,
            'php_direct' => $ready && file_exists($socket),
            'service' => 'webmail',
            'alias' => $alias,
            'pool' => array(
                'key' => $poolKey,
                'binary' => $binary,
                'ini' => $ini,
                'user' => $user,
                'group' => $group,
                'socket' => $socket,
                'ready' => $ready,
            ),
        );
    }

    return $apps;
}

function service_pool_specs($facts)
{
    $specs = array();
    foreach ($facts['domains'] as $domain) {
        if (empty($domain['pool']) || !is_array($domain['pool']) || empty($domain['pool']['ready'])) {
            continue;
        }
        $specs[$domain['pool']['key']] = $domain['pool'];
    }

    return $specs;
}

function service_pool_conf_text(array $pool)
{
    $prefix = service_pool_prefix($pool['key']);

    return "[global]\n"
        . 'pid = ' . $prefix . ".pid\n"
        . 'error_log = ' . $prefix . ".log\n"
        . "daemonize = yes\n"
        . "\n"
        . "[plesk-service]\n"
        . 'user = ' . $pool['user'] . "\n"
        . 'group = ' . $pool['group'] . "\n"
        . 'listen = ' . $pool['socket'] . "\n"
        . "listen.owner = root\n"
        . 'listen.group = ' . PLESK_WEB_GROUP . "\n"
        . "listen.mode = 0660\n"
        . "pm = dynamic\n"
        . "pm.max_children = 8\n"
        . "pm.start_servers = 2\n"
        . "pm.min_spare_servers = 1\n"
        . "pm.max_spare_servers = 3\n"
        . "pm.max_requests = 500\n"
        . "chdir = /\n";
}

function service_pool_pid(array $pool)
{
    $file = service_pool_prefix($pool['key']) . '.pid';
    if (!is_file($file)) {
        return null;
    }
    $pid = (int) trim((string) @file_get_contents($file));
    if ($pid <= 0 || !is_dir('/proc/' . $pid)) {
        return null;
    }

    return $pid;
}

/**
 * Stop one pool, waiting for the master to leave so its socket and pid file can
 * be removed instead of racing a shutting-down process.
 */
function service_pool_stop(array $pool)
{
    $pid = service_pool_pid($pool);
    if ($pid !== null) {
        send_signal($pid, defined('SIGTERM') ? SIGTERM : 15);
        for ($i = 0; $i < 50 && is_dir('/proc/' . $pid); $i++) {
            usleep(100000);
        }
    }
    $prefix = service_pool_prefix($pool['key']);
    foreach (array('.sock', '.pid', '.conf') as $suffix) {
        if (is_file($prefix . $suffix)) {
            @unlink($prefix . $suffix);
        }
    }
}

/**
 * Bring the service pools up to the shape Plesk's own configuration asks for:
 * start what is missing, restart what changed, stop what Plesk removed. The
 * front only ever points at a pool that is listening, so a pool that cannot
 * start leaves its hostnames on the Apache backend instead of serving a 503.
 */
function service_pools_sync($facts, $useDirect)
{
    $result = array('started' => array(), 'stopped' => array(), 'failed' => array());
    if (!is_dir(EXTENGINE_DIR)) {
        @mkdir(EXTENGINE_DIR, 0750, true);
    }

    $specs = $useDirect ? service_pool_specs($facts) : array();

    foreach ((array) glob(SERVICE_POOL_DIR . '/' . SERVICE_POOL_SLUG . '-*.pid') as $file) {
        $key = substr(basename($file, '.pid'), strlen(SERVICE_POOL_SLUG) + 1);
        if (isset($specs[$key])) {
            continue;
        }
        $pool = array('key' => $key);
        service_pool_stop($pool);
        $result['stopped'][] = $key;
    }

    foreach ($specs as $key => $pool) {
        $prefix = service_pool_prefix($key);
        $conf = $prefix . '.conf';
        $wanted = service_pool_conf_text($pool);
        if ($wanted === @file_get_contents($conf) && service_pool_pid($pool) !== null
            && file_exists($pool['socket'])) {
            continue;
        }

        @file_put_contents($conf, $wanted);
        @chmod($conf, 0640);
        service_pool_stop($pool);

        $probe = substr(basename($pool['binary']), 0, 64);
        list($testCode, $testOut) = run(array(
            $pool['binary'], '--fpm-config', $conf, '-c', $pool['ini'], '-t',
        ));
        if ($testCode !== 0) {
            $result['failed'][] = $probe . ': ' . tail_text($testOut, 3);
            continue;
        }

        run(array($pool['binary'], '--fpm-config', $conf, '-c', $pool['ini']));
        $listening = false;
        for ($i = 0; $i < 50 && !$listening; $i++) {
            $listening = file_exists($pool['socket']);
            if (!$listening) {
                usleep(100000);
            }
        }
        if (!$listening) {
            $result['failed'][] = $probe . ': ' . tail_text((string) @file_get_contents($prefix . '.log'), 3);
            service_pool_stop($pool);
            continue;
        }

        $result['started'][] = $key;
    }

    return $result;
}

/** Stop every pool this extension started; used when Apache takes webmail back. */
function service_pools_stop_all()
{
    $stopped = array();
    foreach ((array) glob(SERVICE_POOL_DIR . '/' . SERVICE_POOL_SLUG . '-*.pid') as $file) {
        $key = substr(basename($file, '.pid'), strlen(SERVICE_POOL_SLUG) + 1);
        service_pool_stop(array('key' => $key));
        $stopped[] = $key;
    }
    foreach ((array) glob(SERVICE_POOL_DIR . '/' . SERVICE_POOL_SLUG . '-*') as $file) {
        if (is_file($file)) {
            @unlink($file);
        }
    }

    return $stopped;
}

/**
 * Plesk issues a certificate for the server hostname and nginx answers every
 * unknown HTTPS Host with the panel behind that certificate. Read the same three
 * facts out of server.conf instead of hardcoding them, so a hostname change or a
 * renewed certificate is followed automatically.
 */
function plesk_panel_app()
{
    $file = PLESK_NGINX_DIR . '/server.conf';
    if (!is_file($file)) {
        return null;
    }
    $text = (string) @file_get_contents($file);

    foreach (preg_split('/(^|\n)[ \t]*server[ \t]*\{/i', $text) as $chunk) {
        if (!preg_match('/ssl_certificate\s+["\']?([^\s"\';]+)["\']?/i', $chunk, $cm) || !is_file($cm[1])) {
            continue;
        }
        if (!preg_match('#proxy_pass\s+["\']?(https?)://((?:127\.0\.0\.1|\[::1\]|localhost)(?::\d+)?)#i', $chunk, $pm)) {
            continue;
        }
        $key = $cm[1];
        if (preg_match('/ssl_certificate_key\s+["\']?([^\s"\';]+)["\']?/i', $chunk, $km) && is_file($km[1])) {
            $key = $km[1];
        }

        return array(
            'names' => panel_host_names($cm[1]),
            'cert' => $cm[1],
            'key' => $key,
            'backend' => strtolower($pm[1]) . '://' . $pm[2],
            'plesk_key' => 'panel',
        );
    }

    return null;
}

/**
 * The names the hostname certificate stands for, plus the name the operating
 * system answers to: after `plesk bin server_pref` renames the server, Plesk
 * re-issues the certificate, and until it does the old one still has to be
 * served for the new name.
 */
function panel_host_names($certFile)
{
    $raw = array();
    if (function_exists('openssl_x509_parse')) {
        $parsed = @openssl_x509_parse((string) @file_get_contents($certFile));
        if (is_array($parsed)) {
            if (isset($parsed['subject']['CN'])) {
                $raw[] = $parsed['subject']['CN'];
            }
            foreach (explode(',', (string) (isset($parsed['extensions']['subjectAltName']) ? $parsed['extensions']['subjectAltName'] : '')) as $entry) {
                $entry = trim(preg_replace('/^DNS:/i', '', $entry));
                if ($entry !== '') {
                    $raw[] = $entry;
                }
            }
        }
    }
    $raw[] = gethostname();
    $raw[] = php_uname('n');

    $names = array();
    foreach ($raw as $name) {
        $name = strtolower(trim((string) $name, " \t.;\"'"));
        if ($name === '' || $name === '_' || $name === 'localhost' || $name[0] === '*'
            || strpos($name, '.') === false || !preg_match('/^[a-z0-9][a-z0-9._-]*$/', $name)) {
            continue;
        }
        $names[$name] = true;
    }

    return array_keys($names);
}

/**
 * Discover Plesk domains, certificates, document roots, php-fpm sockets, public
 * IPs and Apache backend ports by parsing the configuration Plesk maintains.
 */
function plesk_front_facts(){
    $facts = array(
        'domains' => array(),
        'ips' => array(),
        'panel' => null,
        'default_cert' => null,
        'http_backend' => '127.0.0.1:7080',
        'https_backend' => '127.0.0.1:7081',
    );

    $vhostFiles = (array) glob(PLESK_NGINX_DIR . '/vhosts/*.conf');
    $serverFile = PLESK_NGINX_DIR . '/server.conf';

    if (!is_file($serverFile) && count($vhostFiles) === 0) {
        return $facts;
    }

    // server.conf is parsed first: its "_" block proxies to the Plesk panel, and
    // that port must never be mistaken for the Apache web backend.
    $panelPorts = array();
    if (is_file($serverFile)) {
        $serverText = (string) @file_get_contents($serverFile);
        if (preg_match_all('#proxy_pass\s+["\']?https?://(?:127\.0\.0\.1|\[::1\]|localhost):(\d+)#i', $serverText, $m)) {
            foreach ($m[1] as $port) {
                $panelPorts[(int) $port] = true;
            }
        }
        if (preg_match('/ssl_certificate\s+["\']?([^\s"\';]+)["\']?/i', $serverText, $m) && is_file($m[1])) {
            $cert = $m[1];
            $key = $cert;
            if (preg_match('/ssl_certificate_key\s+["\']?([^\s"\';]+)["\']?/i', $serverText, $k)) {
                $key = $k[1];
            }
            $facts['default_cert'] = array('cert' => $cert, 'key' => $key);
        }
    }

    $allFiles = $vhostFiles;
    if (is_file($serverFile)) {
        $allFiles[] = $serverFile;
    }

    foreach ($allFiles as $file) {
        $text = (string) @file_get_contents($file);

        if (preg_match_all('/listen\s+["\']?(\[[0-9a-fA-F:]+\]|[0-9.]+):\d+/', $text, $m)) {
            foreach ($m[1] as $ip) {
                $ip = trim($ip, '[]');
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                    $facts['ips'][$ip] = true;
                }
            }
        }

        $cert = null;
        $key = null;
        if (preg_match('/ssl_certificate\s+["\']?([^\s"\';]+)["\']?/i', $text, $m)) {
            $cert = $m[1];
        }
        if (preg_match('/ssl_certificate_key\s+["\']?([^\s"\';]+)["\']?/i', $text, $m)) {
            $key = $m[1];
        }

        if ($file === $serverFile) {
            continue;
        }

        $httpPort = null;
        $httpsPort = null;
        if (preg_match_all('#proxy_pass\s+["\']?(https?)://(?:127\.0\.0\.1|\[::1\]|localhost)(?::(\d+))?#i', $text, $m, PREG_SET_ORDER)) {
            foreach ($m as $set) {
                $scheme = strtolower($set[1]);
                $port = isset($set[2]) && $set[2] !== '' ? (int) $set[2] : ($scheme === 'https' ? 443 : 80);
                if (isset($panelPorts[$port])) {
                    continue;
                }
                if ($scheme === 'https') {
                    if ($httpsPort === null) {
                        $httpsPort = $port;
                    }
                } elseif ($httpPort === null) {
                    $httpPort = $port;
                }
            }
        }
        if ($httpPort !== null) {
            $facts['http_backend'] = '127.0.0.1:' . $httpPort;
        }
        if ($httpsPort !== null) {
            $facts['https_backend'] = '127.0.0.1:' . $httpsPort;
        }
        $forcesHttps = (bool) preg_match('/return\s+30[12]\s+https:/i', $text);

        $names = array();
        if (preg_match_all('/server_name\s+["\']([^"\';\r\n]+)["\']/i', $text, $m)) {
            foreach ($m[1] as $raw) {
                foreach (preg_split('/\s+/', trim($raw)) as $name) {
                    $name = trim($name, ';');
                    if ($name !== '' && $name !== '_' && $name[0] !== '*' && preg_match('/^[a-zA-Z0-9][a-zA-Z0-9._-]*$/', $name)) {
                        $names[strtolower($name)] = true;
                    }
                }
            }
        }
        if (count($names) === 0) {
            continue;
        }
        $pleskKey = basename($file, '.conf');
        $docroot = plesk_docroot($pleskKey);
        $socket = plesk_php_socket($pleskKey, $text);
        $facts['domains'][] = array(
            'names' => array_keys($names),
            'cert' => $cert,
            'key' => $key === null ? $cert : $key,
            'ssl' => $cert !== null && is_file($cert),
            'http301' => $forcesHttps,
            'plesk_key' => $pleskKey,
            'docroot' => $docroot,
            'php_socket' => $socket,
            'php_direct' => $docroot !== null && $socket !== null,
        );
    }

    foreach (plesk_service_apps() as $app) {
        $facts['domains'][] = $app;
    }

    $facts['panel'] = plesk_panel_app();
    $facts['ips'] = array_keys($facts['ips']);
    if ($facts['default_cert'] === null) {
        foreach ($facts['domains'] as $domain) {
            if ($domain['ssl']) {
                $facts['default_cert'] = array('cert' => $domain['cert'], 'key' => $domain['key']);
                break;
            }
        }
    }

    return $facts;
}

function engine_vh_name($domainName, $suffix)
{
    $slug = preg_replace('/[^a-z0-9]+/i', '-', strtolower($domainName));
    $slug = trim(substr($slug, 0, 30), '-');

    return substr(VHOST_PREFIX . $slug . '-' . substr(md5(strtolower($domainName)), 0, 6) . $suffix, 0, 60);
}

function front_vhosts_dir($root)
{
    return $root . '/vhosts';
}

function write_front_vhconf($root, $vhName, $isHttps, $cert = null, $key = null, $handler = null)
{
    $vhDir = $root . '/conf/vhosts/' . $vhName;
    $vhRoot = front_vhosts_dir($root) . '/' . $vhName;
    foreach (array($vhDir, $vhRoot . '/html', $vhRoot . '/logs') as $dir) {
        if (!is_dir($dir)) {
            @mkdir($dir, 0750, true);
        }
    }
    @chown($vhDir, 'lsadm');
    @chgrp($vhDir, 'nobody');
    @chmod($vhDir, 0750);
    @chown($vhRoot . '/logs', 'nobody');
    @chgrp($vhRoot . '/logs', 'nobody');

    if ($handler === null) {
        $handler = $isHttps ? 'PleskHttpsBackend' : 'PleskHttpBackend';
    }
    $lines = array(
        'docRoot $VH_ROOT/html/',
        'enableGzip 1',
        '',
        'context / {',
        '  type proxy',
        '  handler ' . $handler,
        '}',
    );
    if ($isHttps && $cert !== null && $key !== null && is_file($cert) && is_file($key)) {
        $lines[] = '';
        $lines[] = 'vhssl {';
        $lines[] = '  enable 1';
        $lines[] = '  keyFile ' . $key;
        $lines[] = '  certFile ' . $cert;
        $lines[] = '}';
    }
    $lines[] = '';

    $file = $vhDir . '/vhconf.conf';
    @file_put_contents($file, implode("\n", $lines));
    @chown($file, 'lsadm');
    @chgrp($file, 'nobody');
    @chmod($file, 0640);

    return $file;
}

function front_vhost_register($vhName)
{
    return 'virtualHost ' . $vhName . '{' . "\n"
        . '    vhRoot                   vhosts/' . $vhName . '/' . "\n"
        . '    configFile               conf/vhosts/' . $vhName . '/vhconf.conf' . "\n"
        . '    allowSymbolLink          1' . "\n"
        . '    enableScript             1' . "\n"
        . '    setUIDMode               0' . "\n"
        . '}';
}

function engine_tls_handler($domainName)
{
    return 'PleskTls' . substr(md5(strtolower($domainName)), 0, 8);
}

function engine_php_handler($pleskKey)
{
    return 'PleskPhp' . substr(md5(strtolower($pleskKey)), 0, 10);
}

/**
 * A vhost that serves the Plesk document root itself: static files come
 * straight from OpenLiteSpeed and .php is handed to the php-fpm pool Plesk
 * already runs for that domain, so Apache is no longer in the request path.
 */
function write_direct_vhconf($root, $vhName, $docroot, $isHttps, $cert = null, $key = null, $phpHandler = null, $alias = null)
{
    $vhDir = $root . '/conf/vhosts/' . $vhName;
    $vhRoot = front_vhosts_dir($root) . '/' . $vhName;
    foreach (array($vhDir, $vhRoot . '/logs') as $dir) {
        if (!is_dir($dir)) {
            @mkdir($dir, 0750, true);
        }
    }
    @chown($vhDir, 'lsadm');
    @chgrp($vhDir, 'nobody');
    @chmod($vhDir, 0750);
    @chown($vhRoot . '/logs', 'nobody');
    @chgrp($vhRoot . '/logs', 'nobody');

    $doc = rtrim($docroot, '/') . '/';
    $lines = array(
        'docRoot ' . $doc,
        'enableGzip 1',
        '',
        'index {',
        '  indexFiles index.php index.html index.htm',
        '  autoIndex 0',
        '}',
        '',
        'context / {',
        '  location ' . $doc,
        '  allowBrowse 1',
        '  allowSymbolLink 1',
        '  rewrite {',
        '    RewriteFile .htaccess',
        '  }',
        '}',
    );
    if ($isHttps && $cert !== null && $key !== null && is_file($cert) && is_file($key)) {
        $lines[] = '';
        $lines[] = 'vhssl {';
        $lines[] = '  enable 1';
        $lines[] = '  keyFile ' . $key;
        $lines[] = '  certFile ' . $cert;
        $lines[] = '}';
    }
    if ($phpHandler !== null) {
        // The .php association lives in the virtual host config, not in the
        // virtualHost registration inside httpd_config.conf: LiteSpeed only
        // honours a vhost-level scripthandler there. The plain text form is the
        // one the server itself writes ("add <type>:<app> <suffix>"); the
        // "addsuffix" node the admin GUI shows has no plain-text syntax.
        $lines[] = '';
        $lines[] = 'scripthandler {';
        $lines[] = '  add fcgi:' . $phpHandler . ' php';
        $lines[] = '}';
    }
    if ($alias !== null && !empty($alias['uri']) && !empty($alias['path'])) {
        // Plesk keeps a second URI in front of the same application directory
        // (webmail is reached as /roundcube/ too), which is an alias context.
        $lines[] = '';
        $lines[] = 'context ' . $alias['uri'] . '{';
        $lines[] = '  type alias';
        $lines[] = '  alias ' . $alias['path'];
        $lines[] = '  allowBrowse 1';
        $lines[] = '}';
    }
    $lines[] = '';

    $file = $vhDir . '/vhconf.conf';
    @file_put_contents($file, implode("\n", $lines));
    @chown($file, 'lsadm');
    @chgrp($file, 'nobody');
    @chmod($file, 0640);

    return $file;
}

/**
 * A domain Plesk configures as HTTPS-only must keep its 301 even though Apache
 * is no longer in the request path. The plain-HTTP virtual host therefore serves
 * a document root this extension owns, whose only content is an Apache-compatible
 * rewrite that sends everything to the https address. It is reachable only on the
 * plain listener, so the redirect is unconditional.
 */
function write_redirect_vhconf($root, $vhName, $targetHost)
{
    $vhDir = $root . '/conf/vhosts/' . $vhName;
    $vhRoot = front_vhosts_dir($root) . '/' . $vhName;
    foreach (array($vhDir, $vhRoot . '/html', $vhRoot . '/logs') as $dir) {
        if (!is_dir($dir)) {
            @mkdir($dir, 0750, true);
        }
    }
    @chown($vhDir, 'lsadm');
    @chgrp($vhDir, 'nobody');
    @chmod($vhDir, 0750);
    @chown($vhRoot . '/logs', 'nobody');
    @chgrp($vhRoot . '/logs', 'nobody');

    $rules = 'RewriteEngine On' . "\n"
        . 'RewriteRule ^(.*)$ https://' . $targetHost . '/$1 [R=301,L]' . "\n";
    @file_put_contents($vhRoot . '/html/.htaccess', $rules);
    @chmod($vhRoot . '/html/.htaccess', 0644);

    $lines = array(
        'docRoot $VH_ROOT/html/',
        'enableGzip 1',
        '',
        'context / {',
        '  location $VH_ROOT/html/',
        '  allowBrowse 0',
        '  rewrite {',
        '    enable 1',
        '    RewriteFile .htaccess',
        '  }',
        '}',
        '',
    );

    $file = $vhDir . '/vhconf.conf';
    @file_put_contents($file, implode("\n", $lines));
    @chown($file, 'lsadm');
    @chgrp($file, 'nobody');
    @chmod($file, 0640);

    return $file;
}

function front_worker_group($root)
{
    $text = (string) @file_get_contents(main_config_file($root));
    if (preg_match('/^group[ \t]+(\S+)[ \t]*$/mi', $text, $m)) {
        return $m[1];
    }

    return null;
}

/**
 * OpenLiteSpeed drops every supplementary group when it switches its workers
 * to the configured user, so the only way it can read the Plesk document roots
 * (and connect to the php-fpm sockets) is to run with that group as its own -
 * exactly the group Plesk already gives nginx and Apache.
 */
function front_worker_group_set($root, $group)
{
    $main = main_config_file($root);
    $text = (string) @file_get_contents($main);
    $current = front_worker_group($root);
    if ($current === null || $current === $group) {
        return $current;
    }

    $padded = 'group' . str_repeat(' ', 24 - strlen($group)) . $group;
    $text = preg_replace('/^group[ \t]+\S+[ \t]*$/mi', $padded, $text, 1);
    @file_put_contents($main, $text);
    @chmod($main, 0640);

    return $current;
}

function front_worker_group_restore($root, $group)
{
    if ($group === null || $group === '' || $group === front_worker_group($root)) {
        return false;
    }

    $main = main_config_file($root);
    $text = (string) @file_get_contents($main);
    $padded = 'group' . str_repeat(' ', 24 - strlen($group)) . $group;
    $text = preg_replace('/^group[ \t]+\S+[ \t]*$/mi', $padded, $text, 1);
    @file_put_contents($main, $text);
    @chmod($main, 0640);

    return true;
}

/**
 * Apply the worker group the front needs and return the value a release has to
 * put back. A previous switch may already have recorded the real original, and
 * that one must survive instead of being overwritten with our own group.
 */
function front_worker_group_apply($root, $phpMode, $state)
{
    $recorded = isset($state['worker_group_original']) && $state['worker_group_original'] !== ''
        ? $state['worker_group_original'] : null;

    if ($phpMode !== PHP_DIRECT) {
        return $recorded;
    }

    $current = front_worker_group_set($root, PLESK_WEB_GROUP);
    if ($current === null || $current === PLESK_WEB_GROUP) {
        return $recorded === null ? $current : $recorded;
    }

    return $current;
}

/**
 * Build the whole front block.
 *
 * PHP_BACKEND keeps Plesk's Apache as the application server (every request is
 * proxied). PHP_DIRECT lets OpenLiteSpeed serve the document root itself and
 * hand .php straight to the php-fpm pool Plesk runs for that domain, which is
 * what removes Apache from the request path. Domains that cannot go direct -
 * no document root on disk, or a PHP handler without a pool socket - keep
 * using the Apache backend, so the front is always a mixture that works.
 */
function build_front_block($root, $facts, $phpMode = PHP_BACKEND)
{
    $useDirect = ($phpMode === PHP_DIRECT);
    $registrations = array();
    $mapsHttp = array();
    $mapsHttps = array();
    $tlsUpstreams = array();
    $pools = array();
    $needsApache = !$useDirect;

    $cert = $facts['default_cert'];
    $haveHttps = $cert !== null && is_file($cert['cert']) && is_file($cert['key']);

    // Catch-all virtual host: unknown Host headers must land on Plesk's own
    // default page, never on the first subscription.
    $defaultDoc = is_dir(PLESK_DEFAULT_DOCROOT) ? PLESK_DEFAULT_DOCROOT : null;
    if ($useDirect && $defaultDoc !== null) {
        write_direct_vhconf($root, VHOST_PREFIX . 'default', $defaultDoc, false);
    } else {
        write_front_vhconf($root, VHOST_PREFIX . 'default', false);
        $needsApache = true;
    }
    $registrations[] = front_vhost_register(VHOST_PREFIX . 'default');
    $mapsHttp[] = '    map ' . VHOST_PREFIX . 'default *';

    $defaultVhHttps = VHOST_PREFIX . 'default-s';
    if ($haveHttps) {
        if ($useDirect && $defaultDoc !== null) {
            write_direct_vhconf($root, $defaultVhHttps, $defaultDoc, true, $cert['cert'], $cert['key']);
        } else {
            write_front_vhconf($root, $defaultVhHttps, true, $cert['cert'], $cert['key']);
        }
        $registrations[] = front_vhost_register($defaultVhHttps);
        $mapsHttps[] = '    map ' . $defaultVhHttps . ' *';
    }

    // The server hostname answers with the Plesk panel behind the certificate
    // Plesk issued for it, so it is proxied to the same local panel port nginx
    // uses. An explicit map is what makes SNI pick that certificate: without it
    // the front would answer with whatever the catch-all negotiated. Apache is
    // never involved, so this cannot keep it running.
    $panel = isset($facts['panel']) && is_array($facts['panel']) ? $facts['panel'] : null;
    $panelServed = $haveHttps && $panel !== null && count($panel['names']) > 0
        && $panel['backend'] !== '' && is_file((string) $panel['cert']) && is_file((string) $panel['key']);
    if ($panelServed) {
        $panelVh = VHOST_PREFIX . 'panel-s';
        write_front_vhconf($root, $panelVh, true, $panel['cert'], $panel['key'], PANEL_HANDLER);
        $registrations[] = front_vhost_register($panelVh);
        $mapsHttps[] = '    map ' . $panelVh . ' ' . implode(':', $panel['names']);
    }

    foreach ($facts['domains'] as $domain) {
        $primary = $domain['names'][0];
        $hasHttps = !empty($domain['ssl'])
            && is_file((string) $domain['cert']) && is_file((string) $domain['key']);
        $direct = $useDirect && !empty($domain['php_direct']) && !empty($domain['docroot']);
        // Redirecting to HTTPS only makes sense when a listener answers there.
        $redirectHttp = $direct && !empty($domain['http301']) && $hasHttps;
        $handler = null;
        if ($direct) {
            $handler = engine_php_handler($domain['plesk_key']);
            $pools[$handler] = $domain['php_socket'];
        } else {
            $needsApache = true;
        }

        if ($redirectHttp) {
            write_redirect_vhconf($root, engine_vh_name($primary, '-h'), $primary);
        } elseif ($direct) {
            write_direct_vhconf($root, engine_vh_name($primary, '-h'), $domain['docroot'], false,
                null, null, $handler, isset($domain['alias']) ? $domain['alias'] : null);
        } else {
            write_front_vhconf($root, engine_vh_name($primary, '-h'), false);
        }
        $registrations[] = front_vhost_register(engine_vh_name($primary, '-h'));

        $vhHttps = null;
        if ($hasHttps) {
            if ($direct) {
                $vhHttps = engine_vh_name($primary, '-s');
                write_direct_vhconf($root, $vhHttps, $domain['docroot'], true, $domain['cert'],
                    $domain['key'], $handler, isset($domain['alias']) ? $domain['alias'] : null);
            } else {
                // Apache only accepts a request whose Host matches the SNI negotiated
                // on that TLS connection (mod_ssl AH02032 / HTTP 421). One upstream
                // per domain keeps every pooled connection single-host, which is what
                // nginx achieves with proxy_ssl_name $host + session reuse off.
                $tlsHandler = engine_tls_handler($primary);
                $tlsUpstreams[$tlsHandler] = $facts['https_backend'];
                $vhHttps = engine_vh_name($primary, '-s');
                write_front_vhconf($root, $vhHttps, true, $domain['cert'], $domain['key'], $tlsHandler);
            }
            $registrations[] = front_vhost_register($vhHttps);
        }

        // One map line per vhost, domains colon separated (the syntax verified
        // against lshttpd: `map Vhost domain.com:www.domain.com`).
        $hosts = implode(':', $domain['names']);
        $mapsHttp[] = '    map ' . engine_vh_name($primary, '-h') . ' ' . $hosts;
        if ($vhHttps !== null) {
            $mapsHttps[] = '    map ' . $vhHttps . ' ' . $hosts;
        }
    }

    $out = array();
    $out[] = FRONT_MARKER_BEGIN;
    $out[] = '# Managed by the Plesk "openlitespeed" extension. Do not edit inside these markers.';
    $out[] = '';

    $blocks = array();
    if ($needsApache) {
        $blocks[] = extprocessor_block('PleskHttpBackend', $facts['http_backend'], 500);
        $blocks[] = extprocessor_block('PleskHttpsBackend', 'https://' . $facts['https_backend'], 500);
        foreach ($tlsUpstreams as $name => $address) {
            $blocks[] = extprocessor_block($name, 'https://' . $address, 200);
        }
    }
    if ($panelServed) {
        $blocks[] = extprocessor_block(PANEL_HANDLER, $panel['backend'], 200);
    }
    foreach ($pools as $name => $socket) {
        $blocks[] = extprocessor_fcgi_block($name, $socket);
    }
    $out[] = implode("\n\n", $blocks);
    $out[] = '';

    foreach ($registrations as $block) {
        $out[] = $block;
        $out[] = '';
    }

    foreach ($facts['ips'] as $ip) {
        $tag = substr(md5($ip), 0, 8);
        $out[] = 'listener PleskPlain-' . $tag . '{';
        $out[] = '    address                  ' . $ip . ':80';
        $out[] = '    secure                   0';
        foreach ($mapsHttp as $map) {
            $out[] = $map;
        }
        $out[] = '}';
        $out[] = '';
        if ($haveHttps) {
            $out[] = 'listener PleskSecure-' . $tag . '{';
            $out[] = '    address                  ' . $ip . ':443';
            $out[] = '    secure                   1';
            $out[] = '    keyFile                  ' . $cert['key'];
            $out[] = '    certFile                 ' . $cert['cert'];
            foreach ($mapsHttps as $map) {
                $out[] = $map;
            }
            $out[] = '}';
            $out[] = '';
        }
    }

    $out[] = FRONT_MARKER_END;

    return implode("\n", $out);
}

/**
 * Count the domains that cannot be served without Apache, so the switch knows
 * whether Apache may be stopped.
 */
function front_apache_needed($facts, $phpMode)
{
    if ($phpMode !== PHP_DIRECT) {
        return count($facts['domains']);
    }

    $missing = 0;
    foreach ($facts['domains'] as $domain) {
        if (empty($domain['php_direct'])) {
            $missing++;
        }
    }
    if (!is_dir(PLESK_DEFAULT_DOCROOT)) {
        $missing++;
    }

    return $missing;
}

/**
 * Connect to the php-fpm pool Plesk already runs. `autoStart 0` is the whole
 * point: it tells OpenLiteSpeed the backend is started by somebody else, so it
 * only connects to the socket. With autoStart left on, `path` becomes required
 * (LiteSpeed's own rule: "Required field when auto start by Server is
 * enabled"), OpenLiteSpeed takes ownership of the pool, tries to lock a pid file
 * beside Plesk's socket, fails as `nobody`, drops the handler - and the request
 * falls back to the stock lsphp, which also runs as `nobody` and cannot read a
 * Plesk document root, so PHP sites answer 500. `instances` stays unset for the
 * same reason: a pool OpenLiteSpeed must not size.
 */
function extprocessor_fcgi_block($name, $socket, $maxConns = 200)
{
    return 'extprocessor ' . $name . '{' . "\n"
        . '    type                     fcgi' . "\n"
        . '    address                  uds://' . ltrim($socket, '/') . "\n"
        . '    maxConns                 ' . (int) $maxConns . "\n"
        . '    persistConn              1' . "\n"
        . '    autoStart                0' . "\n"
        . '}';
}

function extprocessor_block($name, $address, $maxConns)
{
    return 'extprocessor ' . $name . '{' . "\n"
        . '    type                     proxy' . "\n"
        . '    address                  ' . $address . "\n"
        . '    maxConns                 ' . (int) $maxConns . "\n"
        . '}';
}

/**
 * Delete generated vhost directories the current configuration no longer
 * registers. After a switch back to Plesk the stripped main config registers
 * none, so every pl-* tree goes away; after a failed validation the restored
 * config still registers its own names, so those trees are kept.
 */
function prune_generated_vhosts($root)
{
    $text = (string) @file_get_contents(main_config_file($root));
    if ($text === '') {
        return;
    }

    $used = array();
    foreach (extract_top_blocks($text, 'virtualHost') as $block) {
        if (strpos($block['name'], VHOST_PREFIX) === 0) {
            $used[$block['name']] = true;
        }
    }

    foreach (array($root . '/conf/vhosts', front_vhosts_dir($root)) as $base) {
        $dirs = (array) @glob($base . '/' . VHOST_PREFIX . '*', GLOB_ONLYDIR);
        foreach ($dirs as $dir) {
            $name = basename($dir);
            if (!isset($used[$name])) {
                ols_rmtree($dir);
                ols_rmtree($base . '/' . $name);
            }
        }
    }
}

function strip_front_block($text)
{
    $text = preg_replace('/\n?' . preg_quote(FRONT_MARKER_BEGIN, '/') . ".*?" . preg_quote(FRONT_MARKER_END, '/') . "\n?/s", '', $text);
    // Legacy probe blocks from earlier manual experiments.
    $text = preg_replace('/\n# BEGIN OLS-EXT[^\n]*\n.*?# END OLS-EXT[^\n]*\n?/s', '', $text);
    // Generated stanzas that sit outside the markers, or whose marker was lost:
    // they are identified by their own names, so stock blocks are never touched.
    $text = remove_named_blocks($text, 'extprocessor', '/^Plesk(?:Http|Https)Backend$|^PleskTls[0-9a-f]+$|^PleskPhp[0-9a-f]+$|^' . preg_quote(PANEL_HANDLER, '/') . '$/i');
    $text = remove_named_blocks($text, 'virtualhost', '/^' . preg_quote(VHOST_PREFIX, '/') . '/i');
    $text = remove_named_blocks($text, 'listener', '/^Plesk(?:Plain|Secure)-[0-9a-f]+$/i');
    // Any marker line that survived the passes above.
    $text = preg_replace('/\n?[ \t]*# (?:BEGIN|END) PLESK OLS EXTENSION WEB FRONT[^\n]*\n?/', "\n", $text);
    $text = preg_replace('/\n?[ \t]*# Managed by the Plesk "openlitespeed" extension[^\n]*\n?/', "\n", $text);

    return rtrim($text) . "\n";
}

/**
 * Drop every top-level `keyword <name> { ... }` block whose name matches, used
 * to clean generated stanzas that are not inside the extension markers.
 */
function remove_named_blocks($text, $keyword, $namePattern)
{
    $lines = explode("\n", $text);
    $count = count($lines);
    $kept = array();
    $i = 0;
    $start = '/^' . preg_quote($keyword, '/') . '[ \t]+([^{\n]+?)[ \t]*\{/i';
    while ($i < $count) {
        if (preg_match($start, $lines[$i], $m) && preg_match($namePattern, trim($m[1]))) {
            $depth = substr_count($lines[$i], '{') - substr_count($lines[$i], '}');
            $i++;
            while ($i < $count && $depth > 0) {
                $depth += substr_count($lines[$i], '{') - substr_count($lines[$i], '}');
                $i++;
            }
            continue;
        }
        $kept[] = $lines[$i];
        $i++;
    }

    return implode("\n", $kept);
}

/**
 * The listener addresses inside a front block, as a sorted "name=address" list.
 * Used to tell whether a regenerated block can be applied with a graceful reload.
 */
function front_listener_addresses($text)
{
    $found = array();
    preg_match_all('/listener (Plesk(?:Plain|Secure)-[0-9a-f]+)[ \t]*\{\n *address +(\S+)/', $text, $m, PREG_SET_ORDER);
    foreach ($m as $one) {
        $found[] = $one[1] . '=' . $one[2];
    }
    sort($found);

    return $found;
}

/** Cheap identity of everything the generated front depends on. */
function front_fingerprint($facts)
{
    $lines = (array) $facts['ips'];
    $lines[] = (string) $facts['http_backend'];
    $lines[] = (string) $facts['https_backend'];
    if (isset($facts['default_cert']) && is_array($facts['default_cert'])) {
        $lines[] = 'default:' . cert_stamp($facts['default_cert']['cert']);
    }
    if (isset($facts['panel']) && is_array($facts['panel'])) {
        $names = (array) $facts['panel']['names'];
        sort($names);
        $lines[] = 'panel:' . implode(',', $names) . '|' . (string) $facts['panel']['backend']
            . '|' . cert_stamp($facts['panel']['cert']);
    }
    foreach ($facts['domains'] as $domain) {
        $names = $domain['names'];
        sort($names);
        $lines[] = implode(',', $names) . '|'
            . (empty($domain['ssl']) ? 0 : 1) . '|'
            . (isset($domain['cert']) ? cert_stamp($domain['cert']) : '') . '|'
            . (empty($domain['http301']) ? 0 : 1);
    }
    sort($lines);

    return md5(implode("\n", $lines));
}

/**
 * Plesk renews and re-issues certificates by rewriting the very same file, and
 * OpenLiteSpeed keeps the certificate it read at startup, so the path alone can
 * never show that a renewal happened. The file's own size and mtime do.
 */
function cert_stamp($path)
{
    $path = (string) $path;
    if ($path === '' || !is_file($path)) {
        return 'missing';
    }

    return $path . ':' . (int) @filesize($path) . ':' . (int) @filemtime($path);
}

function ols_rmtree($path)
{
    if (!is_dir($path)) {
        if (is_file($path)) {
            @unlink($path);
        }

        return;
    }
    $items = @scandir($path);
    if ($items === false) {
        return;
    }
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $full = $path . '/' . $item;
        if (is_dir($full)) {
            ols_rmtree($full);
        } else {
            @unlink($full);
        }
    }
    @rmdir($path);
}

function ensure_admin_port_free($root)
{
    $adminConf = $root . '/admin/conf/admin_config.conf';
    if (!is_file($adminConf)) {
        return;
    }
    $text = (string) file_get_contents($adminConf);
    if (preg_match('/address\s+\S*:7080\b/', $text)) {
        $text = preg_replace('/(address\s+\S*?)7080\b/', '${1}7089', $text);
        @file_put_contents($adminConf, $text);
    }
}

/**
 * The OpenLiteSpeed web admin console lives in its own config file and its own
 * listener; Plesk owns 7080/7081 (Apache backend), so the real port is always
 * read from the configuration instead of assumed.
 */
function admin_console_info($root)
{
    $info = array(
        'configured' => false,
        'config_file' => null,
        'format' => null,
        'bind' => null,
        'port' => null,
        'ssl' => false,
        'listener' => null,
        'local_url' => null,
        'users' => array(),
        'has_user' => false,
        'htpasswd' => $root . ADMIN_HTPASSWD_FILE,
        'http_status' => null,
        'reachable' => false,
        'moved_off_7080' => false,
    );

    $plain = $root . ADMIN_CONFIG_FILE;
    $xml = $root . '/admin/conf/admin_config.xml';

    if (is_file($plain)) {
        $info['config_file'] = $plain;
        $info['format'] = 'plain';
        $text = (string) @file_get_contents($plain);
        foreach (extract_top_blocks($text, 'listener') as $block) {
            $address = block_field($block['body'], 'address');
            if ($address === null || !preg_match('/:(\d{2,5})$/', $address, $m)) {
                continue;
            }
            $info['configured'] = true;
            $info['listener'] = $block['name'];
            $info['bind'] = $address;
            $info['port'] = (int) $m[1];
            $info['ssl'] = strtolower((string) block_field($block['body'], 'secure')) === '1';
            break;
        }
    } elseif (is_file($xml)) {
        $info['config_file'] = $xml;
        $info['format'] = 'xml';
        $text = (string) @file_get_contents($xml);
        if (preg_match('#<adminSSL[^>]*>.*?<port>\s*(\d+)\s*</port>#s', $text, $m)) {
            $info['port'] = (int) $m[1];
            $info['ssl'] = true;
            $info['configured'] = true;
        } elseif (preg_match('#<adminPlainPort>\s*(\d+)\s*</adminPlainPort>#', $text, $m)) {
            $info['port'] = (int) $m[1];
            $info['configured'] = true;
        }
        if (preg_match('#<tunnelPort|<address>\s*([^<\s]+:\d+)#', $text, $m)) {
            $info['bind'] = $m[1];
        }
    }

    if ($info['port'] !== null) {
        $info['local_url'] = ($info['ssl'] ? 'https://' : 'http://') . '127.0.0.1:' . $info['port'] . '/';
        $info['moved_off_7080'] = $info['port'] !== 7080;
        $status = curl_status($info['local_url'], null, true, 4);
        $info['http_status'] = $status;
        $info['reachable'] = $status >= 200 && $status < 500;
    }

    if (is_file($info['htpasswd'])) {
        foreach (file($info['htpasswd'], FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
            $parts = explode(':', $line, 2);
            $name = trim($parts[0]);
            if ($name !== '' && preg_match('/^[A-Za-z0-9._@-]{1,64}$/', $name)) {
                $info['users'][] = $name;
            }
        }
        $info['has_user'] = count($info['users']) > 0;
    }

    return $info;
}

function do_admin_console_user($root, $user, $payloadB64)
{
    $file = $root . ADMIN_HTPASSWD_FILE;
    $dir = dirname($file);
    if (!is_dir($dir)) {
        fail('The OpenLiteSpeed admin configuration directory does not exist: ' . $dir);
    }

    $user = (string) $user;
    if (!preg_match('/^[A-Za-z0-9._@-]{3,64}$/', $user)) {
        fail('Invalid administrator name.');
    }

    $password = (string) base64_decode((string) $payloadB64, true);
    if (strlen($password) < 6) {
        fail('The console password must be at least 6 characters long.');
    }

    // bcrypt is exactly what OpenLiteSpeed's own admpass.sh writes (it shells out
    // to its bundled PHP with password_hash($pass, PASSWORD_BCRYPT)).
    $hash = password_hash($password, PASSWORD_BCRYPT);
    if ($hash === null || strlen($hash) < 20) {
        fail('This PHP build cannot create a bcrypt hash for the console user.');
    }

    $lines = array();
    if (is_file($file)) {
        foreach (file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
            $existing = explode(':', $line, 2);
            if (trim($existing[0]) !== $user) {
                $lines[] = $line;
            }
        }
    }
    $lines[] = $user . ':' . $hash;

    $owner = 'lsadm';
    $group = 'lsadm';
    if (!is_dir($dir)) {
        @mkdir($dir, 0750, true);
    }
    if (is_file($file)) {
        $stat = @stat($file);
        if ($stat !== false) {
            $owner = function_exists('posix_getpwuid') && ($u = @posix_getpwuid($stat['uid'])) !== false
                ? $u['name'] : $stat['uid'];
            $group = function_exists('posix_getgrgid') && ($g = @posix_getgrgid($stat['gid'])) !== false
                ? $g['name'] : $stat['gid'];
        }
    }

    $temp = $file . '.plesk-ols.tmp';
    if (@file_put_contents($temp, implode("\n", $lines) . "\n") === false) {
        fail('Unable to write ' . $file);
    }
    @chmod($temp, 0600);
    @chown($temp, $owner);
    @chgrp($temp, $group);
    if (!@rename($temp, $file)) {
        @unlink($temp);
        fail('Unable to replace ' . $file);
    }

    $info = admin_console_info($root);

    return array(
        'ok' => true,
        'user' => $user,
        'users' => $info['users'],
        'url' => $info['local_url'],
        'note' => 'Console credentials saved.',
    );
}

function front_block_installed($root)
{
    $text = (string) @file_get_contents(main_config_file($root));
    if (strpos($text, FRONT_MARKER_BEGIN) !== false || strpos($text, FRONT_MARKER_END) !== false) {
        return true;
    }

    // The markers can be lost by an outside edit, but the generated names cannot.
    return preg_match('/^extprocessor Plesk(?:Http|Https)Backend[ \t]*\{/mi', $text) === 1
        || preg_match('/^virtualhost ' . preg_quote(VHOST_PREFIX, '/') . '[^ \t\{]+[ \t]*\{/mi', $text) === 1;
}

function curl_binary()
{
    static $checked = false;
    static $binary = null;
    if ($checked) {
        return $binary;
    }
    $checked = true;
    foreach (array('/usr/bin/curl', '/bin/curl', '/usr/local/bin/curl') as $candidate) {
        if (is_executable($candidate)) {
            return $binary = $candidate;
        }
    }

    return $binary = null;
}

function stream_http_status($url, $hostHeader, $timeout)
{
    $headers = array();
    if ($hostHeader !== null) {
        $headers[] = 'Host: ' . $hostHeader;
    }
    $context = stream_context_create(array(
        'http' => array(
            'method' => 'GET',
            'timeout' => $timeout,
            'ignore_errors' => true,
            'follow_location' => 0,
            'header' => $headers,
        ),
        'ssl' => array(
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true,
            'peer_name' => $hostHeader !== null ? $hostHeader : (string) parse_url($url, PHP_URL_HOST),
        ),
    ));

    $previous = ini_set('default_socket_timeout', (string) max(1, $timeout));
    @file_get_contents($url, false, $context);
    if ($previous !== false) {
        ini_set('default_socket_timeout', $previous);
    }
    if (!isset($http_response_header) || !isset($http_response_header[0])) {
        return 0;
    }
    if (preg_match('#^HTTP/[0-9.]+ +(\d{3})#', $http_response_header[0], $m)) {
        return (int) $m[1];
    }

    return 0;
}

function curl_status($url, $hostHeader = null, $insecure = false, $timeout = 8)
{
    $curl = curl_binary();
    if ($curl === null) {
        return stream_http_status($url, $hostHeader, $timeout);
    }

    $cmd = array($curl, '-s', '-o', '/dev/null', '-m', (string) $timeout, '-w', '%{http_code}');
    if ($hostHeader !== null) {
        $cmd[] = '-H';
        $cmd[] = 'Host: ' . $hostHeader;
    }
    if ($insecure) {
        $cmd[] = '-k';
    }
    $cmd[] = $url;
    list(, $out) = run($cmd);

    return (int) trim($out);
}

function health_check_domains($facts, $useHttps)
{
    $results = array();
    $failed = array();
    if (count($facts['ips']) === 0 || count($facts['domains']) === 0) {
        return array($results, $failed);
    }
    $ip = $facts['ips'][0];
    $url = ($useHttps ? 'https://' : 'http://') . $ip . '/';
    foreach (array_slice($facts['domains'], 0, MAX_HEALTH_DOMAINS) as $domain) {
        $host = $domain['names'][0];
        $status = curl_status($url, $host, $useHttps);
        $results[$host] = $status;
        if ($status <= 0 || $status >= 500) {
            $failed[] = $host;
        }
    }

    return array($results, $failed);
}

/**
 * Ask the front for the server hostname the way a browser would: the address the
 * panel certificate was issued for, resolved to the public web IP.
 */
function health_check_panel($facts)
{
    if (!isset($facts['panel']) || !is_array($facts['panel']) || count($facts['ips']) === 0
        || count($facts['panel']['names']) === 0) {
        return null;
    }

    return curl_status('https://' . $facts['ips'][0] . '/', $facts['panel']['names'][0], true);
}

function describe_failures($results, $hosts)
{
    $lines = array();
    foreach ($hosts as $host) {
        $status = isset($results[$host]) ? (int) $results[$host] : 0;
        $lines[] = $host . ' => ' . ($status === 0 ? 'no response' : 'HTTP ' . $status);
    }

    return implode('; ', $lines);
}

function backup_front_files($root)
{
    $dir = EXTENGINE_DIR . '/backups/' . date('Ymd-His');
    @mkdir($dir, 0750, true);
    $main = main_config_file($root);
    if (is_file($main)) {
        @copy($main, $dir . '/httpd_config.conf');
    }
    $admin = $root . '/admin/conf/admin_config.conf';
    if (is_file($admin)) {
        @copy($admin, $dir . '/admin_config.conf');
    }
    foreach ((array) glob($dir . '/*') as $f) {
        @chmod($f, 0600);
    }

    return $dir;
}

function restore_configs($root, $dir)
{
    if (is_dir($dir)) {
        if (is_file($dir . '/httpd_config.conf')) {
            @copy($dir . '/httpd_config.conf', main_config_file($root));
        }
        if (is_file($dir . '/admin_config.conf')) {
            @copy($dir . '/admin_config.conf', $root . '/admin/conf/admin_config.conf');
        }
    }
}

/**
 * Undo the two things the direct-mode front changes outside its own marked
 * block: the worker group, and an Apache that was stopped because nothing
 * needed it any more.
 */
function front_release_side_effects($root, $state, $systemctl)
{
    $apache = isset($state['apache_service']) && $state['apache_service'] !== ''
        ? $state['apache_service'] : apache_service_name();

    if (!empty($state['worker_group_original'])) {
        front_worker_group_restore($root, $state['worker_group_original']);
    }

    if (empty($state['apache_disabled']) || $apache === null) {
        return $apache;
    }
    if ($systemctl !== null) {
        run(array($systemctl, 'enable', $apache));
        run(array($systemctl, 'start', $apache));
    }

    return $apache;
}

function do_switch_ols($root, $phpMode = PHP_BACKEND)
{
    if (!in_array($phpMode, PHP_MODES, true)) {
        $phpMode = PHP_BACKEND;
    }
    if (!is_plain_config($root)) {
        fail('The web front switch needs OpenLiteSpeed 1.8+ with plain-text configuration; this server uses the legacy XML format.');
    }
    $facts = plesk_front_facts();
    if (count($facts['ips']) === 0) {
        fail('No Plesk web IP address could be detected from the nginx configuration; nothing was changed.');
    }
    $systemctl = find_systemctl();
    $nginx = nginx_service_name();
    if ($nginx === null) {
        fail('The nginx service was not found; refusing to switch without a reversible path back.');
    }

    $backups = backup_front_files($root);
    $nginxWasActive = service_active($nginx);
    $apache = apache_service_name();
    $apacheWasActive = service_active($apache);
    $previousState = engine_read_state();

    // In direct mode OpenLiteSpeed serves the document roots itself and hands
    // .php to the php-fpm pool Plesk already runs for that domain, so Apache is
    // out of the request path. Domains that cannot go direct keep the Apache
    // backend, which is why Apache is only released when none of them remain.
    $apacheNeeded = front_apache_needed($facts, $phpMode) > 0;
    $directDomains = 0;
    if ($phpMode === PHP_DIRECT) {
        foreach ($facts['domains'] as $domain) {
            if (!empty($domain['php_direct'])) {
                $directDomains++;
            }
        }
    }

    // Plesk's service hostnames (webmail.<domain>) have no subscription pool, so
    // this extension runs one for them in direct mode. The facts are read again
    // afterwards: the front only ever points at a pool that is already listening,
    // and a pool that cannot start leaves those hostnames on the Apache backend.
    $pools = service_pools_sync($facts, $phpMode === PHP_DIRECT);
    if (count($pools['started']) > 0 || count($pools['failed']) > 0) {
        $facts = plesk_front_facts();
    }

    // Baseline probe while nginx is still in front: domains that already answer
    // badly must not be blamed on the switch (and must not trigger a rollback).
    list(, $preFailed) = health_check_domains($facts, false);

    // The worker group lives outside the front markers, so it is backed up here
    // and every failure path below restores it together with the configuration.
    $groupOriginal = front_worker_group_apply($root, $phpMode, $previousState);

    $main = main_config_file($root);
    $text = (string) @file_get_contents($main);
    @file_put_contents($main, rtrim(strip_front_block($text)) . "\n\n" . build_front_block($root, $facts, $phpMode) . "\n");
    @chmod($main, 0640);
    ensure_admin_port_free($root);

    list($testCode, $testOut) = test_config($root);
    $testErrors = $testCode === null ? array() : config_error_lines($testOut);
    if (count($testErrors) > 0) {
        restore_configs($root, $backups);
        prune_generated_vhosts($root);
        fail("The generated front configuration failed the 'lshttpd -t' check. Nothing was switched.\n\n" . implode("\n", $testErrors));
    }

    prune_generated_vhosts($root);

    $rollback = function () use ($root, $backups, $nginx, $apache, $systemctl, $nginxWasActive, $apacheWasActive, $apacheNeeded) {
        restore_configs($root, $backups);
        prune_generated_vhosts($root);
        try_control($root, 'stop');
        if ($systemctl !== null) {
            run(array($systemctl, 'enable', $nginx));
            if ($nginxWasActive) {
                run(array($systemctl, 'start', $nginx));
            }
            if (!$apacheNeeded && $apache !== null) {
                run(array($systemctl, 'enable', $apache));
                if ($apacheWasActive) {
                    run(array($systemctl, 'start', $apache));
                }
            }
        }
        try_control($root, 'start');
        // Plesk's own PHP runtime serves webmail again once nginx is back.
        service_pools_stop_all();
    };

    // Cut over: free ports 80/443, then start OpenLiteSpeed on them.
    if ($nginxWasActive && $systemctl !== null) {
        run(array($systemctl, 'stop', $nginx));
    }
    if ($systemctl !== null && $apache !== null) {
        if ($apacheNeeded) {
            // A previous direct-mode switch may have left Apache disabled.
            if (!$apacheWasActive) {
                run(array($systemctl, 'enable', $apache));
                run(array($systemctl, 'start', $apache));
            }
        } elseif ($apacheWasActive) {
            run(array($systemctl, 'stop', $apache));
        }
    }
    list($started, $out) = try_full_restart($root);
    $olsState = service_state($root);
    if (!$olsState['running']) {
        $rollback();
        fail('OpenLiteSpeed did not start with the front configuration (' . $out . '). nginx was restored.');
    }

    list($checked, $failed) = health_check_domains($facts, false);
    $newlyFailed = array_values(array_diff($failed, $preFailed));
    if (count($newlyFailed) > 0) {
        $rollback();
        fail("Switch to OpenLiteSpeed failed the HTTP health check and was rolled back automatically.\n\nFailed: "
            . describe_failures($checked, $newlyFailed));
    }
    $skipped = array_values(array_intersect($failed, $preFailed));
    list($httpsChecked, $httpsFailed) = health_check_domains($facts, true);
    // Informational: the panel answers on the front too, but a customer site is
    // what decides whether the switch may stay.
    $panelStatus = health_check_panel($facts);

    if ($systemctl !== null) {
        run(array($systemctl, 'disable', $nginx));
        if (!$apacheNeeded && $apache !== null) {
            run(array($systemctl, 'disable', $apache));
        }
    }

    engine_write_state(array(
        'mode' => 'ols-front',
        'php_mode' => $phpMode,
        'direct_domains' => $directDomains,
        'backups' => $backups,
        'switched_at' => date('c'),
        'domains' => $checked,
        'https_domains' => $httpsChecked,
        'https_failed' => $httpsFailed,
        'already_broken' => $skipped,
        'panel_host' => isset($facts['panel']['names'][0]) ? $facts['panel']['names'][0] : null,
        'panel_status' => $panelStatus,
        'front_fingerprint' => front_fingerprint($facts),
        'http_backend' => $facts['http_backend'],
        'https_backend' => $facts['https_backend'],
        'nginx_was_active' => $nginxWasActive,
        'worker_group_original' => $groupOriginal,
        'apache_service' => $apache,
        'apache_was_active' => $apacheWasActive,
        'apache_disabled' => !$apacheNeeded,
    ));

    front_cron_write(true);

    if ($phpMode === PHP_DIRECT) {
        $note = 'OpenLiteSpeed serves every document root itself and runs PHP in the pool Plesk already starts for that domain, so Apache is '
            . ($apacheNeeded
                ? 'still behind the front for ' . front_apache_needed($facts, $phpMode) . ' domain(s) that cannot go direct'
                : 'stopped and disabled') . '. nginx is stopped and disabled until you switch back.';
    } else {
        $note = 'OpenLiteSpeed now fronts ports 80/443 and proxies to Apache. nginx is stopped and disabled until you switch back.';
    }

    $serviceHosts = 0;
    foreach ($facts['domains'] as $domain) {
        if (!empty($domain['service'])) {
            $serviceHosts++;
        }
    }
    if ($phpMode === PHP_DIRECT && $serviceHosts > 0) {
        $note .= ' ' . $serviceHosts . ' Plesk service hostname(s) (webmail) are served directly from a PHP pool this extension starts.';
    }
    if (count($pools['failed']) > 0) {
        $note .= ' These webmail pools could not be started, so those hostnames keep the Apache backend: '
            . implode('; ', $pools['failed']) . '.';
    }

    $panelHost = isset($facts['panel']['names'][0]) ? $facts['panel']['names'][0] : null;
    if ($panelHost !== null && ($panelStatus === null || $panelStatus < 200 || $panelStatus >= 500)) {
        $note .= ' ' . $panelHost . ' (the server hostname) is mapped to the Plesk panel but did not answer through the front.';
    }

    return array(
        'ok' => true,
        'mode' => 'ols-front',
        'php_mode' => $phpMode,
        'apache_disabled' => !$apacheNeeded,
        'backups' => $backups,
        'domains' => $checked,
        'https_domains' => $httpsChecked,
        'https_failed' => $httpsFailed,
        'already_broken' => $skipped,
        'ols_state' => service_state($root),
        'nginx_active' => service_active($nginx),
        'apache_active' => service_active($apache),
        'service_pools' => $pools,
        'panel_host' => $panelHost,
        'panel_status' => $panelStatus,
        'note' => $note,
    );
}

function do_switch_nginx($root)
{
    $systemctl = find_systemctl();
    $nginx = nginx_service_name();
    if ($nginx === null) {
        fail('The nginx service was not found; cannot switch back.');
    }

    $state = engine_read_state();
    $facts = plesk_front_facts();
    list(, $preFailed) = health_check_domains($facts, false);

    $backups = backup_front_files($root);

    $main = main_config_file($root);
    $text = (string) @file_get_contents($main);
    @file_put_contents($main, strip_front_block($text));
    @chmod($main, 0640);
    prune_generated_vhosts($root);
    front_release_side_effects($root, $state, $systemctl);
    front_cron_write(false);

    // Stop OpenLiteSpeed (releases 80/443), bring nginx back, then start OLS again.
    try_control($root, 'stop');
    if ($systemctl !== null) {
        run(array($systemctl, 'enable', $nginx));
        run(array($systemctl, 'start', $nginx));
    }
    sleep(1);

    list($checked, $failed) = health_check_domains($facts, false);
    $newlyFailed = array_values(array_diff($failed, $preFailed));
    try_control($root, 'start');
    // nginx is in front again and Apache has its own PHP runtime, so the pools
    // this extension started for webmail are no longer referenced.
    service_pools_stop_all();

    engine_write_state(array(
        'mode' => count($newlyFailed) === 0 ? 'nginx-front' : 'nginx-front-partial',
        'php_mode' => PHP_BACKEND,
        'backups' => $backups,
        'switched_at' => date('c'),
        'domains' => $checked,
        'already_broken' => array_values(array_intersect($failed, $preFailed)),
        'apache_disabled' => false,
        'worker_group_original' => null,
        'last_error' => count($newlyFailed) === 0 ? null : describe_failures($checked, $newlyFailed),
    ));

    if (count($newlyFailed) > 0) {
        fail('Switch back to nginx completed, but these domains stopped answering: '
            . describe_failures($checked, $newlyFailed)
            . "\nnginx and Apache are running; backups are in " . $backups);
    }

    return array(
        'ok' => true,
        'mode' => 'nginx-front',
        'backups' => $backups,
        'domains' => $checked,
        'already_broken' => array_values(array_intersect($failed, $preFailed)),
        'nginx_active' => service_active($nginx),
        'apache_active' => service_active(apache_service_name()),
        'ols_state' => service_state($root),
        'note' => 'nginx is back in front of Apache. OpenLiteSpeed keeps running for its own ports and everything is reversible.',
    );
}

/**
 * The one question the removal guard asks: is OpenLiteSpeed still holding the
 * public ports for Plesk's domains? Only that combination would strand a site
 * behind a front that is about to lose its owner.
 */
function front_active_state($root)
{
    $nginxActive = service_active(nginx_service_name());
    $installed = $root !== null;
    $block = $installed && front_block_installed($root);
    $ols = $installed ? service_state($root) : array('running' => false);

    return array(
        'ok' => true,
        'is_front' => $block && !empty($ols['running']) && !$nginxActive,
        'front_installed' => $block,
        'ols_running' => !empty($ols['running']),
        'nginx_active' => (bool) $nginxActive,
    );
}

/**
 * Uninstall safety path: put the public web front back on Plesk's stock
 * nginx + Apache without ever aborting, collecting problems as warnings so a
 * removal can never leave the server on a front that nobody owns anymore.
 */
function do_engine_revert($root)
{
    $warnings = array();
    $systemctl = find_systemctl();
    $nginx = nginx_service_name();
    $state = engine_read_state();
    $mode = isset($state['mode']) ? $state['mode'] : 'unknown';

    front_cron_write(false);

    if ($root === null) {
        return array('ok' => true, 'reverted' => false, 'mode' => 'nginx-front',
            'note' => 'OpenLiteSpeed is not installed; nothing to revert.', 'warnings' => $warnings);
    }

    $wasFront = $mode === 'ols-front' || front_block_installed($root);
    if (!$wasFront) {
        engine_write_state(array_merge($state, array(
            'mode' => 'nginx-front',
            'reverted_at' => date('c'),
        )));

        return array('ok' => true, 'reverted' => false, 'mode' => 'nginx-front',
            'note' => 'nginx is already the web front; nothing to revert.', 'warnings' => $warnings);
    }

    $backups = backup_front_files($root);
    $facts = plesk_front_facts();
    list(, $preFailed) = health_check_domains($facts, false);

    $main = main_config_file($root);
    $text = (string) @file_get_contents($main);
    @file_put_contents($main, strip_front_block($text));
    @chmod($main, 0640);
    prune_generated_vhosts($root);
    front_release_side_effects($root, $state, $systemctl);

    list($testCode, $testOut) = test_config($root);
    $errors = $testCode === null ? array() : config_error_lines($testOut);
    if (count($errors) > 0) {
        $warnings[] = "The reverted OpenLiteSpeed configuration did not pass 'lshttpd -t': "
            . implode('; ', array_slice($errors, 0, 3));
    }

    try_control($root, 'stop');
    if ($systemctl === null || $nginx === null) {
        $warnings[] = 'The nginx service was not found; start it manually to serve public traffic.';
    } else {
        run(array($systemctl, 'enable', $nginx));
        run(array($systemctl, 'start', $nginx));
        if (!service_active($nginx)) {
            $warnings[] = 'nginx did not report active after the switch; run "systemctl status ' . $nginx . '".';
        }
    }
    sleep(1);
    // OpenLiteSpeed no longer fronts the public ports, so Plesk's own PHP runtime
    // is the only webmail path left.
    service_pools_stop_all();

    list($checked, $failed) = health_check_domains($facts, false);
    $newlyFailed = array_values(array_diff($failed, $preFailed));
    if (count($newlyFailed) > 0) {
        $warnings[] = 'These domains did not answer after the revert: '
            . describe_failures($checked, $newlyFailed);
    }

    $olsStart = try_control($root, 'start');
    $apache = apache_service_name();
    if ($apache !== null && !service_active($apache)) {
        $warnings[] = 'Apache did not report active after the revert; run "systemctl start ' . $apache . '" if PHP pages do not load.';
    }
    engine_write_state(array(
        'mode' => count($newlyFailed) === 0 ? 'nginx-front' : 'nginx-front-partial',
        'php_mode' => PHP_BACKEND,
        'backups' => $backups,
        'switched_at' => date('c'),
        'reverted_at' => date('c'),
        'domains' => $checked,
        'already_broken' => array_values(array_intersect($failed, $preFailed)),
        'apache_disabled' => false,
        'worker_group_original' => null,
        'last_error' => count($newlyFailed) === 0 ? null : implode("\n", $warnings),
    ));

    return array(
        'ok' => true,
        'reverted' => true,
        'mode' => count($newlyFailed) === 0 ? 'nginx-front' : 'nginx-front-partial',
        'backups' => $backups,
        'domains' => $checked,
        'ols_started' => $olsStart,
        'nginx_active' => service_active($nginx),
        'apache_active' => service_active($apache),
        'warnings' => $warnings,
        'note' => 'nginx + Apache is the public web front again and the automatic sync timer was removed.',
    );
}

function do_engine_sync($root)
{
    $state = engine_read_state();
    if (!isset($state['mode']) || $state['mode'] !== 'ols-front') {
        fail('Domain sync only applies while OpenLiteSpeed is the active web front.');
    }
    $phpMode = isset($state['php_mode']) && in_array($state['php_mode'], PHP_MODES, true)
        ? $state['php_mode'] : PHP_BACKEND;
    $facts = plesk_front_facts();
    if (count($facts['ips']) === 0) {
        fail('No Plesk web IP address could be detected; sync aborted.');
    }
    // Also the supervision path for the webmail pools: this runs on the timer, so
    // a pool that died between two syncs is back before the next cron tick.
    $pools = service_pools_sync($facts, $phpMode === PHP_DIRECT);
    if (count($pools['started']) > 0 || count($pools['failed']) > 0 || count($pools['stopped']) > 0) {
        $facts = plesk_front_facts();
    }
    $backups = backup_front_files($root);
    $systemctl = find_systemctl();

    // Domains that were already unreachable at the last switch/sync are not this
    // sync's fault, so they are excluded from the pass/fail verdict.
    $preFailed = isset($state['already_broken']) && is_array($state['already_broken']) ? $state['already_broken'] : array();
    if (isset($state['domains']) && is_array($state['domains'])) {
        foreach ($state['domains'] as $host => $status) {
            if ((int) $status <= 0 || (int) $status >= 500) {
                $preFailed[] = $host;
            }
        }
    }
    $preFailed = array_values(array_unique($preFailed));

    $groupOriginal = front_worker_group_apply($root, $phpMode, $state);
    $apacheNeeded = front_apache_needed($facts, $phpMode) > 0;
    $apache = isset($state['apache_service']) && $state['apache_service'] !== ''
        ? $state['apache_service'] : apache_service_name();

    $main = main_config_file($root);
    $text = (string) @file_get_contents($main);
    $block = build_front_block($root, $facts, $phpMode);
    // A graceful reload is enough while no listener has to release a port, and it
    // keeps established client connections alive; only an IP change needs stop/start.
    $keepListeners = front_listener_addresses($text) === front_listener_addresses($block);
    @file_put_contents($main, rtrim(strip_front_block($text)) . "\n\n" . $block . "\n");
    @chmod($main, 0640);

    list($testCode, $testOut) = test_config($root);
    $errors = $testCode === null ? array() : config_error_lines($testOut);
    if (count($errors) > 0) {
        restore_configs($root, $backups);
        fail("The regenerated front configuration failed the 'lshttpd -t' check; the previous configuration was restored.\n\n" . implode("\n", $errors));
    }

    prune_generated_vhosts($root);
    // A new subscription may need the Apache backend while a removed one freed it,
    // so the service follows the same verdict the front was built with.
    if ($systemctl !== null && $apache !== null) {
        if ($apacheNeeded) {
            if (!service_active($apache)) {
                run(array($systemctl, 'enable', $apache));
                run(array($systemctl, 'start', $apache));
            }
        } elseif (service_active($apache)) {
            run(array($systemctl, 'stop', $apache));
            run(array($systemctl, 'disable', $apache));
        }
    }
    if ($keepListeners) {
        try_control($root, 'restart');
    } else {
        try_full_restart($root);
    }
    list($checked, $failed) = health_check_domains($facts, false);
    list($httpsChecked, $httpsFailed) = health_check_domains($facts, true);
    $panelStatus = health_check_panel($facts);
    $newlyFailed = array_values(array_diff($failed, $preFailed));
    $skipped = array_values(array_intersect($failed, $preFailed));

    engine_write_state(array_merge($state, array(
        'php_mode' => $phpMode,
        'direct_domains' => $phpMode === PHP_DIRECT ? count(array_filter($facts['domains'], function ($d) {
            return !empty($d['php_direct']);
        })) : 0,
        'domains' => $checked,
        'https_domains' => $httpsChecked,
        'https_failed' => $httpsFailed,
        'already_broken' => $skipped,
        'panel_host' => isset($facts['panel']['names'][0]) ? $facts['panel']['names'][0] : null,
        'panel_status' => $panelStatus,
        'front_fingerprint' => front_fingerprint($facts),
        'worker_group_original' => $groupOriginal,
        'apache_service' => $apache,
        'apache_disabled' => !$apacheNeeded,
        'synced_at' => date('c'),
    )));

    $payload = array(
        'ok' => count($newlyFailed) === 0,
        'php_mode' => $phpMode,
        'domains' => $checked,
        'failed' => $newlyFailed,
        'already_broken' => $skipped,
        'https_domains' => $httpsChecked,
        'https_failed' => $httpsFailed,
        'panel_host' => isset($facts['panel']['names'][0]) ? $facts['panel']['names'][0] : null,
        'panel_status' => $panelStatus,
        'backups' => $backups,
        'service_pools' => $pools,
    );
    if (count($pools['failed']) > 0) {
        $payload['note'] = 'These webmail PHP pools could not be started, so those hostnames keep the Apache backend: '
            . implode('; ', $pools['failed']) . '.';
    }
    if (count($newlyFailed) > 0) {
        $payload['error'] = 'The front configuration was rebuilt, but these domains stopped answering: '
            . describe_failures($checked, $newlyFailed) . "\nThe previous configuration is backed up in " . $backups;
    }

    return $payload;
}

/**
 * Called on a timer: regenerates the front only when Plesk actually changed
 * (new/removed domain, new certificate, different backend port), so an idle
 * server never reloads OpenLiteSpeed.
 */
function do_engine_sync_check($root)
{
    if (!is_dir(EXTENGINE_DIR)) {
        @mkdir(EXTENGINE_DIR, 0750, true);
    }
    $lock = @fopen(EXTENGINE_DIR . '/sync.lock', 'c');
    if ($lock === false || !flock($lock, LOCK_EX | LOCK_NB)) {
        return array('ok' => true, 'changed' => false, 'skipped' => 'busy');
    }

    $state = engine_read_state();
    if (!isset($state['mode']) || $state['mode'] !== 'ols-front') {
        return array('ok' => true, 'changed' => false, 'skipped' => 'not-ols-front');
    }

    $facts = plesk_front_facts();
    if (count($facts['ips']) === 0) {
        return array('ok' => true, 'changed' => false, 'skipped' => 'no-web-ip');
    }

    $fingerprint = front_fingerprint($facts);
    if (isset($state['front_fingerprint']) && $state['front_fingerprint'] === $fingerprint) {
        return array('ok' => true, 'changed' => false);
    }

    $result = do_engine_sync($root);
    $result['changed'] = true;

    return $result;
}

/** Install or remove the timer that keeps the front in sync with Plesk. */
function front_cron_write($install)
{
    $wrapper = dirname(__FILE__) . '/openlitespeed';
    if ($install) {
        if (!is_dir(dirname(FRONT_CRON_FILE))) {
            return array('ok' => false, 'error' => '/etc/cron.d does not exist; automatic sync was not installed.');
        }
        $lines = array(
            '# Managed by the Plesk "openlitespeed" extension.',
            '# Keeps the OpenLiteSpeed web front in sync with Plesk domains and certificates.',
            '# Deleting this file disables automatic sync; the extension re-creates it on the next switch.',
            FRONT_CRON_INTERVAL . ' root ' . $wrapper . ' --action=engine-sync-check >/dev/null 2>&1',
            '',
        );
        @file_put_contents(FRONT_CRON_FILE, implode("\n", $lines));
        @chmod(FRONT_CRON_FILE, 0644);
    } else {
        @unlink(FRONT_CRON_FILE);
    }

    return array(
        'ok' => true,
        'installed' => $install ? true : false,
        'file' => FRONT_CRON_FILE,
        'auto_sync' => file_exists(FRONT_CRON_FILE),
    );
}

function action_engine_status($root)
{
    $facts = plesk_front_facts();
    $state = engine_read_state();
    $nginx = nginx_service_name();
    $apache = apache_service_name();
    $phpMode = isset($state['php_mode']) && in_array($state['php_mode'], PHP_MODES, true)
        ? $state['php_mode'] : PHP_BACKEND;

    $frontListeners = array();
    foreach (parse_listeners($root) as $listener) {
        $address = (string) $listener['address'];
        if (preg_match('/:(80|443)$/', $address)) {
            $frontListeners[] = $listener;
        }
    }

    $directDomains = 0;
    foreach ($facts['domains'] as $domain) {
        if (!empty($domain['php_direct'])) {
            $directDomains++;
        }
    }

    return array(
        'ok' => true,
        'mode' => isset($state['mode']) ? $state['mode'] : 'unknown',
        'state' => $state,
        'front_installed' => front_block_installed($root),
        'auto_sync' => file_exists(FRONT_CRON_FILE),
        'front_listeners' => $frontListeners,
        'ols_running' => service_state($root),
        'nginx_service' => $nginx,
        'nginx_active' => service_active($nginx),
        'apache_service' => $apache,
        'apache_active' => service_active($apache),
        'php_mode' => $phpMode,
        'php_modes' => PHP_MODES,
        'php_direct_domains' => $directDomains,
        'apache_needed' => front_apache_needed($facts, $phpMode) > 0,
        'worker_group' => front_worker_group($root),
        'worker_group_target' => PLESK_WEB_GROUP,
        'os' => os_info(),
        'admin_console' => admin_console_info($root),
        'domains' => $facts['domains'],
        'panel' => isset($facts['panel']) ? $facts['panel'] : null,
        'panel_status' => isset($state['panel_status']) ? $state['panel_status'] : null,
        'ips' => $facts['ips'],
        'http_backend' => $facts['http_backend'],
        'https_backend' => $facts['https_backend'],
        'default_cert' => $facts['default_cert'],
    );
}

/**
 * First-run setup wizard state. The flag file lives in the extension var
 * directory, so removing the extension and installing it again asks once more.
 */
function setup_state_file()
{
    return EXTENGINE_DIR . '/setup.json';
}

function setup_log_file()
{
    return EXTENGINE_DIR . '/setup.log';
}

/**
 * The worker writes its own process id here before it touches anything else, so
 * the panel page can tell a running setup apart from an interrupted one even when
 * the state file was written by the request that spawned the worker.
 */
function setup_pid_file()
{
    return EXTENGINE_DIR . '/setup.pid';
}

function setup_defaults()
{
    return array(
        'onboarded' => false,
        'stage' => 'welcome',
        'php_mode' => PHP_DIRECT,
        'worker_pid' => null,
        'started_at' => null,
        'finished_at' => null,
        'error' => null,
        'steps' => array(),
    );
}

function setup_read_state()
{
    $data = is_file(setup_state_file())
        ? json_decode((string) @file_get_contents(setup_state_file()), true)
        : null;
    if (!is_array($data)) {
        return setup_defaults();
    }

    return array_merge(setup_defaults(), $data);
}

function setup_write_state(array $state)
{
    if (!is_dir(EXTENGINE_DIR)) {
        @mkdir(EXTENGINE_DIR, 0750, true);
    }
    $state['updated'] = date('c');
    @file_put_contents(
        setup_state_file(),
        json_encode($state, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES),
        LOCK_EX
    );
    @chmod(setup_state_file(), 0640);

    return $state;
}

/**
 * The wizard page shows the recorded steps while the detached worker runs, so
 * progress has to survive between requests.
 */
function setup_progress(array $state, $stage, $detail = null, $error = null)
{
    $state['stage'] = $stage;
    if ($detail !== null) {
        $state['steps'][] = date('H:i:s') . ' ' . $detail;
        $state['steps'] = array_slice($state['steps'], -25);
    }
    if ($error !== null) {
        $state['error'] = $error;
        $state['finished_at'] = date('c');
    } elseif (in_array($stage, SETUP_DONE_STAGES, true)) {
        $state['finished_at'] = date('c');
    }

    return setup_write_state($state);
}

function setup_stage_running($state)
{
    if (!in_array($state['stage'], SETUP_RUNNING_STAGES, true)) {
        return false;
    }

    $pid = isset($state['worker_pid']) ? (int) $state['worker_pid'] : 0;
    if ($pid <= 0 && is_file(setup_pid_file())) {
        $pid = (int) trim((string) @file_get_contents(setup_pid_file()));
    }
    if ($pid > 0) {
        if (!process_is_worker($pid)) {
            return false;
        }
        // A live worker that outlived the hard cap is stuck in the package
        // manager; the page has to let the administrator read the log instead of
        // promising an answer that will never arrive.
        if ($state['started_at'] !== null) {
            $started = strtotime((string) $state['started_at']);
            if ($started !== false && time() - $started > SETUP_WORKER_TIMEOUT) {
                return false;
            }
        }

        return true;
    }

    // No worker ever announced itself: give it the start grace, then treat the
    // stage as interrupted instead of letting the page claim progress for the
    // whole worker timeout.
    if ($state['started_at'] === null) {
        return false;
    }
    $started = strtotime((string) $state['started_at']);

    return $started !== false && time() - $started <= SETUP_WORKER_START_GRACE;
}

/**
 * A process id out of our own state file can have been recycled by any other
 * program, so the command line has to be the setup worker before it counts.
 */
function process_is_worker($pid)
{
    $cmdline = @file_get_contents('/proc/' . (int) $pid . '/cmdline');
    if ($cmdline === false) {
        return false;
    }

    return strpos((string) str_replace("\0", ' ', $cmdline), 'setup-worker') !== false;
}

function setup_write_pid()
{
    if (!is_dir(EXTENGINE_DIR)) {
        @mkdir(EXTENGINE_DIR, 0750, true);
    }
    @file_put_contents(setup_pid_file(), (string) getmypid());
    @chmod(setup_pid_file(), 0640);
}

function setup_clear_pid()
{
    if (!is_file(setup_pid_file())) {
        return;
    }
    $recorded = (int) trim((string) @file_get_contents(setup_pid_file()));
    if ($recorded === getmypid() || $recorded <= 0) {
        @unlink(setup_pid_file());
    }
}

/**
 * What the distribution package manager would be asked to do, or the reason why
 * this operating system has no supported OpenLiteSpeed repository.
 */
function openlitespeed_install_plan()
{
    $os = os_info();
    $family = isset($os['family']) ? $os['family'] : null;
    $name = !empty($os['name']) ? $os['name'] : (isset($os['id']) ? $os['id'] : 'this operating system');
    $arch = strtolower(trim((string) php_uname('m')));

    $plan = array('supported' => false, 'family' => $family, 'reason' => null,
        'reason_key' => null, 'reason_params' => array(),
        'summary' => null, 'manager' => null, 'manager_path' => null,
        'package' => OPENLITESPEED_PACKAGE, 'repo_file' => null, 'baseurl' => null,
        'baseurl_update' => null, 'release' => null, 'arch' => $arch,
        'codename' => null, 'keys' => array(), 'optional_repo' => null,
        'os' => $name . (empty($os['version']) ? '' : ' ' . $os['version']));

    if ($family === 'rhel') {
        $id = isset($os['id']) ? $os['id'] : '';
        if (!in_array($id, OPENLITESPEED_RHEL_IDS, true)) {
            return openlitespeed_plan_reject($plan,
                'The LiteSpeed repository publishes OpenLiteSpeed for Debian, Ubuntu and Red Hat based systems; {0} is not one of them.',
                array($plan['os']));
        }
        $major = openlitespeed_major_version(isset($os['version']) ? $os['version'] : null);
        if ($major === null || !isset(OPENLITESPEED_RHEL_MAJORS[$major])) {
            return openlitespeed_plan_reject($plan,
                'The LiteSpeed repository has no OpenLiteSpeed 1.8+ package for {0}.',
                array($plan['os']));
        }
        if (!isset(OPENLITESPEED_RHEL_ARCHES[$arch])) {
            return openlitespeed_plan_reject($plan,
                'The LiteSpeed repository has no OpenLiteSpeed build for the {0} architecture.',
                array($arch));
        }
        $manager = command_path(array('dnf', 'yum'));
        if ($manager === null) {
            return openlitespeed_plan_reject($plan,
                'No dnf or yum package manager was found on this system.', array());
        }
        $plan['supported'] = true;
        $plan['manager'] = basename($manager);
        $plan['manager_path'] = $manager;
        $plan['baseurl'] = OPENLITESPEED_RHEL_BASE . $major . '/' . $arch . '/';
        $plan['baseurl_update'] = OPENLITESPEED_RHEL_BASE . $major . '/update/' . $arch . '/';
        $plan['release'] = $major;
        $plan['arch'] = $arch;
        $plan['repo_file'] = '/etc/yum.repos.d/openlitespeed-stable.repo';
        $plan['keys'][] = array(
            'url' => openlitespeed_rhel_key_url($major),
            'file' => OPENLITESPEED_RHEL_KEY_FILE,
        );
        $plan['optional_repo'] = isset(OPENLITESPEED_RHEL_OPTIONAL_REPO[$major])
            ? OPENLITESPEED_RHEL_OPTIONAL_REPO[$major] : null;
        $plan['summary'] = basename($manager) . ' install ' . OPENLITESPEED_PACKAGE
            . ' (centos/' . $major . '/' . $arch . ' + update)';
    } elseif ($family === 'debian') {
        $codename = isset($os['codename']) ? $os['codename'] : null;
        if ($codename === null || !in_array($codename, OPENLITESPEED_DEBIAN_CODENAMES, true)) {
            return openlitespeed_plan_reject($plan,
                'The LiteSpeed repository has no package set for {0}.',
                array($plan['os'] . ($codename === null ? '' : ' (' . $codename . ')')));
        }
        if (!isset(OPENLITESPEED_DEBIAN_ARCHES[$arch])) {
            return openlitespeed_plan_reject($plan,
                'The LiteSpeed repository has no OpenLiteSpeed build for the {0} architecture.',
                array($arch));
        }
        $apt = command_path(array('apt-get'));
        if ($apt === null) {
            return openlitespeed_plan_reject($plan,
                'No apt-get package manager was found on this system.', array());
        }
        $plan['supported'] = true;
        $plan['manager'] = 'apt-get';
        $plan['manager_path'] = $apt;
        $plan['baseurl'] = OPENLITESPEED_DEBIAN_BASE;
        $plan['codename'] = $codename;
        $plan['repo_file'] = '/etc/apt/sources.list.d/openlitespeed-stable.list';
        foreach (OPENLITESPEED_DEBIAN_KEYS as $key) {
            $plan['keys'][] = array('url' => OPENLITESPEED_DEBIAN_BASE . $key,
                'file' => OPENLITESPEED_DEBIAN_TRUST_DIR . '/' . $key);
        }
        $plan['summary'] = 'apt-get install ' . OPENLITESPEED_PACKAGE
            . ' (debian/' . $codename . ' ' . OPENLITESPEED_DEBIAN_ARCHES[$arch] . ')';
    } else {
        return openlitespeed_plan_reject($plan,
            'The LiteSpeed repository publishes OpenLiteSpeed for Debian, Ubuntu and Red Hat based systems; {0} is not one of them.',
            array($plan['os']));
    }

    return $plan;
}

/**
 * The reason is shown on the panel page, so the English sentence the helper logs
 * is paired with a translatable template the panel can put in Turkish word order.
 */
function openlitespeed_plan_reject(array $plan, $template, array $params)
{
    $text = $template;
    foreach ($params as $index => $value) {
        $text = str_replace('{' . $index . '}', (string) $value, $text);
    }
    $plan['reason'] = $text;
    $plan['reason_key'] = $template;
    $plan['reason_params'] = array_values($params);

    return $plan;
}

/**
 * First digit of the distribution version, which is what the LiteSpeed
 * repository uses for its per-major directories.
 */
function openlitespeed_major_version($version)
{
    $version = trim((string) $version);
    if ($version === '' || !preg_match('/^(\d+)/', $version, $m)) {
        return null;
    }

    return $m[1];
}

/**
 * LiteSpeed rotated its signing key for the builds published from 2025, and the
 * bootstrap picks the file by major release while installing it under the old
 * name; the repository file therefore always references one path.
 */
function openlitespeed_rhel_key_url($major)
{
    return ((int) $major >= OPENLITESPEED_RHEL_KEY_2025_FROM)
        ? OPENLITESPEED_RHEL_KEY_URL_2025 : OPENLITESPEED_RHEL_KEY_URL;
}

function command_path(array $names)
{
    foreach ($names as $name) {
        foreach (array('/usr/bin/', '/bin/', '/usr/sbin/', '/sbin/', '/usr/local/bin/') as $dir) {
            if (is_executable($dir . $name)) {
                return $dir . $name;
            }
        }
        $found = trim((string) @exec('command -v ' . escapeshellarg($name) . ' 2>/dev/null'));
        if ($found !== '' && is_executable($found)) {
            return $found;
        }
    }

    return null;
}

/**
 * LiteSpeed sells a licensed web server under the same install prefix. Mixing
 * the two would break the switch, so the enterprise build stops the wizard.
 */
function openlitespeed_enterprise_installed()
{
    $os = os_info();
    $family = isset($os['family']) ? $os['family'] : null;
    if ($family === 'rhel') {
        list($code) = run(array('rpm', '-q', 'litespeed'));
        if ($code === 0) {
            return true;
        }
    } elseif ($family === 'debian') {
        list($code) = run(array('dpkg', '-s', 'litespeed'));
        if ($code === 0) {
            return true;
        }
    }

    return is_file('/usr/local/lsws/license');
}

function fetch_to_file($url, $dest)
{
    $curl = curl_binary();
    if ($curl !== null) {
        list($code) = run(array($curl, '-sS', '-L', '-m', '60', '-o', $dest, $url));
        if ($code === 0) {
            return is_file($dest) && filesize($dest) > 0;
        }

        return false;
    }
    $wget = command_path(array('wget'));
    if ($wget === null) {
        return false;
    }
    list($code) = run(array($wget, '-q', '-O', $dest, $url));

    return $code === 0 && is_file($dest) && filesize($dest) > 0;
}

/**
 * Install OpenLiteSpeed itself with the distribution package manager. Plesk
 * configuration, nginx and Apache are not touched. The package pulls LiteSpeed's
 * own PHP build as a dependency, but the front never uses it: PHP keeps running
 * through the Plesk php-fpm pools.
 */
function openlitespeed_install(array $plan)
{
    $addLog = function ($line) {
        @file_put_contents(setup_log_file(), date('Y-m-d H:i:s') . ' ' . $line . "\n", FILE_APPEND);
    };

    $repoText = openlitespeed_repo_text($plan);
    if ($repoText === null) {
        return array(false, 'No OpenLiteSpeed repository recipe is known for this operating system.');
    }
    if (openlitespeed_enterprise_installed()) {
        return array(false, 'The paid LiteSpeed Web Server package is installed on this system; OpenLiteSpeed must not be installed over it.');
    }

    // Everything we create is removed again when the install fails, so a failed
    // attempt cannot leave a broken repository behind.
    $created = array();
    $cleanup = function () use ($created, $addLog) {
        foreach ($created as $path) {
            if (@unlink($path)) {
                $addLog('removed ' . $path);
            }
        }
    };

    foreach ($plan['keys'] as $key) {
        // The path of a signing key is fixed but its content is not: LiteSpeed
        // rotated the key for the builds published from 2025, so a file an earlier
        // run left behind can be the wrong key. The recipe's own copy decides, and
        // a copy that is already there is only kept when the download fails.
        $present = is_file($key['file']) && filesize($key['file']) > 0;
        $temporary = $key['file'] . '.openlitespeed-new';
        if (fetch_to_file($key['url'], $temporary) && is_file($temporary) && filesize($temporary) > 0) {
            @chmod($temporary, 0644);
            if (!@rename($temporary, $key['file'])) {
                @unlink($temporary);
                if (!$present) {
                    $cleanup();

                    return array(false, 'Unable to write ' . $key['file']);
                }
            } elseif (!$present) {
                $created[] = $key['file'];
            }
            $addLog('signing key in place: ' . $key['file'] . ' from ' . $key['url']);
            continue;
        }
        @unlink($temporary);
        if ($present) {
            $addLog('signing key kept: ' . $key['file']);
            continue;
        }
        $cleanup();

        return array(false, 'Unable to download the LiteSpeed signing key from ' . $key['url']);
    }

    $repoFile = $plan['repo_file'];
    $existedBefore = is_file($repoFile);
    // An earlier version of this extension wrote a single, incomplete repository
    // set, so the file is rewritten whenever it differs from the recipe. Only a
    // file this run created is removed again when the install fails.
    if (!$existedBefore || (string) @file_get_contents($repoFile) !== $repoText) {
        if (@file_put_contents($repoFile, $repoText) === false) {
            $cleanup();

            return array(false, 'Unable to write ' . $repoFile);
        }
        @chmod($repoFile, 0644);
        if (!$existedBefore) {
            $created[] = $repoFile;
        }
    }
    $addLog('repository file ' . $repoFile . ($existedBefore ? ' refreshed' : ' created'));

    if ($plan['family'] === 'debian') {
        putenv('DEBIAN_FRONTEND=noninteractive');
        list($code, $out) = run(array('apt-get', 'update', '-qq'));
        $addLog('apt-get update exit=' . $code . ' ' . tail_text($out, 300));
        if ($code !== 0) {
            $cleanup();

            return array(false, 'apt-get update failed: ' . tail_text($out, 500));
        }
        list($code, $out) = run(array_merge(
            array($plan['manager_path'], 'install', '-y', '--no-install-recommends'),
            OPENLITESPEED_DEB_OPTIONS,
            array($plan['package'])
        ));
    } else {
        if ($plan['optional_repo'] !== null) {
            // The repository may already be enabled, or named differently on a
            // rebuild; the install itself reports a real dependency failure.
            list($sub, $subOut) = run(array($plan['manager_path'], '-y', 'config-manager',
                '--set-enabled', $plan['optional_repo']));
            $addLog('enabled ' . $plan['optional_repo'] . ' exit=' . $sub . ' ' . tail_text($subOut, 200));
        }
        list($sub, $subOut) = run(array('rpm', '--import', $plan['keys'][0]['file']));
        $addLog('signing key imported exit=' . $sub . ' ' . tail_text($subOut, 200));

        // --refresh: the metadata of a repository id this server has tried before
        // can still be cached and empty, which makes the package look unavailable.
        list($code, $out) = run(array($plan['manager_path'], '-q', '-y', '--refresh',
            'list', 'available', $plan['package']));
        $addLog('availability exit=' . $code . ' ' . tail_text($out, 300));
        if ($code !== 0 || strpos($out, $plan['package']) === false) {
            list($sub, $subOut) = run(array($plan['manager_path'], '-q', '-y', 'repolist'));
            $addLog('repolist exit=' . $sub . ' ' . tail_text($subOut, 600));

            // The dynamic part is kept at the end so the panel can translate the
            // sentence and leave the URL as the helper wrote it.
            return array(false, 'The LiteSpeed repository offered no OpenLiteSpeed package for this operating system. Check that this server can reach '
                . $plan['baseurl'] . ' ' . tail_text($out, 300));
        }
        // The metadata is now refreshed by the check above, so the install itself
        // does not have to download it a second time.
        list($code, $out) = run(array($plan['manager_path'], '-y', 'install', $plan['package']));
        if ($code !== 0 && preg_match('/nothing (provides|requires)/i', $out, $m)) {
            // A dependency that is not in the distribution base repositories;
            // naming it is far more useful than letting the package manager text
            // scroll past inside the setup log.
            $addLog('dependency failure: ' . tail_text($out, 900));
            $missing = preg_match_all('/nothing provides (\S+)/i', $out, $found)
                ? implode(', ', array_unique($found[1])) : trim($m[0]);

            return array(false, 'The OpenLiteSpeed package has a dependency this server cannot resolve. Enable the optional channel repository (crb or powertools) or Extra Packages for Enterprise Linux, then run the setup again. Missing: '
                . $missing);
        }
    }
    $addLog('install exit=' . $code . ' ' . tail_text($out, 400));

    $root = detect_root();
    if ($root === null) {
        $cleanup();

        return array(false, 'OpenLiteSpeed is still not present after the package manager finished: '
            . tail_text($out, 700));
    }

    // The package starts its own listener on 8088/7080 during post-install; the
    // web front switch decides when OpenLiteSpeed may run.
    $systemctl = find_systemctl();
    if ($systemctl !== null) {
        list($sub, $subOut) = run(array($systemctl, 'disable', '--now', 'lsws'));
        $addLog('lsws stopped and disabled until the switch exit=' . $sub . ' ' . tail_text($subOut, 150));
    }
    $addLog('OpenLiteSpeed ' . detect_version($root) . ' installed at ' . $root);

    return array(true, 'OpenLiteSpeed ' . detect_version($root) . ' installed at ' . $root);
}

function openlitespeed_repo_text(array $plan)
{
    if ($plan['family'] === 'rhel' && !empty($plan['baseurl'])) {
        // The current builds are published in the release repository, the rebuilds
        // that carry fixes in the update one, so both are needed to install the
        // newest package. The section ids are ours rather than LiteSpeed's, so an
        // existing repository bootstrap file of the administrator is never shadowed.
        $text = "# Added by the Plesk \"openlitespeed\" extension; the same repositories\n"
            . "# the LiteSpeed repository bootstrap writes for " . $plan['os'] . ".\n"
            . "[openlitespeed]\n"
            . "name=LiteSpeed Tech Repository for CentOS " . $plan['release'] . ' - ' . $plan['arch'] . "\n"
            . "baseurl=" . $plan['baseurl'] . "\n"
            . "enabled=1\n"
            . "gpgcheck=1\n"
            . "gpgkey=file://" . OPENLITESPEED_RHEL_KEY_FILE . "\n"
            . "\n[openlitespeed-update]\n"
            . "name=LiteSpeed Tech Update Repository for CentOS " . $plan['release'] . ' - ' . $plan['arch'] . "\n"
            . "baseurl=" . $plan['baseurl_update'] . "\n"
            . "enabled=1\n"
            . "gpgcheck=1\n"
            . "gpgkey=file://" . OPENLITESPEED_RHEL_KEY_FILE . "\n";

        return $text;
    }
    if ($plan['family'] === 'debian' && !empty($plan['codename'])) {
        return "# Added by the Plesk \"openlitespeed\" extension.\n"
            . 'deb ' . $plan['baseurl'] . ' ' . $plan['codename'] . " main\n";
    }

    return null;
}

/**
 * Detached worker: installs OpenLiteSpeed when it is missing, then switches the
 * web front. Running it outside the panel request is the only way a package
 * install can survive the API timeout.
 */
function do_setup_worker($phpMode)
{
    setup_write_pid();
    // A PHP error here would otherwise leave the stage running with nobody behind
    // it, so the shutdown path records the failure the wizard has to show.
    register_shutdown_function(function () {
        $error = error_get_last();
        $state = setup_read_state();
        if ($error !== null && in_array($error['type'], array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR), true)
            && in_array($state['stage'], SETUP_RUNNING_STAGES, true)) {
            $message = 'The setup worker stopped with a PHP error: ' . $error['message'];
            setup_progress($state, 'failed', $message, $message);
        }
        setup_clear_pid();
    });

    $state = setup_read_state();
    $state['worker_pid'] = getmypid();
    $state = setup_progress($state, 'installing', 'Setup worker started.');

    $root = detect_root();
    if ($root === null) {
        $plan = openlitespeed_install_plan();
        if (!$plan['supported']) {
            $message = $plan['reason'] !== null
                ? $plan['reason']
                : 'This operating system has no supported OpenLiteSpeed package recipe; install it first.';
            setup_progress($state, 'failed', $message, $message);

            return emit(array('ok' => false, 'error' => $message));
        }
        $state = setup_progress($state, 'installing', 'Installing with ' . $plan['summary'] . '.');
        list($installed, $message) = openlitespeed_install($plan);
        if (!$installed) {
            setup_progress($state, 'failed', $message, $message);

            return emit(array('ok' => false, 'error' => $message));
        }
        setup_progress($state, 'configuring', $message);
        $root = detect_root();
    } else {
        $state = setup_progress($state, 'switching', 'OpenLiteSpeed ' . detect_version($root) . ' is already installed.');
    }

    if (!is_plain_config($root)) {
        $message = 'The web front switch needs OpenLiteSpeed 1.8+ with plain-text configuration; this server uses the legacy XML format.';
        setup_progress($state, 'failed', $message, $message);

        return emit(array('ok' => false, 'error' => $message));
    }
    $facts = plesk_front_facts();
    if (count($facts['ips']) === 0) {
        $message = 'No Plesk web IP address could be detected from the nginx configuration; nothing was changed.';
        setup_progress($state, 'failed', $message, $message);

        return emit(array('ok' => false, 'error' => $message));
    }

    $state = setup_progress($state, 'switching', 'Building the front configuration and switching 80/443.');
    $result = do_switch_ols($root, $phpMode);
    $ok = !empty($result['ok']);
    if ($ok) {
        $note = empty($result['apache_disabled'])
            ? 'OpenLiteSpeed is the web front; a few domains still need the Apache backend.'
            : 'OpenLiteSpeed is the web front, PHP runs without Apache and Apache is stopped.';
        $state['php_mode'] = $phpMode;
        $state = setup_progress($state, 'ready', $note);
        setup_write_state(array_merge($state, array('onboarded' => true)));
    } else {
        $error = isset($result['error']) ? (string) $result['error'] : 'The switch failed and was rolled back.';
        setup_progress($state, 'failed', $error, $error);
    }

    return emit(array('ok' => $ok, 'stage' => $ok ? 'ready' : 'failed',
        'switch' => isset($result['mode']) ? $result['mode'] : null));
}

function do_setup_status($root, $lite = false)
{
    $state = setup_read_state();
    $running = setup_stage_running($state);
    if (!$running && in_array($state['stage'], SETUP_RUNNING_STAGES, true)) {
        // A worker that is alive but past the hard cap is stuck inside the package
        // manager; saying so keeps the administrator from starting a second one.
        $pid = isset($state['worker_pid']) ? (int) $state['worker_pid'] : 0;
        $message = ($pid > 0 && process_is_worker($pid))
            ? 'The setup worker is still waiting for the package manager and has not reported for a long time. Read the setup log, and let the package manager finish before you run the setup again.'
            : 'The setup process stopped before it finished.';
        $state = setup_progress($state, 'failed', null, $message);
    }
    // Only the administrator can close the welcome page, by being shown once.
    // An already running front counts as finished the moment the page renders,
    // so a reinstall asks again but never traps the panel in a redirect loop.
    $onboarded = !empty($state['onboarded']);

    if ($lite) {
        return array(
            'ok' => true,
            'lite' => true,
            'onboarded' => $onboarded,
            'stage' => $state['stage'],
            'running' => $running,
            'error' => $state['error'],
            'php_mode' => $state['php_mode'],
            'installed' => $root !== null,
        );
    }

    $facts = plesk_front_facts();
    $directDomains = 0;
    foreach ($facts['domains'] as $domain) {
        if (!empty($domain['php_direct'])) {
            $directDomains++;
        }
    }
    $plan = openlitespeed_install_plan();
    $engine = engine_read_state();

    return array(
        'ok' => true,
        'onboarded' => $onboarded,
        'stage' => $state['stage'],
        'running' => $running,
        'steps' => $state['steps'],
        'error' => $state['error'],
        'started_at' => $state['started_at'],
        'php_mode' => $state['php_mode'],
        'installed' => $root !== null,
        'root' => $root,
        'version' => $root !== null ? detect_version($root) : null,
        'config_format' => $root !== null ? (is_plain_config($root) ? 'plain' : 'xml') : null,
        'install_supported' => $plan['supported'],
        'install_summary' => $plan['summary'],
        'install_reason' => $plan['reason'],
        'install_reason_key' => $plan['reason_key'],
        'install_reason_params' => $plan['reason_params'],
        'os' => os_info(),
        'nginx_service' => nginx_service_name(),
        'apache_service' => apache_service_name(),
        'engine_mode' => isset($engine['mode']) ? $engine['mode'] : 'unknown',
        'front_installed' => $root !== null && front_block_installed($root),
        'ols_running' => $root !== null ? service_state($root) : array('running' => false),
        'domains' => count($facts['domains']),
        'php_direct_domains' => $directDomains,
        'log' => tail_file(setup_log_file(), 40),
    );
}

function do_setup_run($root, $phpMode)
{
    $state = setup_read_state();
    if (setup_stage_running($state)) {
        return array('ok' => true, 'started' => false, 'running' => true, 'stage' => $state['stage']);
    }

    if (!in_array($phpMode, PHP_MODES, true)) {
        $phpMode = PHP_DIRECT;
    }
    if ($root === null && !openlitespeed_install_plan()['supported']) {
        fail('This operating system has no supported OpenLiteSpeed package recipe; install it first.');
    }
    if ($root !== null && !is_plain_config($root)) {
        fail('The web front switch needs OpenLiteSpeed 1.8+ with plain-text configuration; this server uses the legacy XML format.');
    }
    if (nginx_service_name() === null) {
        fail('The nginx service was not found; refusing to switch without a reversible path back.');
    }

    $wrapper = dirname(__FILE__) . '/openlitespeed';
    if (!is_executable($wrapper)) {
        fail('The OpenLiteSpeed helper is not executable: ' . $wrapper);
    }

    $setsid = null;
    foreach (array('/usr/bin/setsid', '/bin/setsid') as $candidate) {
        if (is_executable($candidate)) {
            $setsid = $candidate;
            break;
        }
    }

    $line = 'nohup ' . ($setsid !== null ? escapeshellarg($setsid) . ' ' : '')
        . escapeshellarg($wrapper) . ' --action=setup-worker --php-mode=' . escapeshellarg($phpMode)
        . ' >> ' . escapeshellarg(setup_log_file()) . ' 2>&1 < /dev/null &';

    // The state goes down before the worker is started: the worker writes its own
    // progress the moment it runs, and a state written afterwards would erase it,
    // leaving the page with a start line and no worker id to check.
    @unlink(setup_pid_file());
    $state = setup_write_state(array_merge(setup_defaults(), array(
        'onboarded' => false,
        'php_mode' => $phpMode,
        'stage' => $root === null ? 'installing' : 'switching',
        'started_at' => date('c'),
        'steps' => array(date('H:i:s') . ' Setup started from the panel.'),
    )));

    $output = array();
    $code = 0;
    exec($line, $output, $code);
    if ($code !== 0) {
        $message = 'The setup worker could not be started: ' . tail_text(implode("\n", $output), 300);
        setup_progress($state, 'failed', $message, $message);

        return array('ok' => false, 'started' => false, 'running' => false,
            'stage' => 'failed', 'error' => $message);
    }

    return array('ok' => true, 'started' => true, 'running' => true,
        'stage' => $state['stage'], 'error' => null);
}

function do_setup_skip()
{
    $state = setup_read_state();
    if (setup_stage_running($state)) {
        return array('ok' => false, 'error' => 'The setup process is still running.');
    }
    $state = setup_write_state(array_merge($state, array('onboarded' => true, 'stage' => 'skipped',
        'error' => null)));

    return array('ok' => true, 'stage' => $state['stage']);
}

function do_setup_done()
{
    $state = setup_read_state();
    if (setup_stage_running($state)) {
        return array('ok' => true, 'stage' => $state['stage'], 'onboarded' => false);
    }
    $state = setup_write_state(array_merge($state, array('onboarded' => true)));

    return array('ok' => true, 'stage' => $state['stage'], 'onboarded' => true);
}

function do_setup_reset()
{
    @unlink(setup_state_file());
    @unlink(setup_log_file());
    @unlink(setup_pid_file());

    return array('ok' => true, 'stage' => 'welcome', 'onboarded' => false);
}

/* ------------------------------------------------------------------ *
 * Self-update: read the release feed, then install a package that has been
 * verified to be this extension and to be newer. Only the module files change:
 * the generated web front, its certificates and the engine state live outside
 * the module directory and are never touched by an upgrade.
 * ------------------------------------------------------------------ */

function update_cache_file()
{
    return EXTENGINE_DIR . '/update.json';
}

function update_marker_file()
{
    return EXTENGINE_DIR . '/upgrading.json';
}

function update_read($file)
{
    if (!is_file($file)) {
        return null;
    }
    $data = json_decode((string) @file_get_contents($file), true);

    return is_array($data) ? $data : null;
}

function update_write($file, array $data)
{
    if (!is_dir(EXTENGINE_DIR)) {
        @mkdir(EXTENGINE_DIR, 0750, true);
    }
    @file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX);
    @chmod($file, 0640);

    return $data;
}

function extension_meta_file()
{
    foreach (array(
        '/usr/local/psa/admin/plib/modules/' . EXTENSION_ID . '/meta.xml',
        '/opt/psa/admin/plib/modules/' . EXTENSION_ID . '/meta.xml',
    ) as $candidate) {
        if (is_file($candidate)) {
            return $candidate;
        }
    }

    return null;
}

function meta_version($text)
{
    if (preg_match('/<version>\s*([0-9]+(?:\.[0-9]+)*)\s*<\/version>/i', (string) $text, $m)) {
        return $m[1];
    }

    return null;
}

function installed_extension_version()
{
    $file = extension_meta_file();
    if ($file === null) {
        return null;
    }

    return meta_version((string) @file_get_contents($file, false, null, 0, 65536));
}

/**
 * A release tag is free text ("v1.3.9", "1.3.9"); only a plain dotted number can
 * be compared, and anything else is reported as no update rather than guessed at.
 */
function update_tag_version($tag)
{
    $tag = strtolower(trim((string) $tag));
    if (strpos($tag, 'v') === 0) {
        $tag = substr($tag, 1);
    }

    return preg_match('/^[0-9]+(?:\.[0-9]+)*$/', $tag) ? $tag : null;
}

function update_url_allowed($url)
{
    if (!is_string($url) || strpos($url, 'https://') !== 0) {
        return false;
    }
    $host = strtolower((string) parse_url($url, PHP_URL_HOST));

    // GitHub's own hosts only: the repository's raw files and the CDN that serves
    // release assets. Nothing else on the internet can hand us a package.
    return update_host_ends_with($host, 'github.com') || update_host_ends_with($host, 'githubusercontent.com');
}

function update_host_ends_with($host, $domain)
{
    return $host === $domain || substr($host, -(strlen($domain) + 1)) === '.' . $domain;
}

/**
 * curl only ever speaks HTTPS here, the answer is capped, and whatever it returns
 * still has to pass update_package_verifies() before Plesk is asked to install it.
 */
function http_download($url, $destination, $maxBytes, $timeout)
{
    if (!update_url_allowed($url)) {
        return array(false, 'The download address is not an HTTPS GitHub address.');
    }

    $curl = curl_binary();
    if ($curl === null) {
        return array(false, 'curl is not available on this server, so the update cannot be downloaded.');
    }

    list($code, $out) = run(array(
        $curl, '--silent', '--show-error', '--location', '--proto', '=https',
        '--max-time', (string) $timeout, '--max-filesize', (string) $maxBytes,
        '--output', $destination, $url,
    ));
    if ($code !== 0) {
        return array(false, 'The download failed: ' . substr($out, -400));
    }
    if (!is_file($destination) || (int) @filesize($destination) <= 0) {
        return array(false, 'The download came back empty.');
    }
    if ((int) @filesize($destination) > $maxBytes) {
        return array(false, 'The downloaded file is larger than the allowed limit.');
    }

    return array(true, null);
}

function unzip_binary()
{
    foreach (array('/usr/bin/unzip', '/bin/unzip', '/usr/local/bin/unzip') as $candidate) {
        if (is_executable($candidate)) {
            return $candidate;
        }
    }

    return null;
}

function update_meta_from_zip($zipFile)
{
    $unzip = unzip_binary();
    if ($unzip === null) {
        return null;
    }
    list($code, $out) = run(array($unzip, '-p', $zipFile, 'meta.xml'));

    return $code === 0 && trim($out) !== '' ? $out : null;
}

/**
 * Everything that has to hold before Plesk is asked to install the package: it is
 * this extension, it carries the version the feed announced, and it is newer than
 * what is installed. A package that fails here is deleted, never installed.
 */
function update_package_verifies($zipFile, $expected, $current)
{
    $size = is_file($zipFile) ? @filesize($zipFile) : false;
    if ($size === false || $size < 1024) {
        return array('ok' => false, 'error' => 'The downloaded package is empty or too small to be an extension.');
    }

    $meta = update_meta_from_zip($zipFile);
    if ($meta === null) {
        return array('ok' => false, 'error' => 'The package has no readable meta.xml, so it is not a Plesk extension.');
    }
    if (!preg_match('/<id>\s*' . preg_quote(EXTENSION_ID, '/') . '\s*<\/id>/i', $meta)) {
        return array('ok' => false, 'error' => 'The package is a different extension than this one.');
    }

    $version = meta_version($meta);
    if ($version === null) {
        return array('ok' => false, 'error' => 'The package does not declare a version.');
    }
    if ($version !== $expected) {
        return array('ok' => false, 'error' => 'The package is version ' . $version . ' but the release announced '
            . $expected . '.');
    }
    if ($current !== null && version_compare($version, $current) <= 0) {
        return array('ok' => false, 'error' => 'The package is not newer than the installed version.');
    }

    return array('ok' => true, 'error' => null);
}

function plesk_cli()
{
    foreach (array('/usr/sbin/plesk', '/usr/local/psa/bin/plesk', '/opt/psa/bin/plesk') as $candidate) {
        if (is_executable($candidate)) {
            return $candidate;
        }
    }

    return null;
}

function update_result($current, $latest, $available, $url, $size, $notes, $error)
{
    return array(
        'ok' => true,
        'current' => $current,
        'latest' => $latest,
        'available' => $available,
        'url' => $url,
        'size' => $size,
        'notes' => $notes,
        'error' => $error,
        'checked_at' => date('c'),
        'ttl' => $error === null ? UPDATE_CACHE_TTL : UPDATE_FAIL_TTL,
    );
}

function do_update_check($force = false)
{
    $cached = update_read(update_cache_file());
    if (!$force && is_array($cached) && isset($cached['checked_at'])
        && time() - (int) strtotime((string) $cached['checked_at']) < (int) (isset($cached['ttl']) ? $cached['ttl'] : 0)) {
        $cached['cached'] = true;

        return $cached;
    }

    $current = installed_extension_version();
    if ($current === null) {
        $result = update_result(null, null, false, null, 0, null,
            'The version of the installed extension could not be read.');
        update_write(update_cache_file(), $result);

        return $result;
    }

    $feed = sys_get_temp_dir() . '/' . EXTENSION_ID . '-feed-' . getmypid() . '.json';
    list($ok, $error) = http_download(UPDATE_FEED_URL, $feed, UPDATE_JSON_BYTES, UPDATE_FETCH_TIMEOUT);
    $data = $ok ? json_decode((string) @file_get_contents($feed), true) : null;
    @unlink($feed);

    if (!is_array($data)) {
        $result = update_result($current, null, false, null, 0, null,
            $error !== null ? $error : 'The update file did not return a usable answer.');
        update_write(update_cache_file(), $result);

        return $result;
    }

    $latest = update_tag_version(isset($data['version']) ? $data['version'] : '');
    if ($latest === null) {
        $result = update_result($current, null, false, null, 0, null,
            'The version in the update file is not a number this extension can compare.');
        update_write(update_cache_file(), $result);

        return $result;
    }

    $url = isset($data['url']) && update_url_allowed((string) $data['url']) ? (string) $data['url'] : null;
    $available = version_compare($latest, $current) > 0 && $url !== null;
    $notes = isset($data['notes']) && is_string($data['notes']) ? trim(substr($data['notes'], 0, 4000)) : null;

    $result = update_result($current, $latest, $available, $url, 0, $notes,
        $url === null ? 'The update file carries no installable package address.' : null);
    update_write(update_cache_file(), $result);

    return $result;
}

function do_update_apply()
{
    $check = do_update_check(true);
    if (empty($check['available'])) {
        return array('ok' => true, 'updated' => false, 'current' => $check['current'],
            'latest' => $check['latest'], 'error' => $check['error']);
    }

    $target = $check['latest'];
    $zip = sys_get_temp_dir() . '/' . EXTENSION_ID . '-' . $target . '-' . date('YmdHis') . '.zip';
    list($ok, $error) = http_download($check['url'], $zip, UPDATE_ZIP_BYTES, 120);
    if (!$ok) {
        @unlink($zip);

        return array('ok' => false, 'updated' => false, 'current' => $check['current'], 'error' => $error);
    }

    $verified = update_package_verifies($zip, $target, $check['current']);
    if (empty($verified['ok'])) {
        @unlink($zip);

        return array('ok' => false, 'updated' => false, 'current' => $check['current'], 'error' => $verified['error']);
    }

    /*
     * Plesk runs this extension's own removal script while it upgrades the
     * package. That script refuses to take the extension away while
     * OpenLiteSpeed is the web front, which would stop the upgrade too, so the
     * marker says "this is an upgrade" for as long as it takes to install.
     */
    update_write(update_marker_file(), array(
        'from' => $check['current'],
        'to' => $target,
        'started' => date('c'),
        'package' => basename($zip),
    ));

    $cli = plesk_cli();
    if ($cli === null) {
        @unlink($zip);
        @unlink(update_marker_file());

        return array('ok' => false, 'updated' => false, 'current' => $check['current'],
            'error' => 'The Plesk command line was not found, so the package cannot be installed.');
    }

    list($code, $out) = run(array($cli, 'bin', 'extension', '--upgrade', $zip));
    @unlink($zip);
    @unlink(update_marker_file());

    $installed = installed_extension_version();
    if ($code !== 0 || $installed !== $target) {
        return array('ok' => false, 'updated' => false, 'current' => $installed === null ? $check['current'] : $installed,
            'error' => 'Plesk could not install the package (exit ' . $code . '): ' . substr($out, -1200));
    }

    $root = detect_root();

    return array(
        'ok' => true,
        'updated' => true,
        'current' => $installed,
        'previous' => $check['current'],
        'front_installed' => $root !== null && front_block_installed($root),
        'ols_state' => $root === null ? array('running' => false) : service_state($root),
        'note' => 'Only the extension files changed; the web front configuration and every certificate stayed in place.',
    );
}

function main(array $argv)
{
    $action = get_arg($argv, 'action');
    if ($action === null || !in_array($action, VALID_ACTIONS, true)) {
        fail('Missing or invalid --action.');
    }

    $root = detect_root();
    if ($root === null && !in_array($action, SETUP_ACTIONS, true)
        && !in_array($action, ROOT_FREE_ACTIONS, true)) {
        fail('OpenLiteSpeed was not detected on this server. Install it or set the correct directory in the extension Settings.');
    }

    switch ($action) {
        case 'info':
            emit(action_info($root));
            break;
        case 'status':
            $state = service_state($root);
            $state['ok'] = true;
            $state['version'] = detect_version($root);
            emit($state);
            break;
        case 'start':
        case 'stop':
        case 'restart':
        case 'graceful':
            $result = do_control($root, $action);
            $state = service_state($root);
            emit(array_merge(array('ok' => true, 'action' => $action, 'state' => $state), $result));
            break;
        case 'test':
            list($code, $out) = test_config($root);
            $errors = $code === null ? array() : config_error_lines($out);
            $ok = count($errors) === 0;
            emit(array(
                'ok' => $ok,
                'supported' => $code !== null,
                'exit_code' => $code,
                'errors' => $errors,
                'output' => $out,
            ), $ok ? 0 : 1);
            break;
        case 'vhosts':
            emit(array('ok' => true, 'vhosts' => list_vhosts($root)));
            break;
        case 'logs':
            $type = get_arg($argv, 'type', 'error');
            if (!in_array($type, LOG_TYPES, true)) {
                fail('Unknown log type.');
            }
            $vhost = get_arg($argv, 'vhost');
            $lines = (int) get_arg($argv, 'lines', 100);
            $lines = max(1, min(MAX_LOG_LINES, $lines));

            if (strpos($type, 'vhost-') === 0) {
                if ($vhost === null || $vhost === '' || !preg_match('/^[A-Za-z0-9][A-Za-z0-9._-]*$/', $vhost)) {
                    $available = list_vhosts($root);
                    if (count($available) === 0) {
                        fail('This OpenLiteSpeed installation has no virtual host, so there is nothing to show.');
                    }
                    $vhost = $available[0]['name'];
                }
            }

            $path = log_path($root, $type, $vhost);
            $content = tail_file($path, $lines);
            emit(array(
                'ok' => true,
                'path' => $path,
                'vhost' => $vhost,
                'exists' => $content !== null,
                'lines' => $lines,
                'content' => $content === null ? '' : $content,
            ));
            break;
        case 'config-list':
            emit(action_config_list($root));
            break;
        case 'config-get':
            emit(action_config_get($root, (string) get_arg($argv, 'key', 'main')));
            break;
        case 'config-save':
            emit(action_config_save($root, (string) get_arg($argv, 'key', 'main'), get_arg($argv, 'payload')));
            break;
        case 'engine-status':
            emit(action_engine_status($root));
            break;
        case 'engine-switch-ols':
            emit(do_switch_ols($root, (string) get_arg($argv, 'php-mode', PHP_BACKEND)));
            break;
        case 'engine-switch-nginx':
            emit(do_switch_nginx($root));
            break;
        case 'engine-sync':
            emit(do_engine_sync($root));
            break;
        case 'engine-sync-check':
            emit(do_engine_sync_check($root));
            break;
        case 'engine-cron-install':
            emit(front_cron_write(true));
            break;
        case 'engine-cron-remove':
            emit(front_cron_write(false));
            break;
        case 'engine-revert':
            emit(do_engine_revert($root));
            break;
        case 'front-active':
            emit(front_active_state($root));
            break;
        case 'update-check':
            emit(do_update_check(get_arg($argv, 'force') !== null));
            break;
        case 'update-apply':
            emit(do_update_apply());
            break;
        case 'setup-status':
            emit(do_setup_status($root, get_arg($argv, 'lite') !== null));
            break;
        case 'setup-run':
            emit(do_setup_run($root, (string) get_arg($argv, 'php-mode', PHP_DIRECT)));
            break;
        case 'setup-worker':
            emit(do_setup_worker((string) get_arg($argv, 'php-mode', PHP_DIRECT)));
            break;
        case 'setup-skip':
            emit(do_setup_skip());
            break;
        case 'setup-done':
            emit(do_setup_done());
            break;
        case 'setup-reset':
            emit(do_setup_reset());
            break;
        case 'admin-console':
            $info = admin_console_info($root);
            $info['ok'] = true;
            $info['host_name'] = gethostname();
            emit($info);
            break;
        case 'admin-console-user':
            emit(do_admin_console_user($root, get_arg($argv, 'user'), get_arg($argv, 'payload')));
            break;
    }

    fail('Unhandled action.');
}

main($argv);
